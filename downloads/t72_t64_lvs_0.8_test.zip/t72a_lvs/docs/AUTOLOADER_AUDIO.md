# Original loader sound effects

`sound/t72a_ural/autoloader.wav` and `sound/t64a_1971/loader.wav` are original
procedurally synthesized game effects, not sampled recordings of real AZ/MZ
units. They contain staged motor/servo tones, friction, chain ratchet pulses,
steel clunks and a final latch. Each lasts 7.1 seconds and is mono signed
16-bit PCM at 44.1 kHz. Their peak is limited to about -2.2 dBFS; GMod emission
volume is restrained so the cue does not overwhelm the cannon.

Regenerate with `python tools/build_autoloader_audio.py` (numpy required).
The two variants are intentionally different, but no historical recording
authenticity is claimed.

The server starts a cue only after a successful shot, accepted shell-type
change or actual cannon rearm. Repeated think calls cannot stack it. A new
reload schedule stops the existing cue before restarting; destruction,
deletion and the reload deadline stop playback. It is emitted spatially at
the vehicle. Standalone tests check the lifecycle and PCM integrity; audible
balance in a running Garry's Mod session remains a live check.
