# Uploaded T-72 Ural rig measurements

The uploaded `models.7z` contains Damik's `T-72 URAL (Prop)` and `(Ragdoll)` Source
models. The user selected **T-72 «Урал»**, rather than relabelling this geometry as
T-72A. Original model assets are external dependencies and are not bundled.

Inspected prop MDL SHA-256:
`e50e645fdbb40870441bf31142592c191f11b7e1dc789056ac711a1b79490fab`.
Companions were present: `.vvd`, `.dx90.vtx`, `.phy`. The archive contained no Lua
vehicle definitions or materials. Source MDL version is 49, with 60 bones, **zero
attachments and zero pose parameters**, 43 material slots and four skin families.

Measurements were read using SourceIO's v49 MDL/VVD readers and the original
`tools/inspect_source_model.py` reporting script. Full extracted reports and meshes
remain in `/workspace/scratch/t72a-research`, outside the distributable addon.

## Coordinates and animation

Raw VVD bind geometry points down -Y. **The Source runtime's first sequence
already changes the root bone from bind quaternion (~0.7071,0,0,~0.7071) to
(~0.5,~0.5,~0.5,~0.5).** Skinning uses animatedBone * poseToBone, producing a
+90-degree yaw on the whole mesh before entity rotation. Thus the actual model
renders with forward +X, +Y left and +Z up without another visual yaw.

Version 0.1 accidentally applied a second +90 yaw to its clientside model, which
explains the user's sideways-driving and side-of-turret firing reports: its
physics/muzzle coordinates were already in the correct runtime frame but the
visible model was rotated again. Version 0.2 sets `VisualYaw = 0`, freezes
sequence 0 at cycle 0, and keeps the measured runtime pivots below.

`tools/verify_runtime_pose.py` verifies the first-frame animation against all
60 pose-to-bone matrices in the actual MDL. Every skinning matrix matches yaw+90
within 8.5e-6 per matrix element. The end-ring runtime centre is approximately
(240.478105, 0.044660, 69.941846), agreeing with the profile within 0.0011 units.
The root is the only bone with an animation channel; there are no per-wheel or
track-leaf animation overrides. These source-derived values are covered by an
additional fixture in `tests/bone_turret.lua` so a duplicated visual yaw fails.

Measured runtime-reference pivots, in Source units:

| Element | Coordinates |
| --- | --- |
| `>>>TURRET<<<`, bone 29 | (-11.45601, 0, 30.06000) |
| `>>>GUN<<<`, bone 30, child of 29 | (22.79314, 0, 64.96432) |
| `Barrel`, bone 31, child of 30 | (49.49085, 0.04600, 69.85962) |
| Barrel end-ring centre from mesh vertices | (240.478439, 0.0451313, 69.9407692) |

Sequence-zero turret runtime rotation maps local bone +Y to global +Z. Thus Source
`ManipulateBoneAngles` uses `Angle(yaw,0,0)` for yaw. Sequence-zero gun runtime rotation
is approximately diag(1,-1,-1): positive downward gun pitch uses
`Angle(-pitch,0,0)`. Apply pitch about the gun pivot, then yaw the whole assembly
about the turret pivot. This analytic chain is also used by server muzzle math;
it does not depend on a server-side bone cache or nonexistent attachments.

The model has **no identified MG muzzle attachment or MG-named bone**. A coaxial
machine-gun origin must therefore be an explicit gameplay socket, not described
as an extracted attachment. The neighbouring `>>GUN - Part a<<` front mesh point
is (57.77336,-7.95117,68.39630), but its function was not proven from metadata.

## Chassis measurements

Hull mesh bounds (excluding the separate turret/barrel) are
(-167.81201,-71.40800,19.74800)..(128.28000,71.52400,63.82800). A simple collision
box based on these bounds is an approximation to the hull, not the original
multi-convex collision geometry.

Six road-wheel centres on each side: X approximately
81.960, 47.516, 13.856, -19.826, -53.256, -86.840; Y approximately +/-57.322;
Z approximately 18.292. Mesh radius is 15.684 and width 16.420. These are mesh
centres: bone-pivot Y offsets differ and should not be reused as physical wheel
centre coordinates. LVS `AddWheel` accepts explicit `radius` and `width` fields.

Wheel local +Y maps to canonical -Y. Forward physical rolling about canonical +Y
therefore corresponds to visual `Angle(-spin,0,0)`, with the same bone-frame
orientation on left and right. The model has track deformation bones but no
stock track-scroll pose parameters.

All bind/geometry results are offline evidence. They do not establish Source
runtime bone multiplication order, suspension tuning, collision stability,
network prediction or gameplay correctness; those need a Garry's Mod run.
