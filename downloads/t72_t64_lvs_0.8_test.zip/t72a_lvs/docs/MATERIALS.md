# Original material set — v0.2

The worn olive base-color tile was generated for this project using OpenAI image
generation. Its source is included at `assets/source/olive_generated.png`. The
output textures are resampled to 2048x2048; this does not imply the source image
had a native 2K pixel resolution. No original model textures or War Thunder
resources are included.

`tools/build_materials.py SOURCE.png` reproduces the material set using Pillow
and numpy. Armor now has a worn/mottled olive albedo, an artist-derived fine
surface normal map, and a varying specular mask in the albedo alpha channel.
Rubber, tracks and steel have their own original procedural albedos and normal
maps. The tracks use an original repeated chevron/link pattern, so moving UVs
have visible detail. These patterns are material art, not extracted tread
geometry and not an assertion of historically exact manufacturing detail.

## Source formats and shaders

Textures are VTF 7.2 BC3/DXT5 with complete mip chains, smallest mip first. Each
compressed tiny mip still occupies a 4x4 BC block. The original converter's
RGBA8888 option remains available for fixtures and lossless small outputs; BC1
is also tested. Pillow's DDS encoder supplies the BC block compression, with its
DDS container removed before writing the independently constructed VTF header.
Normal-map files carry Source's NORMAL texture flag; their mip vectors are
renormalized before compression. Normals represent bounded artistic microrelief
from generated surface variation. They are **not** high-to-low model bakes,
scanned normals, or recovered original normals.

`VertexLitGeneric` uses `$bumpmap`, `$phong`, `$phongexponent`, and a varying
`$basemapalphaphongmask`. The alpha channel controls highlights, not opacity:
no translucent flag is enabled. Lamps and tinted glass remain intentionally
opaque to avoid transparency sorting issues in the two-pass visual adapter.
No claim is made that this approximates a full modern metallic/roughness PBR
shader; it uses the material features available in Garry's Mod's Source engine.

## Final field-worn pass

The final source image has substantially denser chips, rubbed paint, dry dust
and dark earth marks. Independently seeded, tileable low-frequency mud and dust
masks are also applied to armor, track steel, rubber, exposed steel, lenses and
lamp surfaces. Mud and dust lower the material's highlight mask instead of
adding shiny baked highlights. No material or geometry from another game is
used for these additions.

Armor Phong boost is 0.10, tracks 0.12, exposed steel 0.18, rubber 0.025,
interior 0.03 and lamp glass 0.03. Armor/track/rubber Fresnel ranges are limited
to `[0.02 0.08 0.2]`; exposed steel uses `[0.03 0.12 0.3]`. The opaque dirty lens
keeps only a very faint environment reflection. Narrow exposed track ridges can
still polish, but mud and rubber remain deliberately matte. These Source Phong
parameters are not a physical roughness model, and the Blender preview is an
approximation of the corresponding visual intent, not the Source renderer.

`build_materials.py --preview PATH` also exports individual generated PNG maps
beside the contact sheet under `material_sources/` so the model preview can use
the exact final albedo/normal/mask inputs. New images are original material art.

## Per-model scope

The 43 model slots, including alternate skins, resolve by basename through
`lua/t72a/sh_materials.lua`. The default skin uses the first19 slots, within
GMod's 0..31 submaterial override interface. Armor is olive, wheels/black parts
rubber, tracks and netting dark steel, and the interior dark gray. The `props`
slot is shared by equipment and the rear log; both retain the generic paint
surface because a detailed per-part UV atlas was not provided or recreated.

Only this vehicle's private visual model receives the replacements. The original
Workshop files and unrelated vehicles are not overwritten. Each track-side
runtime material must inherit the static tracks shader's base texture, bumpmap,
and highlight mask rather than mutating the global VMT.

## Validation

`tests/test_materials.py` checks VTF header fields, mip ordering and row/channel
orientation, BC block sizes including sub4x4 mips, independent DDS decoding of
the VTF's largest BC payload, normal-mip vector lengths, and alpha-mask flags.
The generated contact sheet was visually inspected at
`/workspace/scratch/t72a-research/materials_v2_contact.png`. These checks do not
substitute for Source shader/lighting validation in Garry's Mod.
