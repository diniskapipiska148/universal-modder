# LVS API evidence and scope

This addon targets Garry's Mod Lua and the `lvs_tank_wheeldrive` entity API. Source was inspected on 2026-11-04. No Garry's Mod executable or game session is available in this cloud machine; compatibility review is not an in-game test.

## References

- LVS Framework source mirror: <https://github.com/SpaxscE/lvs_base>, inspected commit `54c88e21ff2fab6c6be3303eaa17309d6a31eda8`.
- LVS tank examples mirror: <https://github.com/SpaxscE/lvs_tanks>, inspected commit `4e9982159400e6dd2fd5c5f3fd2ce1e87fa6ea6e`.
- Requested model source: <https://steamcommunity.com/sharedfiles/filedetails/?id=2884416595>. The cloud proxy initially denied this host. No model, rig, attachment names or reuse licence have been verified from that download at this stage.

These GitHub repositories are mirrors used as API references; they are not claimed to be the authoritative latest Workshop release. No framework or tank-example source/assets are bundled in this addon.

## API evidence

Framework paths below are relative to `lvs_base`:

- `lua/lvs_framework/init.lua` calls `resource.AddWorkshop("2912816023")`; this identifies the Framework Workshop dependency.
- `lua/entities/lvs_tank_wheeldrive/shared.lua`: inherits `lvs_base_wheeldrive`, identifies itself as vehicle type `tank`, adds the networked track-drive wheels.
- `lua/entities/lvs_base/shared.lua`: `CreateBaseDT()` calls `InitWeapons()` and allocates health, weapon, driver, and engine-related network fields through `AddDT`. `OnSetupDataTables()` is the supported addon hook for extra fields. `GetHP()`/`GetMaxHP()` expose hull health.
- `lua/entities/lvs_base_wheeldrive/init.lua`: `PostInitialize(PObj)` invokes `TracksCreate(PObj)`; base initialization invokes `OnSpawn(PObj)` separately. Do not manually repeat those base initialization phases.
- `lua/entities/lvs_base_wheeldrive/sv_components.lua`: `AddEngine(pos,ang,mins,maxs)` creates an engine emitter/control entity and a damage-system region. `AddFuelTank` and `AddAmmoRack` add separate damageable modules. This addon's single-health mode should not use module damage regions.
- `lua/entities/lvs_base/sv_damagesystem.lua`: `CalcDamage` applies damage masks/reduction and `CalcComponentDamage`, updates `HP`, then performs normal destruction and explosion lifecycle. Disabling component interception while keeping this lifecycle preserves standard LVS destruction handling.
- `lua/entities/lvs_base_wheeldrive/sv_damage.lua`: stock collision damage targets the engine component. Single-health mode needs an explicit hull collision policy.
- `lua/entities/lvs_tank_wheeldrive/modules/sh_turret.lua`: optional turret module uses pose parameters, `TurretSystemDT`, `AimTurret`, and pitch/yaw rate limits. Pose names and attachment directions are model-specific and must be inspected.
- `lua/entities/lvs_base/init.lua`: `LVSFireBullet(data)` sets the firing entity and delegates to `LVS:FireBullet`; `Velocity` must be supplied. Source velocity is incorporated by the framework.
- `lua/entities/lvs_base/sh_weapons.lua`: weapons are registered via `AddWeapon`, with server `Attack`, `OnThink`, and heat/ammo handling. `TakeAmmo(1)` is explicit in the attack callback. Client accessors include `GetNWAmmo`, `GetNWHeat`, and `GetAmmoID`.
- `lua/entities/lvs_base/cl_hud.lua`: entity HUD extension points include `LVSHudPaint(X,Y,ply)`, `LVSHudPaintVehicleHealth(...)`, and `LVSHudPaintInfoText(...)`. Shared API provides `GetSelectedWeapon`, `GetMaxAmmo`, and `GetMaxHP`; wheeldrive adds `GetGear`.
- `zzz_readme_function_list.txt`: `ply:lvsGetVehicle()` returns the occupied LVS entity; `ply:lvsGetWeaponHandler()` distinguishes the weapon handler from the hull. Controls are queried through `ply:lvsKeyDown(name)`.

Concrete known-working example paths relative to `lvs_tanks`:

- `lua/entities/lvs_wheeldrive_t34_base/sh_tracks.lua`: hidden wheel pairs, `DefineAxle`, `CreateWheelChain`, `SetTrackDriveWheelLeft/Right`, pivot steering. Its coordinates are T-34-specific and must not be used as T-72 rig measurements.
- `lua/entities/lvs_wheeldrive_t34_base/init.lua`: driver/passenger seats, engine, fuel and module setup. This addon's simplified health omits the armor, fuel and ammo-rack subsystems.
- `lua/entities/lvs_wheeldrive_t34/shared.lua`: shell and coaxial weapon callbacks use `LVSFireBullet` with `EnableBallistics`, `Damage`, `Velocity`, optional splash damage, and explicit ammunition consumption.

## Required live verification

A successful Lua parse or mocked test cannot validate Source model physics, material mounting, suspension tuning, turret/muzzle alignment, network prediction, rendered HUD, or controls. Check these in a local Sandbox session before calling the vehicle fully functional. Obtain the requested model through its original Workshop addon rather than redistributing its files. Its materials, collision hull, pose parameters/bones, attachments, axis conventions and rights must be confirmed before enabling a final model profile.
