#!/usr/bin/env python3
"""Synthesize original tank-loader game sounds; no sampled/recorded audio.

These are designed mechanical effects, not historical recordings of AZ/MZ units.
Usage: python tools/build_autoloader_audio.py [addon_root]
Requires numpy. Output is mono 44.1 kHz signed 16-bit PCM WAV, 7.1 seconds.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import wave
import numpy as np

RATE = 44100
DURATION = 7.1


def make_loader(seed: int = 72, hydraulic: bool = False) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = round(RATE * DURATION)
    out = np.zeros(n, dtype=np.float64)

    def add(start: float, samples: np.ndarray):
        first = round(start * RATE)
        last = min(first + len(samples), n)
        if last > first:
            out[first:last] += samples[:last-first]

    def clunk(start: float, strength: float = 1, bright: float = 1):
        t = np.arange(round(.32 * RATE)) / RATE
        # Damped, slightly inharmonic steel resonances with a soft low thud.
        signal = np.zeros_like(t)
        for f, level, decay in ((137, .22, 20), (283, .15, 27), (617, .09, 40),
                                (1043, .035, 56), (1799, .02, 85)):
            signal += level * np.sin(2*np.pi*f*bright*t) * np.exp(-decay*t)
        attack = rng.normal(size=t.size) * np.exp(-t*220) * .065
        add(start, (signal + attack) * strength)

    def motor(start: float, seconds: float, low: float, high: float, gain: float):
        t = np.arange(round(seconds * RATE)) / RATE
        u = t / max(seconds, .001)
        frequency = low + (high-low) * np.sin(np.pi*u)**.6
        phase = 2*np.pi*np.cumsum(frequency) / RATE
        envelope = np.minimum(t/.12, 1) * np.minimum((seconds-t)/.19, 1)
        envelope = np.maximum(envelope, 0)
        signal = (np.sin(phase) + .31*np.sin(phase*2.02) + .13*np.sin(phase*4.01))
        # Small load fluctuation/chain gear modulation, no continuous loud hiss.
        signal *= .78 + .10*np.sin(2*np.pi*13*t) + .07*np.sin(phase*.25)
        add(start, signal * envelope * gain)

    def slide(start: float, seconds: float, strength: float):
        t = np.arange(round(seconds * RATE)) / RATE
        noise = rng.normal(size=t.size)
        # Moving average keeps broad friction below piercing high frequencies.
        noise = np.convolve(noise, np.ones(17)/17, mode="same")
        env = np.sin(np.pi*t/seconds)**1.1
        signal = noise*.27 + .045*np.sin(2*np.pi*(205*t + 24*t*t))
        add(start, signal*env*strength)

    clunk(.05, .95, .86 if hydraulic else 1)
    motor(.18, .74, 76, 124, .042)
    clunk(.86, .45)
    motor(1.02, 2.50, 74 if hydraulic else 92, 126 if hydraulic else 166, .052)
    # Ratchet links move with the carousel, initially slower and then steady.
    for i in range(17):
        clunk(1.15 + i*.135, .105 + .025*np.sin(i), 1.08)
    clunk(3.49, .70, .93)
    motor(3.64, 1.05, 145 if hydraulic else 105, 193 if hydraulic else 154, .038)
    slide(3.68, 1.02, .65 if hydraulic else .43)
    clunk(4.68, .80, .83)
    motor(4.82, 1.38, 82, 139, .045)
    slide(4.88, 1.20, .72)
    for when in (5.00, 5.20, 5.41, 5.64, 5.87):
        clunk(when, .12, .92)
    clunk(6.25, .58, .92)
    clunk(6.57, 1.02, .80)
    motor(6.66, .34, 88, 101, .018)

    # Remove DC, avoid clipping, and retain useful headroom for the cannon.
    out -= out.mean()
    out *= .78 / max(float(np.max(np.abs(out))), 1e-9)
    out[:441] *= np.linspace(0, 1, 441)
    out[-2205:] *= np.linspace(1, 0, 2205)
    return out


def write_wave(path: Path, signal: np.ndarray):
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = np.round(np.clip(signal, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(RATE)
        stream.writeframes(pcm.tobytes())


def build(root: Path):
    for filename, seed, hydraulic in (("t72a_ural/autoloader.wav", 72, False),
                                      ("t64a_1971/loader.wav", 64, True)):
        signal = make_loader(seed, hydraulic)
        path = root / "sound" / filename
        write_wave(path, signal)
        print(f"{path}: {DURATION}s, mono PCM16/{RATE}, "
              f"peak={np.max(np.abs(signal)):.3f}, RMS={np.sqrt(np.mean(signal**2)):.3f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", type=Path, default=Path(__file__).resolve().parents[1])
    build(parser.parse_args().root)
