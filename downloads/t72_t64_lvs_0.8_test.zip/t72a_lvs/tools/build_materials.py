#!/usr/bin/env python3
"""Build original detail materials for Source from the generated olive albedo.

Requires Pillow and numpy. Source albedo is artist-generated, not a measured
surface or historical atlas. Derived normals approximate fine surface relief;
all tread/rubber/steel patterns below are original procedural material art.
"""
from __future__ import annotations
import argparse
import io
from pathlib import Path
import struct
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

FORMAT_IDS = {"RGBA8888": 0, "DXT1": 13, "DXT5": 15}


def mip_images(image: Image.Image, normal_map: bool = False) -> list[Image.Image]:
    levels = [image.convert("RGBA")]
    while levels[-1].size != (1, 1):
        w, h = levels[-1].size
        level = levels[-1].resize((max(w//2, 1), max(h//2, 1)), Image.Resampling.BOX)
        if normal_map:
            a = np.asarray(level).astype(np.float32)
            n = a[:, :, :3] / 127.5 - 1
            n /= np.maximum(np.linalg.norm(n, axis=2, keepdims=True), 1e-8)
            a[:, :, :3] = (n + 1) * 127.5
            level = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA")
        levels.append(level)
    return levels


def encode_vtf(image: Image.Image, compression: str = "RGBA8888", *, normal_map: bool = False) -> bytes:
    """VTF 7.2; packed RGBA8888 or native BC1/BC3 payloads, smallest mip first.

    Pillow's DDS BC encoder supplies the block encoding, not the VTF header.
    Compressed small mips still occupy one 4x4 block. Normal mip vectors are
    renormalized before compression and carry Source's NORMAL texture flag.
    """
    image = image.convert("RGBA")
    width, height = image.size
    if width < 1 or height < 1 or width & (width - 1) or height & (height - 1):
        raise ValueError("VTF dimensions must be positive powers of two")
    if compression not in FORMAT_IDS:
        raise ValueError("unsupported VTF compression")
    levels = mip_images(image, normal_map)
    header = bytearray(80)
    header[0:4] = b"VTF\0"
    flags = 0x12 | (0x80 if normal_map else 0)
    if image.getextrema()[3][0] < 255:
        flags |= 0x2000  # EIGHTBITALPHA: used as a Phong mask, not translucency.
    struct.pack_into("<IIIHHIHH", header, 4, 7, 2, 80, width, height, flags, 1, 0)
    average = image.convert("RGB").resize((1, 1), Image.Resampling.BOX).getpixel((0, 0))
    struct.pack_into("<3f", header, 32, *(v / 255 for v in average))
    struct.pack_into("<fI", header, 48, 1.0, FORMAT_IDS[compression])
    header[56] = len(levels)
    struct.pack_into("<I", header, 57, 0xFFFFFFFF)
    struct.pack_into("<H", header, 63, 1)
    chunks = []
    for level in reversed(levels):
        if compression == "RGBA8888":
            chunks.append(level.tobytes())
        else:
            stream = io.BytesIO()
            level.save(stream, format="DDS", pixel_format=compression)
            data = stream.getvalue()
            if data[:4] != b"DDS " or data[84:88] != compression.encode("ascii"):
                raise ValueError("Pillow DDS encoder did not return expected BC format")
            chunks.append(data[128:])
    return bytes(header) + b"".join(chunks)


def normal_from_height(height: np.ndarray, strength: float = 1.0) -> Image.Image:
    """Bounded wrap-aware artist micro-relief, Source/DirectX normal convention."""
    height = height.astype(np.float32)
    dx = (np.roll(height, -1, 1) - np.roll(height, 1, 1)) * strength
    dy = (np.roll(height, -1, 0) - np.roll(height, 1, 0)) * strength
    # Source uses a left-handed tangent space; green follows raster-down Y.
    n = np.stack((-dx, -dy, np.ones_like(height)), axis=2)
    n /= np.linalg.norm(n, axis=2, keepdims=True)
    return Image.fromarray(np.rint((n + 1) * 127.5).astype(np.uint8), "RGB")


def periodic_noise(size: int, grid: int, rng: np.random.Generator) -> np.ndarray:
    small = rng.integers(0, 256, (grid, grid), dtype=np.uint8)
    padded = np.pad(small, 1, mode="wrap")
    large = Image.fromarray(padded).resize((size + size*2//grid, size + size*2//grid), Image.Resampling.BICUBIC)
    margin = size // grid
    return np.asarray(large.crop((margin, margin, margin + size, margin + size))).astype(np.float32)/255


def color_image(rgb: np.ndarray, alpha: np.ndarray | float) -> Image.Image:
    rgb = np.clip(rgb, 0, 255).astype(np.uint8)
    a = np.full(rgb.shape[:2], alpha, dtype=np.float32) if np.isscalar(alpha) else alpha
    return Image.fromarray(np.dstack((rgb, np.clip(a, 0, 255).astype(np.uint8))), "RGBA")


def dirty_surface(rgb: np.ndarray, alpha: np.ndarray | float, dirt: np.ndarray,
                  dust: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Layer original dry earth over paint/metal; dirt suppresses highlights."""
    shape = rgb.shape[:2]
    alpha = np.full(shape, alpha, dtype=np.float32) if np.isscalar(alpha) else alpha.copy()
    mud = np.array([61, 52, 39], dtype=np.float32)
    earth = np.array([112, 103, 79], dtype=np.float32)
    mud_amount = np.clip(dirt, 0, 1) * .45
    dust_amount = np.clip(dust, 0, 1) * .30
    rgb = rgb * (1-mud_amount[...,None]) + mud * mud_amount[...,None]
    rgb = rgb * (1-dust_amount[...,None]) + earth * dust_amount[...,None]
    alpha *= 1-.85*np.maximum(dirt, dust*.8)
    return rgb, np.clip(alpha, 3, 96)


def surface_set(source: Path) -> dict[str, tuple[Image.Image, str, bool]]:
    rng = np.random.default_rng(72003)
    with Image.open(source) as raw:
        armor = raw.convert("RGB").resize((2048, 2048), Image.Resampling.LANCZOS)
    a = np.asarray(armor).astype(np.float32)
    luminance = a.mean(2)/255
    local = np.asarray(armor.convert("L").filter(ImageFilter.GaussianBlur(3))).astype(np.float32)/255
    relief = (luminance-local)*.16 + periodic_noise(2048, 128, rng)*.009
    dirt = np.clip((periodic_noise(2048, 7, rng)-.35)*2, 0, 1)
    dust = np.clip((periodic_noise(2048, 11, rng)-.3)*1.8, 0, 1)
    spec = np.clip(17+(luminance-local)*160+periodic_noise(2048, 32, rng)*12,8,40)
    armor_rgb, armor_spec = dirty_surface(a,spec,dirt*.65,dust*.7)
    images = {"olive": (color_image(armor_rgb,armor_spec),"DXT5",False),
              "olive_normal": (normal_from_height(relief,.16),"DXT5",True)}
    size = 1024
    y,x = np.mgrid[0:size,0:size].astype(np.float32)/size
    fine = rng.random((size,size),dtype=np.float32)
    broad = periodic_noise(size,24,rng)
    mud = np.clip((periodic_noise(size,6,rng)-.25)*2.2,0,1)
    dust = np.clip((periodic_noise(size,13,rng)-.3)*1.7,0,1)
    band = (x*12)%1
    raised = np.clip((band-.16)*14,0,1)*np.clip((.88-band)*14,0,1)
    chevron = np.abs(((x*12+np.abs((y*4)%1-.5)*.38)%1)-.5)
    edge = np.exp(-(chevron/.045)**2)
    track_height = raised*.36+edge*.17+(fine-.5)*.025
    track_gray = 37+raised*20+edge*42+broad*15+(fine-.5)*8
    track_rgb = np.stack((track_gray*1.01,track_gray,track_gray*.96),2)
    # Only narrow contact ridges polish; most exposed belt is dusty matte steel.
    track_spec = np.clip(12+edge*58+fine*2,12,72)
    track_rgb,track_spec = dirty_surface(track_rgb,track_spec,mud,dust)
    images["tracks_color"]=(color_image(track_rgb,track_spec),"DXT5",False)
    images["tracks_normal"]=(normal_from_height(track_height,1.3),"DXT5",True)
    rubber_gray = 22+broad*7+(fine-.5)*7
    rubber_rgb = np.repeat(rubber_gray[:,:,None],3,2)
    rubber_rgb,rubber_spec = dirty_surface(rubber_rgb,4+broad*18,mud*.9,dust)
    rubber_height = (fine-.5)*.04+(np.sin(x*2*np.pi*38)*.5+.5)*.009
    images["rubber_color"]=(color_image(rubber_rgb,rubber_spec),"DXT5",False)
    images["rubber_normal"]=(normal_from_height(rubber_height,.25),"DXT5",True)
    steel = 47+broad*26+(fine-.5)*12
    scratches = np.maximum(np.sin((x*76+y*.6)*2*np.pi)-.985,0)*1200
    steel_rgb = np.stack((steel*.95+scratches,steel+scratches,steel*1.02+scratches),2)
    steel_rgb,steel_spec = dirty_surface(steel_rgb,np.clip(20+broad*42+scratches,20,96),mud*.8,dust*.8)
    images["neutral"]=(color_image(steel_rgb,steel_spec),"DXT5",False)
    images["steel_normal"]=(normal_from_height((fine-.5)*.03+scratches/3500,.25),"DXT5",True)
    # Lenses/lamps get their own dirt variation rather than perfectly flat colors.
    small=256
    grime=np.clip((periodic_noise(small,8,rng)-.18)*2,0,1)
    haze=periodic_noise(small,16,rng)
    glass_rgb=np.broadcast_to(np.array([45,53,47],dtype=np.float32),(small,small,3)).copy()
    glass_rgb,glass_alpha=dirty_surface(glass_rgb,8,grime*.65,haze*.6)
    images["glass"]=(color_image(glass_rgb,glass_alpha),"DXT5",False)
    lamp_rgb=np.broadcast_to(np.array([146,141,110],dtype=np.float32),(small,small,3)).copy()
    lamp_rgb,lamp_alpha=dirty_surface(lamp_rgb,18,grime,haze*.7)
    images["lamp"]=(color_image(lamp_rgb,lamp_alpha),"DXT5",False)
    return images


def vmt(texture: str, extra: str = "") -> str:
    return ('"VertexLitGeneric"\n{\n'+f'    "$basetexture" "t72a_ural/{texture}"\n'
            +'    "$model" "1"\n'+extra+'}\n')


def lit(texture: str, normal: str, exponent: int, boost: float, extra: str = "", fresnel: str = "[0.02 0.08 0.2]") -> str:
    return vmt(texture, f'    "$bumpmap" "t72a_ural/{normal}"\n'
        +'    "$phong" "1"\n'+f'    "$phongexponent" "{exponent}"\n'
        +f'    "$phongboost" "{boost}"\n'+ '    "$basemapalphaphongmask" "1"\n'
        +f'    "$phongfresnelranges" "{fresnel}"\n'+extra)


def build(source: Path, addon: Path, preview: Path | None = None) -> list[Path]:
    destination=addon/"materials"/"t72a_ural"
    destination.mkdir(parents=True,exist_ok=True)
    images=surface_set(source)
    result=[]
    for name,(image,compression,normal) in images.items():
        path=destination/(name+".vtf")
        path.write_bytes(encode_vtf(image,compression,normal_map=normal))
        result.append(path)
    specs={
        "olive":lit("olive","olive_normal",12,.10),
        "darksteel":lit("neutral","steel_normal",22,.18,fresnel="[0.03 0.12 0.3]"),
        "tracks":lit("tracks_color","tracks_normal",20,.12),
        "rubber":lit("rubber_color","rubber_normal",6,.025),
        "glass":vmt("glass",'    "$envmap" "env_cubemap"\n    "$envmaptint" "[0.012 0.015 0.012]"\n'),
        "lamp":vmt("lamp",'    "$phong" "1"\n    "$phongexponent" "12"\n    "$phongboost" "0.03"\n    "$basemapalphaphongmask" "1"\n'),
        "lamp_on":vmt("lamp",'    "$selfillum" "1"\n'),
        "interior":lit("neutral","steel_normal",8,.03,'    "$color2" "[0.55 0.55 0.5]"\n'),
    }
    for name,content in specs.items():
        path=destination/(name+".vmt");path.write_text(content,encoding="utf8");result.append(path)
    if preview:
        preview.parent.mkdir(parents=True,exist_ok=True)
        keys=("olive","olive_normal","tracks_color","tracks_normal","rubber_color","rubber_normal","neutral","steel_normal")
        canvas=Image.new("RGB",(1280,700),(24,25,26));draw=ImageDraw.Draw(canvas)
        for i,key in enumerate(keys):
            px,py=(i%4)*320,(i//4)*350
            tile=images[key][0].convert("RGB").resize((316,316),Image.Resampling.LANCZOS)
            canvas.paste(tile,(px,py+26));draw.text((px+8,py+6),key,fill=(235,235,235))
        canvas.save(preview)
        sources=preview.parent/"material_sources"
        sources.mkdir(parents=True,exist_ok=True)
        for name,(image,_,_) in images.items():
            image.save(sources/(name+".png"))
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source",type=Path)
    parser.add_argument("addon",type=Path,nargs="?",default=Path(__file__).resolve().parents[1])
    parser.add_argument("--preview",type=Path)
    args=parser.parse_args()
    for p in build(args.source,args.addon,args.preview):print(p)
