#!/usr/bin/env python3
"""Render a private extracted model with the addon's authored material maps.

Run in Blender, e.g. blender -b -t 4 --python tools/render_preview.py --
 --mesh /private/t72_mesh.npz --metadata /private/mesh_metadata.json
 --textures /private/material_sources --materials materials/t72a_ural
 --output /private/previews

External model data is never written into the addon. The Blender Principled
shader is an approximation to Source's VertexLitGeneric, not a game screenshot.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import re
import sys

import bpy
import numpy as np
from mathutils import Vector


def parse_args():
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mesh", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--textures", type=Path, required=True)
    parser.add_argument("--materials", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=32)
    return parser.parse_args(args)


def resolve(name):
    name = re.sub(r"\(\d+\)$", "", name.lower())
    return {"sus":"rubber", "black":"rubber", "tracks":"tracks",
        "net":"darksteel", "antenna":"darksteel", "int":"interior",
        "glass alpha":"glass", "lights":"lamp", "lights on":"lamp_on",
        "lamp":"lamp", "lamp on":"lamp_on"}.get(name, "olive")


def shader(name, args):
    source = (args.materials / (name + ".vmt")).read_text()
    parameters = dict(re.findall(r'"(\$[^\"]+)"\s+"([^\"]*)"', source))
    mat = bpy.data.materials.new("Original authored " + name)
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    bsdf = nodes.get("Principled BSDF")
    # Low IOR-level and high roughness approximate the final low-Phong finish.
    boost = float(parameters.get("$phongboost", "0.02"))
    bsdf.inputs["Specular IOR Level"].default_value = min(.2, boost * .65)
    bsdf.inputs["Roughness"].default_value = .9 if name != "glass" else .68
    bsdf.inputs["Metallic"].default_value = .12 if name in {"darksteel", "tracks"} else 0
    base = parameters["$basetexture"].rsplit("/", 1)[-1]
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(str(args.textures / (base + ".png")), check_existing=True)
    tex.extension = "REPEAT"
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    if "$color2" in parameters:
        values = [float(v) for v in parameters["$color2"].strip("[]").split()]
        multiply = nodes.new("ShaderNodeMixRGB")
        multiply.blend_type = "MULTIPLY"
        multiply.inputs[0].default_value = 1
        multiply.inputs[2].default_value = (*values, 1)
        links.new(tex.outputs["Color"], multiply.inputs[1])
        links.new(multiply.outputs[0], bsdf.inputs["Base Color"])
    # Phong-mask alpha affects roughness mildly, never surface opacity.
    roughness = nodes.new("ShaderNodeMapRange")
    roughness.inputs["From Min"].default_value = 0
    roughness.inputs["From Max"].default_value = 1
    roughness.inputs["To Min"].default_value = .94
    roughness.inputs["To Max"].default_value = .6
    links.new(tex.outputs["Alpha"], roughness.inputs["Value"])
    links.new(roughness.outputs["Result"], bsdf.inputs["Roughness"])
    if "$bumpmap" in parameters:
        normal_name = parameters["$bumpmap"].rsplit("/", 1)[-1]
        normal_tex = nodes.new("ShaderNodeTexImage")
        normal_tex.image = bpy.data.images.load(str(args.textures / (normal_name + ".png")), check_existing=True)
        normal_tex.image.colorspace_settings.name = "Non-Color"
        normal_tex.extension = "REPEAT"
        normal = nodes.new("ShaderNodeNormalMap")
        normal.inputs["Strength"].default_value = 1
        # Source normal maps use raster-down green. Blender's tangent normal
        # input is OpenGL-style, so flip only the green component for preview.
        separate = nodes.new("ShaderNodeSeparateColor")
        separate.mode = "RGB"
        combine = nodes.new("ShaderNodeCombineColor")
        combine.mode = "RGB"
        flip = nodes.new("ShaderNodeMath")
        flip.operation = "SUBTRACT"
        flip.inputs[0].default_value = 1
        links.new(normal_tex.outputs["Color"], separate.inputs["Color"])
        links.new(separate.outputs["Green"], flip.inputs[1])
        links.new(separate.outputs["Red"], combine.inputs["Red"])
        links.new(flip.outputs[0], combine.inputs["Green"])
        links.new(separate.outputs["Blue"], combine.inputs["Blue"])
        links.new(combine.outputs["Color"], normal.inputs["Color"])
        links.new(normal.outputs["Normal"], bsdf.inputs["Normal"])
    if name == "lamp_on":
        bsdf.inputs["Emission Color"].default_value = (.14,.12,.07,1)
        bsdf.inputs["Emission Strength"].default_value = .1
    return mat


def main(args):
    args.output.mkdir(parents=True, exist_ok=True)
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    data = np.load(args.mesh)
    metadata = json.loads(args.metadata.read_text())
    mesh = bpy.data.meshes.new("Private source mesh, not distributed")
    mesh.from_pydata(data["vertices"].tolist(), [], data["triangles"].tolist())
    mesh.update()
    model = bpy.data.objects.new("T-72 Ural — supplied model", mesh)
    bpy.context.collection.objects.link(model)
    cache = {}
    for slot in metadata["materials"]:
        name = resolve(slot["name"])
        if name not in cache: cache[name] = shader(name, args)
        mesh.materials.append(cache[name])
    mesh.polygons.foreach_set("material_index", data["materials"])
    mesh.polygons.foreach_set("use_smooth", [True] * len(mesh.polygons))
    uv = mesh.uv_layers.new(name="SourceUV")
    indices = np.zeros(len(mesh.loops), dtype=np.int32)
    mesh.loops.foreach_get("vertex_index", indices)
    uv.data.foreach_set("uv", data["uv"][indices].ravel())

    bpy.ops.mesh.primitive_plane_add(size=1800, location=(0,0,-.6))
    plane = bpy.context.object
    ground = bpy.data.materials.new("Neutral studio floor")
    ground.use_nodes = True
    g = ground.node_tree.nodes.get("Principled BSDF")
    g.inputs["Base Color"].default_value = (.12,.125,.115,1)
    g.inputs["Roughness"].default_value = .95
    plane.data.materials.append(ground)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = args.samples
    scene.cycles.use_denoising = False  # OIDN unavailable on this cloud worker.
    scene.world.color = (.35,.35,.35)
    for location, energy, size in [((100,-200,600),3500000,400),((-200,300,350),2000000,300)]:
        light = bpy.data.lights.new("Studio area", "AREA")
        light.energy, light.shape, light.size = energy, "DISK", size
        ob = bpy.data.objects.new("Studio area", light)
        bpy.context.collection.objects.link(ob)
        ob.location = location
        ob.rotation_euler = (Vector((0,0,60)) - ob.location).to_track_quat("-Z","Y").to_euler()
    camera = bpy.data.objects.new("Camera", bpy.data.cameras.new("Camera"))
    bpy.context.collection.objects.link(camera)
    scene.camera = camera
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = 500
    scene.render.resolution_x = 1600
    scene.render.resolution_y = 1000
    scene.render.resolution_percentage = 100
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "Medium High Contrast"
    scene.view_settings.exposure = 0
    scene.view_settings.gamma = 1
    # Camera-attached emission label visibly distinguishes this from a game shot.
    label_curve = bpy.data.curves.new("Preview label", "FONT")
    label_curve.body = "T-72 URAL / BLENDER MATERIAL PREVIEW — NOT IN-GAME"
    label_curve.size = 4.5
    font = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
    if font.exists(): label_curve.font = bpy.data.fonts.load(str(font))
    label = bpy.data.objects.new("Preview label", label_curve)
    bpy.context.collection.objects.link(label)
    label.parent = camera
    label.location = (-237,-146,-200)
    emission = bpy.data.materials.new("Preview label emission")
    emission.use_nodes = True
    n = emission.node_tree.nodes
    n.clear()
    e = n.new("ShaderNodeEmission")
    e.inputs["Color"].default_value = (.7,.73,.65,1)
    emission.node_tree.links.new(e.outputs[0], n.new("ShaderNodeOutputMaterial").inputs[0])
    label.data.materials.append(emission)
    for name, location, target in [("front",(480,-550,330),(15,0,65)),
                                  ("rear",(-430,510,280),(0,0,60))]:
        camera.location = location
        camera.rotation_euler = (Vector(target)-camera.location).to_track_quat("-Z","Y").to_euler()
        scene.render.filepath = str(args.output / ("t72_ural_0.2_" + name + ".png"))
        bpy.ops.render.render(write_still=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(args.output / "t72_ural_private_preview.blend"))


if __name__ == "__main__":
    main(parse_args())
