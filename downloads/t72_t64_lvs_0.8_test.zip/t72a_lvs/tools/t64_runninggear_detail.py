"""Original detailed T-64A running gear, expressed in the author's mesh API.

All shapes are authored here: no imported mesh or sampled texture is used.
The paired road wheels are dished steel pressings with a narrow resilient rim.
Track shoes, grousers, guide horns and hinge ends have actual geometry.
"""
from __future__ import annotations
import math


def _add(a, b): return tuple(x+y for x,y in zip(a,b))
def _sub(a, b): return tuple(x-y for x,y in zip(a,b))
def _mul(a, t): return tuple(x*t for x in a)
def _dot(a, b): return sum(x*y for x,y in zip(a,b))
def _cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def _unit(a):
    d=math.sqrt(_dot(a,a));return _mul(a,1/d) if d>1e-12 else (0,0,1)


def _lathe(api, part, material, center, profile, sides=32):
    """Closed, smooth-around-axis lathe about Y; profile=(axial offset,radius)."""
    area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(profile,profile[1:]+profile[:1]))
    orientation=1 if area>0 else -1
    for a,b in zip(profile,profile[1:]+profile[:1]):
        dy,dr=b[0]-a[0],b[1]-a[1]
        for i in range(sides):
            t0,t1=i*math.tau/sides,(i+1)*math.tau/sides
            def v(p,t):return (center[0]+p[1]*math.cos(t),center[1]+p[0],center[2]+p[1]*math.sin(t))
            def n(t):return _unit((-dy*math.cos(t)*orientation,dr*orientation,-dy*math.sin(t)*orientation))
            vertices=[v(a,t0),v(a,t1),v(b,t1),v(b,t0)]
            normals=[n(t0),n(t1),n(t1),n(t0)]
            if _dot(_cross(_sub(vertices[1],vertices[0]),_sub(vertices[2],vertices[0])),normals[0])<0:
                vertices.reverse();normals.reverse()
            api.quad(part,material,*vertices,normals=normals)


def _local(center, tangent, normal, point):
    return _add(center,_add(_mul(tangent,point[0]),_add((0,point[1],0),_mul(normal,point[2]))))


def _oriented_box(api, part, mat, center, tangent, normal, dimensions):
    a,b,c=(v*.5 for v in dimensions)
    vertices=[_local(center,tangent,normal,p) for p in
        [(-a,-b,-c),(a,-b,-c),(a,b,-c),(-a,b,-c),(-a,-b,c),(a,-b,c),(a,b,c),(-a,b,c)]]
    for ids in ((0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)):
        api.quad(part,mat,*[vertices[i] for i in ids])


def _pressed_rib(api,part,x,y,z,angle,side):
    # A pressed ridge follows the sloped dish rather than floating over it.
    def p(r,a,depth):return (x+r*math.cos(a),y+side*depth,z+r*math.sin(a))
    lower=[p(5.4,angle-.065,5.8),p(11.4,angle-.035,3.5),
           p(11.4,angle+.035,3.5),p(5.4,angle+.065,5.8)]
    upper=[(a,b+side*.36,c) for a,b,c in lower]
    vertices=lower+upper
    # This is a sealed narrow embossing. Orient all sides away from its center.
    centre=tuple(sum(v[j] for v in vertices)/8 for j in range(3))
    for ids in ((0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)):
        vs=[vertices[i] for i in ids]
        mean=tuple(sum(v[j] for v in vs)/4 for j in range(3))
        if _dot(_cross(_sub(vs[1],vs[0]),_sub(vs[2],vs[0])),_sub(mean,centre))<0:vs.reverse()
        api.quad(part,'darksteel',*vs)


def _pocketed_face(api,part,x,y,z,side,inner=4.25,outer=12.65,
                   pocket_ring=8.2,pocket_radius=2.18,count=6,depth=1.85,
                   shallow=False):
    """A pressed wheel disk with real round depressions, tessellated in sectors.

    Each wedge is a curved annular sector with a circular recessed well. Rays
    from that well find the exact inner/outer/sector boundaries, leaving no
    flat disk behind the depressed surface and no overlapping decal circles.
    """
    half=math.pi/count
    # Include each sector's four exact boundary corners. Uniform rays alone
    # cut these corners off and leave tiny triangular gaps between sectors.
    angles={i*math.tau/12 for i in range(12)}
    for radius in (inner,outer):
        for sign in (-1,1):
            angles.add(math.atan2(sign*radius*math.sin(half),
                radius*math.cos(half)-pocket_ring)%math.tau)
    angles=sorted(angles)
    def face_depth(r):return 6.15-(r-inner)*(.14 if shallow else .285)
    def boundary(theta):
        co,si=math.cos(theta),math.sin(theta)
        values=[-pocket_ring*co+math.sqrt(max(0,outer*outer-pocket_ring*pocket_ring*si*si))]
        disc=inner*inner-pocket_ring*pocket_ring*si*si
        if disc>=0:
            t=-pocket_ring*co-math.sqrt(disc)
            if t>1e-6:values.append(t)
        tangent=math.tan(half)
        for sign in (-1,1):
            den=si-sign*co*tangent
            if abs(den)>1e-9:
                t=sign*pocket_ring*tangent/den
                if t>1e-6:values.append(t)
        return min(values)
    def q(a,theta,radius,depression):
        u=pocket_ring+radius*math.cos(theta);v=radius*math.sin(theta)
        radial=math.hypot(u,v)
        return (x+u*math.cos(a)-v*math.sin(a),
                y+side*(face_depth(radial)-depression),
                z+u*math.sin(a)+v*math.cos(a))
    def emit(mat,verts):
        if _cross(_sub(verts[1],verts[0]),_sub(verts[2],verts[0]))[1]*side<0:verts.reverse()
        if len(verts)==3:api.triangle(part,mat,*verts)
        else:api.quad(part,mat,*verts)
    for k in range(count):
        a=(k+.5)*math.tau/count
        for i,t0 in enumerate(angles):
            t1=angles[(i+1)%len(angles)]
            if i==len(angles)-1:t1+=math.tau
            b0,b1=boundary(t0),boundary(t1)
            # The road wheels have solid, shallow stamped lands rather than
            # the deep black wells that made the earlier disk read as spokes.
            shoulder=.16 if shallow else .38
            shoulder_depth=depth*.35 if shallow else .38
            rings=[((b0,0),(b1,0)),
                   ((pocket_radius+shoulder,0),(pocket_radius+shoulder,0)),
                   ((pocket_radius,shoulder_depth),(pocket_radius,shoulder_depth)),
                   ((pocket_radius-.28,depth),(pocket_radius-.28,depth))]
            for j,(ra,rb) in enumerate(zip(rings,rings[1:])):
                verts=[q(a,t0,*ra[0]),q(a,t1,*ra[1]),q(a,t1,*rb[1]),q(a,t0,*rb[0])]
                emit('armor',verts)
            center=(x+pocket_ring*math.cos(a),y+side*(face_depth(pocket_ring)-depth),z+pocket_ring*math.sin(a))
            emit('armor' if shallow else 'darksteel',[center,q(a,t0,pocket_radius-.28,depth),q(a,t1,pocket_radius-.28,depth)])


def _pressed_road_face(api,part,x,y,z,side):
    """Continuous steel bowl, with closed stamped depressions, not drilled holes.

    The six strengthening impressions share complete concentric boundary rings.
    A single polar surface avoids detached inset circles and sector corner gaps.
    """
    rings=[4.45,5.35,6.7,7.65,8.3,9.0,9.7,10.55,11.8,13.0,13.75]
    profile=[(4.45,6.15),(5.35,5.20),(6.7,4.30),(9.0,3.80),
             (11.8,4.25),(13.0,4.85),(13.75,5.60)]
    sectors=48
    def depth(radius,angle):
        value=profile[-1][1]
        for a,b in zip(profile,profile[1:]):
            if radius<=b[0]:
                t=max(0,min(1,(radius-a[0])/(b[0]-a[0])))
                # Soft transitions represent a pressed sheet rather than a
                # machined series of conical steps.
                t=t*t*(3-2*t)
                value=a[1]+(b[1]-a[1])*t
                break
        # Six shallow closed oval pressings sit in the bowl. The depression is
        # painted steel throughout; it has no black plug or radial spoke.
        phase=(angle-math.pi/6+math.pi/6)%(math.pi/3)-math.pi/6
        q=((radius-9.0)/1.72)**2+(phase/(1.6/9.0))**2
        if q<1:value-=.66*(1-q)**2
        return value
    def at(radius,angle):
        return (x+radius*math.cos(angle),y+side*depth(radius,angle),z+radius*math.sin(angle))
    def normal(radius,angle):
        e=.002
        dr=_sub(at(radius+e,angle),at(radius-e,angle))
        da=_sub(at(radius,angle+e),at(radius,angle-e))
        n=_unit(_cross(da,dr))
        return n if side>0 else _mul(n,-1)
    for r0,r1 in zip(rings,rings[1:]):
        for i in range(sectors):
            a0=i*math.tau/sectors;a1=(i+1)*math.tau/sectors
            coordinates=[(r0,a0),(r0,a1),(r1,a1),(r1,a0)]
            vertices=[at(*p) for p in coordinates]
            normals=[normal(*p) for p in coordinates]
            if side<0:vertices.reverse();normals.reverse()
            api.quad(part,'armor',*vertices,normals=normals)


def _roadwheel(api,part,x,y,z,side):
    # Small internally cushioned T-64-style steel pressings, with paired narrow
    # running bands and a deep guide-horn channel. The outer face is a bowl.
    profile=[(-5.15,4.5),(-2.95,13.3),(-5.15,14.15),(-2.05,14.15),
             (-1.8,10.2),(1.8,10.2),(2.05,14.15),(5.15,14.15),
             (2.95,13.3),(1.9,13.3),(1.9,4.5)]
    _lathe(api,part,'armor',(x,y,z),[(side*axial,radius) for axial,radius in profile],32)
    for sign in (-1,1):
        _lathe(api,part,'rubber',(x,y,z),[
            (sign*2.0,14.15),(sign*2.25,15.0),
            (sign*4.95,15.0),(sign*5.25,14.15)],32)
        _lathe(api,part,'armor',(x,y,z),[
            (sign*4.5,13.55),(sign*5.75,14.3),
            (sign*5.55,14.55),(sign*4.95,14.65)],32)
    _pressed_road_face(api,part,x,y,z,side)
    api.cylinder(part,'darksteel',(x,y-5.55,z),(x,y+5.55,z),4.55,24)
    api.cylinder(part,'armor',(x,y+side*5.55,z),(x,y+side*6.35,z),4.45,24)
    _lathe(api,part,'armor',(x,y,z),[(side*6.35,4.10),(side*6.65,3.7),
        (side*7.10,3.0),(side*7.25,.35),(side*6.35,.35)],32)
    # Small fasteners are on the inner raised flange, outside the domed cap.
    for i in range(6):
        a=i*math.tau/6
        xx,zz=x+5.0*math.cos(a),z+5.0*math.sin(a)
        api.cylinder(part,'darksteel',(xx,y+side*5.4,zz),(xx,y+side*5.85,zz),.60,6)
    api.cylinder(part,'darksteel',(x+1.15,y+side*7.25,z+.65),(x+1.15,y+side*7.48,z+.65),.43,6)


def _idler(api,part,x,y,z,side):
    _lathe(api,part,'armor',(x,y,z),[
        (-5.6,3.2),(-2.1,3.2),(-2.1,11.5),(-6.0,12.8),
        (-6.2,13.8),(6.2,13.8),(6.0,12.8),(2.1,11.5),(2.1,3.2),(5.6,3.2)],28)
    # Two contact bands with a recessed guide channel in between.
    for yy in (-5.5,5.5):
        _lathe(api,part,'darksteel',(x,y+yy,z),[(-1.0,13.3),(-.75,14.15),(.75,14.15),(1.0,13.3)],28)
    _pocketed_face(api,part,x,y,z,side,inner=3.7,outer=12.5,pocket_ring=8.1,pocket_radius=2.4,count=6,depth=2.0)
    api.cylinder(part,'armor',(x,y-6.6,z),(x,y+6.6,z),3.5,28)
    api.cylinder(part,'darksteel',(x,y+side*6.6,z),(x,y+side*7.15,z),2.5,24)
    for i in range(6):
        a=i*math.tau/6
        xx,zz=x+4.0*math.cos(a),z+4.0*math.sin(a)
        api.cylinder(part,'darksteel',(xx,y+side*5.6,zz),(xx,y+side*6.2,zz),.62,6)


def _toothed_ring(api,part,x,y,z,offset):
    n=60
    radii=[14.4 if i%5 in (1,2) else 12.25 for i in range(n)]
    for i in range(n):
        j=(i+1)%n; a,b=i*math.tau/n,j*math.tau/n
        # A proper annular star profile, with discrete tooth tips and roots.
        points=[]
        for yy,radius,t in ((offset-.95,radii[i],a),(offset-.95,radii[j],b),
                            (offset+.95,radii[j],b),(offset+.95,radii[i],a)):
            points.append((x+radius*math.cos(t),y+yy,z+radius*math.sin(t)))
        target=(math.cos((a+b)*.5),0,math.sin((a+b)*.5))
        if i==n-1:target=(math.cos(a+math.pi/n),0,math.sin(a+math.pi/n))
        if _dot(_cross(_sub(points[1],points[0]),_sub(points[2],points[0])),target)<0:points.reverse()
        api.quad(part,'darksteel',*points)
        for sign in (-1,1):
            yy=y+offset+sign*.95
            vs=[(x+7.7*math.cos(a),yy,z+7.7*math.sin(a)),(x+7.7*math.cos(b),yy,z+7.7*math.sin(b)),
                (x+radii[j]*math.cos(b),yy,z+radii[j]*math.sin(b)),(x+radii[i]*math.cos(a),yy,z+radii[i]*math.sin(a))]
            if _cross(_sub(vs[1],vs[0]),_sub(vs[2],vs[0]))[1]*sign<0:vs.reverse()
            api.quad(part,'darksteel',*vs)


def _sprocket(api,part,x,y,z,side):
    _lathe(api,part,'armor',(x,y,z),[(-7.2,3.2),(-5.4,7.8),(-2.0,10.5),
        (2.0,10.5),(5.4,7.8),(7.2,3.2)],40)
    for offset in (-6.2,6.2):_toothed_ring(api,part,x,y,z,offset)
    api.cylinder(part,'armor',(x,y-7.8,z),(x,y+7.8,z),4.3,32)
    for i in range(8):
        a=i*math.tau/8
        xx,zz=x+6.35*math.cos(a),z+6.35*math.sin(a)
        api.cylinder(part,'darksteel',(xx,y+side*5.2,zz),(xx,y+side*6.0,zz),.82,6)
    api.cylinder(part,'darksteel',(x,y+side*7.8,z),(x,y+side*8.25,z),3.1,24)


def _track_segments():
    # Rounded convex path about raised end wheels and the low road wheels.
    # In side view there are long inclined lower runs; it is not a capsule
    # with two large end wheels that almost scrape the ground.
    centers=[(-140.,33.3),(151.,33.3),(112.,19.5),(-98.,19.5)]
    # The chassis builder shortens the belt in X but leaves round wheels round.
    # This extra clearance keeps the squeezed end arcs outside the idler teeth.
    radius=16.5
    segments=[]
    for i,a in enumerate(centers):
        b=centers[(i+1)%4];c=centers[(i+2)%4]
        dx,dz=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dz)
        t=(dx/length,0,dz/length);normal=(-t[2],t[0])
        start=(a[0]+radius*normal[0],a[1]+radius*normal[1])
        end=(b[0]+radius*normal[0],b[1]+radius*normal[1])
        segments.append(('line',length,start,end))
        ndx,ndz=c[0]-b[0],c[1]-b[1];nl=math.hypot(ndx,ndz)
        nnext=(-ndz/nl,ndx/nl)
        angle=math.atan2(normal[1],normal[0]);next_angle=math.atan2(nnext[1],nnext[0])
        sweep=(angle-next_angle)%math.tau
        segments.append(('arc',sweep*radius,b,angle))
    return segments,radius


_TRACK_SEGMENTS,_TRACK_RADIUS=_track_segments()
_TRACK_LENGTH=sum(s[1] for s in _TRACK_SEGMENTS)


def _path(distance):
    s=distance%_TRACK_LENGTH
    for kind,length,a,b in _TRACK_SEGMENTS:
        if s<=length+1e-8:
            if kind=='line':
                tangent=((b[0]-a[0])/length,0,(b[1]-a[1])/length)
                return (a[0]+tangent[0]*s,a[1]+tangent[2]*s),tangent
            angle=b-s/_TRACK_RADIUS
            return (a[0]+_TRACK_RADIUS*math.cos(angle),a[1]+_TRACK_RADIUS*math.sin(angle)),(math.sin(angle),0,-math.cos(angle))
        s-=length
    return _path(0)


def _shoe(api,part,y,distance,pitch):
    (x,z),tangent=_path(distance)
    normal=(-tangent[2],0,tangent[0]);center=(x,y,z)
    # Chamfered eight-sided shoe with thickness, separated hinge gaps.
    length= pitch-.48; half=length*.5; wide=14.8; bevel=1.15
    outline=[(-half+bevel,-wide),(half-bevel,-wide),(half,-wide+bevel),
             (half,wide-bevel),(half-bevel,wide),(-half+bevel,wide),
             (-half,wide-bevel),(-half,-wide+bevel)]
    lower=[_local(center,tangent,normal,(a,b,-.8)) for a,b in outline]
    upper=[_local(center,tangent,normal,(a*.98,b*.98,.55)) for a,b in outline]
    def uv(v):
        q=_sub(v,center)
        return ((distance+_dot(q,tangent))/10,(_dot(q,(0,1,0))+wide)/(wide*2))
    for i in range(8):
        j=(i+1)%8
        api.triangle(part,'tracks',center,upper[i],upper[j],uv=[uv(center),uv(upper[i]),uv(upper[j])])
        base=_local(center,tangent,normal,(0,0,-.8))
        api.triangle(part,'darksteel',base,lower[j],lower[i])
        api.quad(part,'darksteel',lower[i],lower[j],upper[j],upper[i])
    # A narrow full-width traction bar, plus the two offset shoulders of the
    # hinge castings. The silhouette stays metal shoe, not a black rubber pad.
    _oriented_box(api,part,'darksteel',_local(center,tangent,normal,(.25,0,.94)),tangent,normal,(1.2,27.8,.8))
    for sign in (-1,1):
        _oriented_box(api,part,'darksteel',_local(center,tangent,normal,(-half+.7,sign*10.3,.55)),tangent,normal,(1.2,6.4,.5))
    # Guide horn: a tapered triangular prism, actually visible inside each link.
    local=[(-2,-2.0,-.8),(2,-2.0,-.8),(0,-1.2,-4.2),(-2,2.0,-.8),(2,2.0,-.8),(0,1.2,-4.2)]
    vertices=[_local(center,tangent,normal,p) for p in local]
    centroid=tuple(sum(v[j] for v in vertices)/6 for j in range(3))
    for ids in ((0,2,1),(3,4,5),(0,1,4,3),(1,2,5,4),(2,0,3,5)):
        vs=[vertices[i] for i in ids];middle=tuple(sum(v[j] for v in vs)/len(vs) for j in range(3))
        if _dot(_cross(_sub(vs[1],vs[0]),_sub(vs[2],vs[0])),_sub(middle,centroid))<0:vs.reverse()
        (api.triangle if len(vs)==3 else api.quad)(part,'darksteel',*vs)
    # Hinge/pin ends at both exposed edges, with small face plugs.
    for sign in (-1,1):
        a=_local(center,tangent,normal,(-half+.55,sign*13.2,-.1))
        b=_local(center,tangent,normal,(-half+.55,sign*15.2,-.1))
        api.cylinder(part,'darksteel',a,b,1.02,6)


def build(api):
    """Add detailed authored components to the main builder's registered parts."""
    # Body height changes must not stretch suspension or lift the return rollers
    # off the belt. The chassis builder shortens this group only along X.
    api.part('gear_fixed','hull',(0,0,0))
    for side,label,y,sign in [('Left','L',77,1),('Right','R',-77,-1)]:
        for i,x in enumerate([112,70,28,-14,-56,-98],1):
            wheelpart=f'wheel_{label}{i}'
            api.part(wheelpart,'wheel',(x,y,19.5),side)
            api.PARTS[wheelpart]['Radius']=15
            _roadwheel(api,wheelpart,x,y,19.5,sign)
            # Torsion-arm casting and shock body are fixed to the hull.
            api.cylinder('gear_fixed','armor',(x-12,sign*64,30.5),(x-3,sign*70,20.5),2.15,12)
            api.cylinder('gear_fixed','armor',(x-3,sign*70,20.5),(x,sign*70,19.5),2.6,12)
            api.cylinder('gear_fixed','darksteel',(x-12,sign*63,30.5),(x-12,sign*70,30.5),3.0,16)
            api.cylinder('gear_fixed','armor',(x-12,sign*70,30.5),(x-12,sign*70.6,30.5),2.3,16)
            if i in (1,2,6):
                api.cylinder('gear_fixed','darksteel',(x-8,sign*65,38),(x+2,sign*70,21.5),1.65,12)
                api.cylinder('gear_fixed','darksteel',(x-8,sign*65,38),(x-3,sign*67.5,29.5),2.15,12)
        for name,x,function in [('idler',151,_idler),('sprocket',-140,_sprocket)]:
            partname=f'{name}_{label}'
            api.part(partname,'wheel',(x,y,33.3),side)
            api.PARTS[partname]['Radius']=14.2
            function(api,partname,x,y,33.3,sign)
            # Axle/tensioner connects the high end wheel to the hull side.
            api.cylinder('gear_fixed','armor',(x-6,sign*62,33.3),(x,sign*72,33.3),3.0,16)
        # Three return rollers with their own brackets and dished caps.
        for x in (-91,-6,78):
            api.cylinder('gear_fixed','darksteel',(x,sign*62,43.2),(x,sign*76,43.2),1.6,12)
            _lathe(api,'gear_fixed','rubber',(x,y,43.2),[(-6,2.1),(-5.4,5.4),(5.4,5.4),(6,2.1)],20)
            api.cylinder('gear_fixed','armor',(x,y+sign*6.1,43.2),(x,y+sign*6.5,43.2),2.4,16)
        total=_TRACK_LENGTH;count=76; pitch=total/count
        for i in range(count):_shoe(api,'track_'+side.lower(),y,(i+.5)*pitch,pitch)

