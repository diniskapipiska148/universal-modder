"""Read Source MDL/VVD rig metadata using an external SourceIO checkout.
All derived model data is written outside the addon by an explicit output path.
"""
import sys, types, pathlib, json
import numpy as np
sourceio, modelbase, output = sys.argv[1:4]
module = types.ModuleType('SourceIO'); module.__path__ = [sourceio]; sys.modules['SourceIO'] = module
from SourceIO.library.models.mdl.v49.mdl_file import MdlV49
from SourceIO.library.models.vvd import Vvd
from SourceIO.library.utils import FileBuffer
mdl = MdlV49.from_buffer(FileBuffer(modelbase + '.mdl'))
vvd = Vvd.from_buffer(FileBuffer(modelbase + '.vvd'))
vertices = vvd.lod_data[0]
world = []
C = np.array([[0.,-1,0,0],[1,0,0,0],[0,0,1,0],[0,0,0,1]])
report = {'coordinate_adapter':'native to canonical yaw +90 degrees', 'bones':[], 'materials':[m.name for m in mdl.materials], 'bodyparts':[], 'skins':[[m.name for m in skin] for skin in mdl.skin_groups]}
def bounds(v):
 if not len(v): return None
 return {'mins':v.min(axis=0).tolist(), 'maxs':v.max(axis=0).tolist(), 'center':((v.min(axis=0)+v.max(axis=0))/2).tolist()}
for i,b in enumerate(mdl.bones):
 local = b.matrix
 matrix = world[b.parent_id] @ local if b.parent_id >= 0 else local
 world.append(matrix)
 mask = ((vertices['bone_id'] == i) & (vertices['weight'] > .001)).any(axis=1)
 points = vertices['vertex'][mask]
 canonical = points @ C[:3,:3].T
 report['bones'].append({'id':i,'name':b.name,'parent':b.parent_id,'local_matrix':local.tolist(),'world_native':matrix.tolist(),'world_canonical':(C @ matrix).tolist(),'local_angles_radians':list(b.rotation),'local_quat_xyzw':list(b.quat),'vertex_count':int(mask.sum()),'native_weighted_bounds':bounds(points),'canonical_weighted_bounds':bounds(canonical)})
for body in mdl.body_parts:
 items=[]
 for model in body.models:
  points=vertices['vertex'][model.vertex_offset:model.vertex_offset+model.vertex_count]
  items.append({'name':model.name,'start':model.vertex_offset,'count':model.vertex_count,'native_bounds':bounds(points),'canonical_bounds':bounds(points @ C[:3,:3].T)})
 report['bodyparts'].append({'name':body.name,'models':items})
report['all_native_bounds']=bounds(vertices['vertex'])
report['all_canonical_bounds']=bounds(vertices['vertex']@C[:3,:3].T)
pathlib.Path(output).write_text(json.dumps(report,indent=2))
for b in report['bones']:
 if b['id'] in [0,1,2,13,21,29,30,31,32,33,34]:
  print(b['id'],b['name'],'parent',b['parent'],'native',np.round(np.array(b['world_native'])[:3,3],5),'canon',np.round(np.array(b['world_canonical'])[:3,3],5),'localRot',b['local_angles_radians'],'worldRot',np.round(np.array(b['world_native'])[:3,:3],5).tolist(),'bounds',b['canonical_weighted_bounds'])
print('BODY PARTS',json.dumps(report['bodyparts']))
print('Wrote',output)
