#!/usr/bin/env python3
"""Verify the actual MDL's first-sequence skinning frame and cannon muzzle.

Usage: python verify_runtime_pose.py /path/to/SourceIO /path/to/model_without_ext
External model data stays external. Requires numpy and a separate SourceIO tree.
"""
from __future__ import annotations
import json
from pathlib import Path
import sys
import types
import numpy as np


def main(sourceio: str, modelbase: str) -> dict:
    package = types.ModuleType("SourceIO")
    package.__path__ = [sourceio]
    sys.modules["SourceIO"] = package
    from SourceIO.library.models.mdl.v49.mdl_file import MdlV49
    from SourceIO.library.models.vvd import Vvd
    from SourceIO.library.utils import FileBuffer
    from SourceIO.library.utils.math_utilities import quat_to_matrix
    mdl = MdlV49.from_buffer(FileBuffer(modelbase + ".mdl"))
    vvd = Vvd.from_buffer(FileBuffer(modelbase + ".vvd"))
    animation = mdl.animations[0]
    posed = []
    skins = []
    for bone in mdl.bones:
        local = bone.matrix
        if bone.name in animation:
            frame = animation[bone.name][0]
            local = np.eye(4)
            local[:3, :3] = quat_to_matrix(frame["rot"])
            local[:3, 3] = frame["pos"]
        world = posed[bone.parent_id] @ local if bone.parent_id >= 0 else local
        posed.append(world)
        pose_to_bone = np.eye(4)
        pose_to_bone[:3, :] = bone.pose_to_bone.T
        skins.append(world @ pose_to_bone)
    expected = np.array([[0., -1., 0., 0.], [1., 0., 0., 0.],
                         [0., 0., 1., 0.], [0., 0., 0., 1.]])
    max_error = max(float(np.abs(skin - expected).max()) for skin in skins)
    assert max_error < .002, ("unexpected first-sequence skin frame", max_error)
    barrel_id = next(i for i, b in enumerate(mdl.bones) if b.name == "Barrel")
    vertices = vvd.lod_data[0]
    mask = ((vertices["bone_id"] == barrel_id) & (vertices["weight"] > .001)).any(axis=1)
    raw = vertices["vertex"][mask]
    ring = raw[raw[:, 1] < raw[:, 1].min() + .001]
    centre = (ring.min(axis=0) + ring.max(axis=0)) * .5
    runtime_centre = skins[barrel_id] @ np.append(centre, 1)
    result = {
        "model": Path(modelbase).name,
        "first_sequence_root_quaternion": animation[mdl.bones[0].name][0]["rot"].tolist(),
        "root_skin_delta": skins[0].tolist(),
        "all_bones_match_runtime_yaw_plus_90_max_error": max_error,
        "raw_bind_muzzle": centre.tolist(),
        "runtime_muzzle": runtime_centre[:3].tolist(),
        "required_additional_visual_yaw": 0,
    }
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    main(*sys.argv[1:3])
