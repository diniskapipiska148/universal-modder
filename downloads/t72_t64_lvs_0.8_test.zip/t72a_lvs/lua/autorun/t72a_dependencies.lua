if SERVER then
    AddCSLuaFile()
    resource.AddWorkshop("2912816023")
    resource.AddFile("materials/entities/lvs_t64a_1971.png")
    -- T-64A is self-contained apart from LVS. Mount the old model dependency
    -- for clients only when the server actually has the optional T-72 model.
    if file.Exists("models/damik/ussr/t-72 ural/t-72 ural (prop).mdl", "GAME") then
        resource.AddWorkshop("2884416595")
    end
    for _, folder in ipairs({"materials/t72a_ural/", "materials/t64a_1971/", "sound/t72a_ural/", "sound/t64a_1971/"}) do
        for _, name in ipairs(file.Find(folder .. "*", "GAME")) do
            resource.AddFile(folder .. name)
        end
    end
end
-- Read-only diagnostic, usable without lua_run or elevated server privileges.
concommand.Add("t72a_check", function(ply)
    local function report(message)
        message = "[T-72 Ural] " .. message
        print(message)
        if SERVER and IsValid(ply) then ply:PrintMessage(HUD_PRINTCONSOLE, message) end
    end
    report("realm: " .. (SERVER and "server" or "client"))
    local base = scripted_ents.GetStored("lvs_tank_wheeldrive")
    report("LVS tank base: " .. (base and "OK" or "MISSING"))
    local mdl = "models/damik/ussr/t-72 ural/t-72 ural (prop).mdl"
    report("model: " .. (file.Exists(mdl, "GAME") and "OK" or "MISSING") .. " | " .. mdl)
    for _, ext in ipairs({"vvd", "dx90.vtx", "phy"}) do
        local path = mdl:sub(1, -5) .. "." .. ext
        report(ext .. ": " .. (file.Exists(path, "GAME") and "OK" or "MISSING"))
    end
    report("new texture: " .. (file.Exists("materials/t72a_ural/olive.vtf", "GAME") and "OK" or "MISSING"))
    report("spawn class: lvs_t72a | category: [LVS] - Т-72 Урал")
end)
concommand.Add("t64a_check", function(ply)
    local function report(message)
        message = "[T-64A 1971] " .. message
        print(message)
        if SERVER and IsValid(ply) then ply:PrintMessage(HUD_PRINTCONSOLE, message) end
    end
    report("LVS tank base: " .. (scripted_ents.GetStored("lvs_tank_wheeldrive") and "OK" or "MISSING"))
    report("generated geometry: " .. (file.Exists("t64a_1971/geometry/index.lua", "LUA") and "OK" or "MISSING"))
    report("material: " .. (file.Exists("materials/t64a_1971/armor.vmt", "GAME") and "OK" or "MISSING"))
    report("loader sound: " .. (file.Exists("sound/t64a_1971/loader.wav", "GAME") and "OK" or "MISSING"))
    report("spawn class: lvs_t64a_1971")
end)
