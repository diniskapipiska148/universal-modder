-- Local diagnostic only; never downloads assets or changes an installed game.
concommand.Add("t72a_model_report", function(_, _, args)
    local path = args[1]
    if not path or not path:match("^models/.+%.mdl$") or path:find("..", 1, true) then
        print("Usage: t72a_model_report models/path/to/tank.mdl")
        return
    end
    if not file.Exists(path, "GAME") then
        print("T72A: model is not mounted: " .. path)
        return
    end
    local model = ClientsideModel(path, RENDERGROUP_OTHER)
    if not IsValid(model) then
        print("T72A: cannot create model: " .. path)
        return
    end
    model:SetNoDraw(true)
    model:SetPos(vector_origin)
    model:SetAngles(angle_zero)
    model:SetupBones()
    local low, high = model:GetModelBounds()
    local report = {model = path, bounds = {mins = low, maxs = high},
        attachments = {}, poses = {}, bones = {}, materials = model:GetMaterials(),
        bodygroups = model:GetBodyGroups()}
    for _, entry in ipairs(model:GetAttachments() or {}) do
        local att = model:GetAttachment(entry.id)
        report.attachments[#report.attachments + 1] = {
            name = entry.name, id = entry.id, pos = att and att.Pos, ang = att and att.Ang
        }
    end
    for id = 0, model:GetNumPoseParameters() - 1 do
        local minimum, maximum = model:GetPoseParameterRange(id)
        report.poses[#report.poses + 1] = {
            name = model:GetPoseParameterName(id), min = minimum, max = maximum
        }
    end
    for id = 0, model:GetBoneCount() - 1 do
        report.bones[#report.bones + 1] = {id = id, name = model:GetBoneName(id)}
    end
    model:Remove()
    file.CreateDir("t72a")
    file.Write("t72a/model_report.json", util.TableToJSON(report, true))
    print("T72A: saved garrysmod/data/t72a/model_report.json")
end)
