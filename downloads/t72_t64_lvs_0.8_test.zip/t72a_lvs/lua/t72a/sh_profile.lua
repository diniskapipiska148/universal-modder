-- Measured from the user's Damik T-72 Ural MDL49/VVD; see MODEL_NOTES.md.
-- Raw VVD bind geometry faces -Y; sequence 0 already rotates it +90 into +X.
-- Do NOT add another visual yaw: that made v0.1 drive sideways and fire beside the turret.
local left, right, wheelBones = {}, {}, {Left = {}, Right = {}}
for i, x in ipairs({81.960,47.516,13.856,-19.828,-53.256,-86.840}) do
    left[i], right[i] = Vector(x,57.322,18.292), Vector(x,-57.322,18.292)
    wheelBones.Left[i], wheelBones.Right[i] = "[wheels] L"..i, "[wheels] R"..i
end
return {
    Ready = true, WorkshopID = "2884416595",
    Model = "models/damik/ussr/t-72 ural/t-72 ural (prop).mdl",
    VisualYaw = 0,
    HullMins = Vector(-167.812,-71.408,19.748),
    HullMaxs = Vector(128.280,71.524,87),
    RenderMins = Vector(-168,-77,-1), RenderMaxs = Vector(241,77,177),
    DriverSeat = {Pos = Vector(38,0,35), Ang = Angle(0,-90,0)},
    Engine = {Pos = Vector(-85,0,40), Ang = Angle(0,0,0)},
    Wheels = {Left = left, Right = right, DriveIndex = 3,
        Model = "models/props_vehicles/tire001c_car.mdl", Radius = 15.684, Width = 16.42},
    WheelBones = wheelBones,
    Suspension = {Height = 7, MaxTravel = 7, ControlArmLength = 150,
        SpringConstant = 45000, SpringDamping = 1800, SpringRelativeDamping = 2000},
    Turret = {AimRate = 16, PitchMin = -14, PitchMax = 6},
    Rig = {
        TurretBone = ">>>TURRET<<<", GunBone = ">>>GUN<<<",
        TurretPivot = Vector(-11.456,0,30.060), GunPivot = Vector(22.793,0,64.964),
        CannonMuzzle = Vector(240.478439,0.0451313,69.9407692),
        -- Gameplay coaxial socket; the model has no MG-specific attachment.
        MGMuzzle = Vector(58,-9,68.3), Sight = Vector(60,-20,92)
    }
}
