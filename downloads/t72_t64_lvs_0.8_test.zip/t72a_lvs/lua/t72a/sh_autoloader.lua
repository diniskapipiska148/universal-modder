-- Original synthesized loader cues. Emitted only by the server, spatially.
ENT.T72AutoloaderSound = "t72a_ural/autoloader.wav"
ENT.T72AutoloaderVolume = 0.65

if SERVER then
    function ENT:T72StopAutoloader()
        if self._T72LoaderSound then self:StopSound(self._T72LoaderSound) end
        self._T72LoaderSound = nil
        self._T72LoaderEnd = nil
    end

    function ENT:T72StartAutoloader(deadline)
        deadline = tonumber(deadline) or self:GetT72ReloadEnd()
        if self:GetHP() <= 0 or deadline <= CurTime() then return false end
        -- Repeated OnThink calls cannot stack/restart the same event.
        if self._T72LoaderSound and self._T72LoaderEnd == deadline then return false end
        self:T72StopAutoloader()
        self._T72LoaderSound = self.T72AutoloaderSound
        self._T72LoaderEnd = deadline
        self:EmitSound(self._T72LoaderSound, 72, 100, self.T72AutoloaderVolume, CHAN_ITEM)
        return true
    end

    function ENT:T72AutoloaderThink()
        if not self._T72LoaderSound then return end
        if self:GetHP() <= 0 or CurTime() >= self._T72LoaderEnd then self:T72StopAutoloader() end
    end

    -- Include after the stock turret module so its removal cleanup is retained.
    local previousRemoved = ENT.OnRemoved
    function ENT:OnRemoved()
        self:T72StopAutoloader()
        if previousRemoved then previousRemoved(self) end
    end
end
