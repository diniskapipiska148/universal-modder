-- Only applied with SetSubMaterial on this vehicle's local visual entity.
-- Original Workshop VMT names/files are never replaced globally.
local exact = {
    sus = "rubber", body = "olive", lights = "lamp", add_2 = "olive",
    props = "olive", add_3 = "olive", net = "darksteel", black = "rubber",
    turret = "olive", parts = "olive", gun = "olive", int = "interior",
    tracks = "tracks", skirts = "olive", ["glass alpha"] = "glass",
    antenna = "darksteel", ["lights on"] = "lamp_on", lamp = "lamp",
    ["lamp on"] = "lamp_on"
}
return {
    Resolve = function(modelMaterial)
        local name = string.lower(modelMaterial):gsub("\\", "/")
        name = name:match("([^/]+)$") or name
        name = name:gsub("%.vmt$", ""):gsub("%(%d+%)$", "")
        local replacement = exact[name] or "olive"
        return "t72a_ural/" .. replacement
    end,
    TrackMaterial = "t72a_ural/tracks"
}
