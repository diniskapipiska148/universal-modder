-- Original generated T-64A1971 game-art geometry; not an engineering survey.
local left,right={},{}
left[1]=Vector(109.76,77,19.5);right[1]=Vector(109.76,-77,19.5)
left[2]=Vector(68.6,77,19.5);right[2]=Vector(68.6,-77,19.5)
left[3]=Vector(27.44,77,19.5);right[3]=Vector(27.44,-77,19.5)
left[4]=Vector(-13.72,77,19.5);right[4]=Vector(-13.72,-77,19.5)
left[5]=Vector(-54.88,77,19.5);right[5]=Vector(-54.88,-77,19.5)
left[6]=Vector(-96.04,77,19.5);right[6]=Vector(-96.04,-77,19.5)
return {
 Ready=true,Model="models/hunter/blocks/cube025x025x025.mdl",VisualYaw=0,
 HullMins=Vector(-162,-70,29),HullMaxs=Vector(172,70,111),
 -- Include the complete yaw/pitch sweep of the long barrel, not just neutral pose.
 RenderMins=Vector(-336,-328,-4),RenderMaxs=Vector(320,328,176),
 DriverSeat={Pos=Vector(68.6,-15,49.7143),Ang=Angle(0,-90,0)},
 Engine={Pos=Vector(-93.1,0,53.6571),Ang=Angle(0,0,0)},
 Wheels={Left=left,Right=right,DriveIndex=3,Model="models/props_vehicles/tire001c_car.mdl",Radius=15,Width=14},
 Suspension={Height=7,MaxTravel=7,ControlArmLength=150,SpringConstant=42000,SpringDamping=1800,SpringRelativeDamping=2000},
 Turret={AimRate=16,PitchMin=-14,PitchMax=6},TrackUVUnits=10,
 Rig={TurretPivot=Vector(-7.84,0,76),GunPivot=Vector(40.92,0,91.64),CannonMuzzle=Vector(275.152,0,91.64),MGMuzzle=Vector(53.156,-8.28,88.88),Sight=Vector(54.72,-16.56,110.96)}
}
