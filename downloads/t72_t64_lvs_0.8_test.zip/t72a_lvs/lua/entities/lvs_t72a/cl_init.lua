include("shared.lua")
include("t72a/cl_hud.lua")
include("t72a/cl_visual.lua")
if file.Exists("entities/lvs_tank_wheeldrive/modules/cl_tankview.lua", "LUA") then
    include("entities/lvs_tank_wheeldrive/modules/cl_tankview.lua")
end

T72AHUD.SuppressBasePanels(ENT)
function ENT:LVSHudPaint(x, y, ply)
    T72AHUD.Paint(self, x, y, ply)
end

function ENT:TankViewOverride(ply, pos, angles, fov, pod)
    if pod:GetThirdPersonMode() then return pos, angles, fov end
    local origin, available = self:GetTurretViewOrigin()
    if not available then return pos, angles, fov end
    local sightFOV = ply:lvsKeyDown("ZOOM") and 25 or fov
    self.T72SightFOV = sightFOV
    return origin, angles, sightFOV
end
