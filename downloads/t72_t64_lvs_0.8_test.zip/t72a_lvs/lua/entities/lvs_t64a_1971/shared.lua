ENT.Base = "lvs_t72a"
ENT.Type = "anim"
ENT.PrintName = "Т-64А (1971)"
ENT.T72DisplayName = "Т-64А (1971)"
ENT.Author = "Original procedural tank project"
ENT.Information = "Original 1971-style T-64A geometry, LVS gameplay"
ENT.Category = "[LVS] - Т-64А (1971)"
ENT.VehicleCategory = "Tanks"
ENT.VehicleSubCategory = "Main battle tank"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.lvsShowInSpawner = true
ENT.IconOverride = "entities/lvs_t64a_1971.png"
ENT.T72A = true
ENT.T64Generated = true
ENT.T72AmmoLoadout = {18, 9, 10}
ENT.T72AutoloaderSound = "t64a_1971/loader.wav"

-- The stock cube is only an invisible engine/physics handle. Every visible
-- surface of this vehicle comes from this project's generated geometry.
ENT.T72Profile = include("t64a_1971/sh_generated_profile.lua")
ENT.MDL = ENT.T72Profile.Model
ENT.MaxHealth = 2500
ENT.MaxHealthEngine = 2500
ENT.MaxVelocity = 660
ENT.MaxVelocityReverse = 50
ENT.PhysicsMass = 3900
ENT.PhysicsInertia = Vector(12000, 12000, 3500)
ENT.TurretAimRate = 16
ENT.TurretPitchMin = -14
ENT.TurretPitchMax = 6

-- There are no Source model bones to update on this original IMesh vehicle.
function ENT:T72ApplyVisualTurret() end
function ENT:UpdatePoseParameters() end
