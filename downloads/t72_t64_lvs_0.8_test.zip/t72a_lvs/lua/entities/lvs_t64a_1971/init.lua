AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("t64a_1971/sh_generated_profile.lua")
AddCSLuaFile("t64a_1971/cl_mesh.lua")
AddCSLuaFile("t64a_1971/geometry/index.lua")
local geometry = include("t64a_1971/geometry/index.lua")
for _, path in ipairs(geometry.Chunks) do AddCSLuaFile(path) end
include("shared.lua")

function ENT:SpawnFunction(ply, trace, className)
    if not util.IsValidModel(self.MDL) then
        if IsValid(ply) then ply:ChatPrint("[T-64A] The built-in GMod physics handle is unavailable.") end
        return
    end
    return baseclass.Get("lvs_base").SpawnFunction(self, ply, trace, className)
end

function ENT:Initialize()
    if not self.T72Profile or not self.T72Profile.Ready then self:Remove() return end
    -- Base initialization dispatches the inherited canonical PhysicsInitBox,
    -- then obtains its fresh physics object and runs wheeldrive initialization.
    baseclass.Get("lvs_base").Initialize(self)
end

function ENT:OnSpawn()
    local profile = self.T72Profile
    local seat = self:AddDriverSeat(profile.DriverSeat.Pos, profile.DriverSeat.Ang)
    if not IsValid(seat) then self:Remove() return end
    seat.HidePlayer = true
    self:AddEngine(profile.Engine.Pos, profile.Engine.Ang)
end
