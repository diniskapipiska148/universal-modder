"""Validate shipped audio container, headroom and synthesis reproducibility."""
from pathlib import Path
import importlib.util
import unittest
import wave
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("loader_audio", ROOT / "tools/build_autoloader_audio.py")
audio = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audio)


class LoaderAudioTests(unittest.TestCase):
    def test_shipped_waves_are_finite_mono_pcm_and_have_headroom(self):
        for path in (ROOT/"sound/t72a_ural/autoloader.wav", ROOT/"sound/t64a_1971/loader.wav"):
            with self.subTest(path=path), wave.open(str(path), "rb") as stream:
                self.assertEqual((stream.getnchannels(),stream.getsampwidth(),stream.getframerate()),(1,2,44100))
                self.assertEqual(stream.getnframes(),round(7.1*44100))
                signal=np.frombuffer(stream.readframes(stream.getnframes()),dtype="<i2").astype(float)/32767
                self.assertLess(np.abs(signal).max(),.8)
                self.assertGreater(np.sqrt(np.mean(signal**2)),.02)
                self.assertLess(abs(signal.mean()),.001)
                self.assertLess(np.abs(signal[-50:]).max(),.001)

    def test_original_synthesis_is_repeatable_and_variants_differ(self):
        a=audio.make_loader(72,False)
        b=audio.make_loader(72,False)
        c=audio.make_loader(64,True)
        np.testing.assert_array_equal(a,b)
        self.assertFalse(np.array_equal(a,c))


if __name__=="__main__": unittest.main()
