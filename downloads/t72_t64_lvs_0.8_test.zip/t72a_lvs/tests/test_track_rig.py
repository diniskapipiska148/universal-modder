"""Measured-model regression: belt child transforms must cancel wheel spin.

Fixtures are 16 local track-bone transforms read from the uploaded MDL49.
No model meshes or original textures are included. This is not a Source render.
"""
import math
import unittest

FIXTURES = [('[TRACKS] L1',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 8.185317993164062],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] L2',
  [[1.0, 0.0, 0.0, 1.9073486328125e-06],
   [0.0, 1.0, 0.0, 10.051078796386719],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] L3',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 5.290599822998047],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] L4',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 7.024681091308594],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] L5',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 7.632560729980469],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] L6',
  [[1.0, 0.0, 0.0, -1.9073486328125e-06],
   [0.0, 1.0, 0.0, 6.133720397949219],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] L0',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 13.782119750976562],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] L7',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 13.782119750976562],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] R1',
  [[1.0, 0.0, 0.0, 1.9073486328125e-06],
   [0.0, 1.0, 0.0, 8.185317993164062],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] R2',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 10.051078796386719],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] R3',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 5.290561676025391],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] R4',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 7.024681091308594],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] R5',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 7.632560729980469],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] R6',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 6.133678436279297],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] R0',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 13.782119750976562],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]]),
 ('[TRACKS] R7',
  [[1.0, 0.0, 0.0, 0.0],
   [0.0, 1.0, 0.0, 13.782119750976562],
   [0.0, 0.0, 1.0, 0.0],
   [0.0, 0.0, 0.0, 1.0]])]


def multiply(a,b):
    return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]


def rotate_y(degrees):
    a=math.radians(degrees);c,s=math.cos(a),math.sin(a)
    return [[c,0,s,0],[0,1,0,0],[-s,0,c,0],[0,0,0,1]]


def point(matrix, value):
    return [sum(matrix[i][k]*value[k] for k in range(4)) for i in range(3)]


class TrackRigRegression(unittest.TestCase):
    def test_real_track_offsets_are_on_wheel_spin_axis(self):
        self.assertEqual(len(FIXTURES),16)
        for name, matrix in FIXTURES:
            with self.subTest(bone=name):
                for i in range(3):
                    for j in range(3):
                        self.assertAlmostEqual(matrix[i][j],float(i==j),places=6)
                self.assertLess(abs(matrix[0][3]),1e-4)
                self.assertLess(abs(matrix[2][3]),1e-4)

    def test_counterspin_keeps_belt_vertices_stationary(self):
        vertex=[7.,-4.,9.,1.]
        old_worst=0
        for name, matrix in FIXTURES:
            expected=point(matrix,vertex)
            for angle in (0,30,90,180,270,359):
                with self.subTest(bone=name,angle=angle):
                    wheel=rotate_y(-angle)
                    # Old build rotated the wheel, implicitly dragging its
                    # skinned belt children around the roadwheel.
                    old=point(multiply(wheel,matrix),vertex)
                    old_worst=max(old_worst,max(abs(a-b) for a,b in zip(old,expected)))
                    corrected=point(multiply(multiply(wheel,matrix),rotate_y(angle)),vertex)
                    self.assertLess(max(abs(a-b) for a,b in zip(corrected,expected)),1e-4)
        self.assertGreater(old_worst,10, "fixture must expose the original visual defect")


if __name__ == '__main__':
    unittest.main()
