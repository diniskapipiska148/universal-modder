-- State, authorization, rearm and projectile distinctions; not a GMod run.
local root=arg[1] or "."
local state=dofile(root.."/tests/ammo_fixture.lua")(root)
local v=state.vehicle
local cannon=v.WEAPONS[1][1]
local count=0
local function check(value,message) count=count+1;assert(value,message) end
local function near(a,b) return math.abs(a-b)<1e-8 end
check(v:GetT72AmmoType()==1 and v:GetT72PendingAmmoType()==1,"initial loaded and selected APFSDS")
check(v:GetT72AmmoAP()==18 and v:GetT72AmmoHEAT()==9 and v:GetT72AmmoHE()==12,"finite initial distribution")
check(not v:T72RequestAmmo(99),"invalid type rejected")
check(not v:T72RequestAmmo(1),"same selected type does not reload")
check(v:T72RequestAmmo(2),"select HEAT")
check(v:GetT72AmmoType()==1 and v:GetT72PendingAmmoType()==2,"loaded stays until reload completes")
check(near(v.reload,107.1),"switch schedules full reload")
check(not v:T72RequestAmmo(3),"spam switch rate-limited")
check(v:T72GetAmmoTotal()==39,"selection does not spend/duplicate ammo")
check(cannon.Attack(v)==true and #state.shots==0,"cannot fire old loaded round while exchanging")
state.now=101
check(v:T72RequestAmmo(3),"change pending type during reload")
check(near(v.reload,108.1),"pending change never shortens reload")
state.now=107.5
v:T72AmmoThink()
check(v:GetT72AmmoType()==1,"not complete at previous deadline")
state.now=109
v:T72AmmoThink()
check(v:GetT72AmmoType()==3 and v.ballistics==26000,"completed HE changes loaded ballistics")
cannon.Attack(v)
check(v:GetT72AmmoHE()==11 and v:GetT72AmmoAP()==18,"HE consumes only HE")
local he=state.shots[#state.shots]
check(he.SplashDamage==800 and he.SplashDamageRadius==240 and he.Velocity==26000,"HE large blast")
state.now=110
check(v:T72RequestAmmo(2),"queue HEAT after HE shot")
local deadline=v.reload
v.selected=2
state.now=120
cannon.OnThink(v)
check(v:GetT72AmmoType()==2,"reload completes while MG selected")
check(v:GetT72ReloadEnd()==deadline,"weapon selection does not reset reload")
v.selected=1
cannon.Attack(v)
local heat=state.shots[#state.shots]
check(heat.Velocity==30000 and heat.SplashDamage==160 and heat.Damage==1000,"HEAT different damage/blast/velocity")
check(v:GetT72AmmoHEAT()==8 and v:T72GetAmmoTotal()==37,"reserves remain consistent")
v:SetT72AmmoAP(0)
state.now=130
check(not v:T72RequestAmmo(1),"empty requested type rejected")
v:SetT72PendingAmmoType(3)
check(v:T72CycleAmmo() and v:GetT72PendingAmmoType()==2,"cycle skips empty APFSDS")

-- A held LVS key is an edge, not one type change per server tick.
state.now=140
v:SetT72PendingAmmoType(2);v.driver.held=true
cannon.OnThink(v)
local pending=v:GetT72PendingAmmoType()
local keyDeadline=v.reload
state.now=141
cannon.OnThink(v)
check(v:GetT72PendingAmmoType()==pending and v.reload==keyDeadline,"held key cannot repeat")
v.driver.held=false;cannon.OnThink(v)
state.now=142;v.driver.held=true;cannon.OnThink(v)
check(v:GetT72PendingAmmoType()~=pending,"new key edge cycles")

-- Console route accepts only the current driver of this vehicle.
local command=state.commands.t72a_ammo_next
state.now=150
local before=v:GetT72PendingAmmoType()
command({lvsGetVehicle=function() return v end})
check(v:GetT72PendingAmmoType()==before,"passenger/other player denied")
command(nil)
check(v:GetT72PendingAmmoType()==before,"server console cannot select remote tank")
command(v.driver)
check(v:GetT72PendingAmmoType()~=before,"current driver may cycle")

-- Standard LVS rearm restores our typed reserves and MG, with no free ready shot.
v.WEAPONS[1][2]._CurAmmo=1500
state.now=160
v.reload=170
check(v:WeaponRestoreAmmo(),"rearm detects spent reserves")
check(v:T72GetAmmoTotal()==39 and v.WEAPONS[1][1]._CurAmmo==39,"rearm restores all typed reserves")
check(v.WEAPONS[1][2]._CurAmmo==2000,"rearm restores MG")
check(v.reload==170,"rearm cannot shorten existing deadline")
check(not v:WeaponRestoreAmmo(),"full rearm is idempotent")
v.hp=0
before=v:GetT72PendingAmmoType()
check(not v:T72CycleAmmo() and before==v:GetT72PendingAmmoType(),"destroyed tank cannot change type")
local other=dofile(root.."/tests/ammo_fixture.lua")(root,{18,9,10})
local t64=other.vehicle
check(t64:T72GetAmmoTotal()==37 and t64.WEAPONS[1][1].Ammo==37,"T64 has its own finite 37-round loadout")
check(t64:T72RequestAmmo(2) and t64.loaderCues==1,"accepted type change starts loader sound")
check(not t64:T72RequestAmmo(2) and t64.loaderCues==1,"rejected type change makes no loader cue")
other.now=110;t64:T72AmmoThink();t64.WEAPONS[1][1].Attack(t64)
check(t64.loaderCues==2 and t64:T72GetAmmoTotal()==36,"successful shot starts one loading cue")
check(t64:WeaponRestoreAmmo() and t64:T72GetAmmoTotal()==37 and t64.loaderCues==3,"T64 rearm respects its capacity and loading cue")
t64.WEAPONS[1][2]._CurAmmo=100
check(t64:WeaponRestoreAmmo() and t64.loaderCues==3,"MG-only rearm does not play cannon loader")
print("PASS: "..count.." ammo selection/rearm/authorization contracts (mock API)")
