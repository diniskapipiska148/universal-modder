-- Render/rig contract tests. These are mocks, not Source physics/render tests.
local root = arg[1] or "."
ENT = {OnRemoved = function() return "preserved" end}
local draws, creations, removals, callbacks = 0, 0, 0, {}
local frame, yaw, speed = 1, 0, 100
local visual
local vector = {}; vector.__index = vector
function Vector(x,y,z) return setmetatable({x=x,y=y,z=z},vector) end
function vector:Dot(v) return self.x*v.x+self.y*v.y+self.z*v.z end
function vector.__unm(v) return Vector(-v.x,-v.y,-v.z) end
function IsValid(e) return type(e)=="table" and e.valid~=false end
function include(path) return dofile(root .. "/lua/" .. path) end
function Angle(p,y,r) return {p=p,y=y,r=r} end
function FrameNumber() return frame end
function FrameTime() return 0.016 end
math.Clamp = function(n,a,b) return math.max(a,math.min(n,b)) end
math.AngleDifference = function(a,b) return (a-b+180)%360-180 end
RENDERGROUP_OPAQUE = 0
util = {IsValidModel=function() return true end}
function Matrix() return {Translate=function(self,value) self.translation=value end} end
function Material() return {GetString=function(_,key)
    if key=="$basetexture" then return "t72a_ural/tracks_diffuse" end
    if key=="$bumpmap" then return "t72a_ural/tracks_normal" end
    if key=="$basemapalphaphongmask" then return "1" end
    if key=="$phongfresnelranges" then return "[0.02 0.08 0.2]" end
end} end
local madeMaterials={}
function CreateMaterial(name,shader,parameters)
    local material={name=name,parameters=parameters,GetName=function(self) return self.name end,
        SetMatrix=function(self,key,matrix)
            self.matrices=self.matrices or {};self.matrices[key]=matrix;self.matrix=matrix
        end}
    madeMaterials[#madeMaterials+1]=material
    return material
end
local clipState, clipStack, clipPlanes = false, 0, {}
render={EnableClipping=function(value) local old=clipState;clipState=value;return old end,
    PushCustomClipPlane=function(normal,distance)
        clipStack=clipStack+1;clipPlanes[#clipPlanes+1]={normal=normal,distance=distance}
    end,
    PopCustomClipPlane=function() clipStack=clipStack-1 end}
local errors=0
function ErrorNoHalt() errors=errors+1 end
function ClientsideModel()
    creations=creations+1
    visual={valid=true,bones={},sub={},failDraw=false}
    function visual:SetNoDraw(v) self.noDraw=v end
    function visual:SetSkin(v) self.skin=v end
    function visual:ResetSequence(v) self.sequence=v end
    function visual:SetCycle(v) self.cycle=v end
    function visual:SetPlaybackRate(v) self.playback=v end
    function visual:GetBodyGroups() return {{id=0}} end
    function visual:SetBodygroup() end
    function visual:GetMaterials() return {"models/test/body","models/test/tracks"} end
    function visual:SetSubMaterial(id,value) assert(id<=31);self.sub[id]=value end
    function visual:LookupBone(name)
        return ({["[wheels] L1"]=1,["[wheels] R1"]=2,["[TRACKS] L1"]=11,["[TRACKS] R1"]=12})[name]
    end
    function visual:ManipulateBoneAngles(id,value) self.bones[id]=value end
    function visual:SetPos(pos) self.pos=pos end
    function visual:SetAngles(ang) self.ang=ang end
    function visual:SetColor() end
    function visual:SetupBones() end
    function visual:DrawModel()
        if self.failDraw then error("intentional renderer test failure") end
        draws=draws+1
    end
    function visual:Remove() self.valid=false;removals=removals+1 end
    return visual
end
dofile(root.."/lua/t72a/cl_visual.lua")
local v=setmetatable({T72Profile={Model="model",VisualYaw=0,RenderMins={},RenderMaxs={},
    Wheels={Left={Vector(0,57.322,0)},Radius=15.684},
    WheelBones={Left={"[wheels] L1"},Right={"[wheels] R1"}}}}, {__index=ENT})
function v:DrawShadow() end
function v:SetRenderBounds() end
function v:CallOnRemove(name,func) callbacks[name]=func end
function v:GetPos() return Vector(10,20,30) end
function v:GetAngles() return {y=yaw} end
function v:LocalToWorldAngles(ang) return ang end
function v:GetColor() return {} end
function v:GetVelocity() return Vector(speed,0,0) end
function v:GetForward() return Vector(1,0,0) end
function v:GetRight() return Vector(0,-1,0) end
function v:T72ApplyVisualTurret() end
v:Draw()
assert(creations==1 and draws==2 and visual.noDraw and visual.skin==0)
assert(visual.sequence==0 and visual.cycle==0 and visual.playback==0,"pin runtime reference animation")
assert(visual.ang.y==0 and visual.sub[0]=="t72a_ural/olive","do not double rotate model")
assert(#madeMaterials==2 and madeMaterials[1]~=madeMaterials[2],"independent belt materials")
assert(madeMaterials[1].parameters['$bumpmap']=='t72a_ural/tracks_normal',"inherit detailed track finish")
assert(madeMaterials[1].parameters['$basemapalphaphongmask']=='1',"inherit dirt highlight mask")
assert(madeMaterials[1].parameters['$phongfresnelranges']=='[0.02 0.08 0.2]',"retain matte track reflection")
assert(madeMaterials[1].matrices['$basetexturetransform']==madeMaterials[1].matrices['$bumptransform'],
    "tread color and normal maps must scroll together")
local firstScroll=madeMaterials[1].matrices['$basetexturetransform'].translation
assert(firstScroll.x<0 and firstScroll.y==0 and firstScroll.z==0,
    "forward belt travel must scroll longitudinal U, not cross-width V")
assert(math.abs(firstScroll.x+100*0.016/12.8)<1e-9,"scroll speed must follow measured UV scale")
-- Measured UV tangents: +U is +X on top and -X underneath; the negative
-- sampling offset therefore moves texture features with a forward belt loop.
local topTangentX,bottomTangentX=12.778789,-12.5931
assert(-firstScroll.x*topTangentX>0 and -firstScroll.x*bottomTangentX<0,
    "top and lower runs must move in opposite world directions")
assert(clipPlanes[1].normal.y==1 and clipPlanes[2].normal.y==-1,"clip the respective hull halves")
assert(clipPlanes[1].distance==20 and clipPlanes[2].distance==-20,"clip plane must follow root origin")
assert(not clipState and clipStack==0,"restore render state")
assert(visual.bones[1].p==-visual.bones[11].p,"left belt must not inherit roadwheel rotation")
assert(visual.bones[2].p==-visual.bones[12].p,"right belt must not inherit roadwheel rotation")
-- Parent spin and child counterspin cancel around local Y; the child's local
-- translation (0,8.185318,0) lies on that axis and therefore cannot orbit.
for _,degrees in ipairs({0,30,90,180,270,359}) do
    local p,c=math.rad(-degrees),math.rad(degrees)
    local resultingX=math.sin(p+c)*8.185318
    assert(math.abs(resultingX)<1e-10 and math.abs(math.cos(p+c)-1)<1e-10)
end
local phase=v._T72WheelPhaseLeft
v:Draw()
assert(creations==1 and v._T72WheelPhaseLeft==phase,"only one animation update per frame")
frame=2;yaw=2;speed=0
local lastL,lastR=v._T72TrackScrollLeft,v._T72TrackScrollRight
v:Draw()
assert(v._T72TrackScrollLeft~=lastL and v._T72TrackScrollRight~=lastR)
local deltaL=(v._T72TrackScrollLeft-lastL+0.5)%1-0.5
local deltaR=(v._T72TrackScrollRight-lastR+0.5)%1-0.5
assert(deltaL<0 and deltaR>0,"pivot turn needs opposite belt travel")
local leftUV=madeMaterials[1].matrices['$basetexturetransform'].translation
local rightUV=madeMaterials[2].matrices['$basetexturetransform'].translation
assert(leftUV.y==0 and rightUV.y==0,"pivot scrolling must remain longitudinal")
assert(visual.bones[1].p==-visual.bones[11].p and visual.bones[2].p==-visual.bones[12].p)
v:DrawTranslucent()
assert(draws==6,"each half once; no duplicate translucent draw")
-- A renderer exception must not leak clipping state into other world draws.
clipState=true;visual.failDraw=true;frame=3
v:Draw()
assert(errors==1 and clipState and clipStack==0 and v._T72DisableSplitTracks)
visual.failDraw=false;v:Draw()
assert(draws==7,"safe fallback after one split-render error")
assert(v:OnRemoved()=="preserved","base removal hook stays intact")
callbacks.T72UralVisualCleanup(v)
assert(removals==1 and v.T72Visual==nil)
print("PASS: reference pose, belt counterspin, opposite-side UV travel, private materials, clipping/lifecycle safety (mock API)")
