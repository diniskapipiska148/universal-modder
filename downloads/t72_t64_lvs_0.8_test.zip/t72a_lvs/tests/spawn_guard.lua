-- Missing model must fail before invoking LVS physics or creating entities.
local root = arg[1] or "."
ENT = {T72Profile = {Ready = false}}
local baseCalls, removed, notices = 0, 0, 0
function AddCSLuaFile() end
function include() end
function IsValid(e) return e ~= nil end
function ErrorNoHalt() notices = notices + 1 end
function isstring(v) return type(v) == "string" end
function istable(v) return type(v) == "table" end
util = {IsValidModel = function() return false end}
baseclass = {Get = function()
    return {SpawnFunction = function() baseCalls = baseCalls + 1 end,
        Initialize = function() baseCalls = baseCalls + 1 end}
end}
function ENT:Remove() removed = removed + 1 end
dofile(root .. "/lua/entities/lvs_t72a/init.lua")
local ply = {ChatPrint = function() notices = notices + 1 end}
assert(ENT:SpawnFunction(ply, {}, "lvs_t72a") == nil)
ENT:Initialize()
assert(baseCalls == 0 and removed == 1 and notices == 2, "unverified profile must not reach physics")
ENT.T72Profile = {Ready = true, Model = "models/not_mounted.mdl"}
assert(ENT:SpawnFunction(ply, {}, "lvs_t72a") == nil)
assert(baseCalls == 0, "unmounted model must not spawn")
print("PASS: unverified profile and missing model block spawn before physics (mock API)")
