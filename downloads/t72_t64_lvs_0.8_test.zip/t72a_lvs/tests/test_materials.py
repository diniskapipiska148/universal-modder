"""Tests of the byte-level format, independent of an installed Garry's Mod."""
import io
import importlib.util
from pathlib import Path
import struct
import unittest

from PIL import Image

path = Path(__file__).resolve().parents[1] / "tools" / "build_materials.py"
spec = importlib.util.spec_from_file_location("build_materials", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class VTFTests(unittest.TestCase):
    def test_header_layout_mip_order_channels_and_rows(self):
        source = Image.new("RGBA", (2, 2))
        source.putdata([(255, 0, 0, 255), (0, 255, 0, 255),
                        (0, 0, 255, 255), (255, 255, 255, 255)])
        data = module.encode_vtf(source)
        self.assertEqual(data[:4], b"VTF\0")
        self.assertEqual(struct.unpack_from("<IIIHH", data, 4), (7, 2, 80, 2, 2))
        self.assertEqual(struct.unpack_from("<HH", data, 24), (1, 0))
        self.assertEqual(struct.unpack_from("<I", data, 52)[0], 0)
        self.assertEqual(data[56], 2)
        self.assertEqual(struct.unpack_from("<I", data, 57)[0], 0xFFFFFFFF)
        self.assertEqual(struct.unpack_from("<H", data, 63)[0], 1)
        self.assertEqual(len(data), 80 + 4 + 16)
        # The 1x1 mip is first; the original colored quadrants are last with
        # unchanged channel and row orientation (no texture-writer UV flip).
        self.assertEqual(data[80:84], bytes((128, 128, 128, 255)))
        self.assertEqual(data[84:], source.tobytes())

    def test_rectangular_mip_chain_and_reject_invalid_dimensions(self):
        data = module.encode_vtf(Image.new("RGB", (8, 2), (2, 3, 4)))
        self.assertEqual(data[56], 4)
        self.assertEqual(len(data), 80 + (1 + 2 + 4 + 16) * 4)
        self.assertEqual(data[80:84], bytes((2, 3, 4, 255)))
        with self.assertRaises(ValueError):
            module.encode_vtf(Image.new("RGB", (3, 4)))


    def test_bc1_mip_block_sizes_and_decoded_top_level(self):
        source = Image.new("RGBA", (8, 8), (200, 64, 30, 255))
        data = module.encode_vtf(source, "DXT1")
        self.assertEqual(struct.unpack_from("<I", data, 52)[0], 13)
        self.assertEqual(data[56], 4)
        # 1x1/2x2/4x4 each use one BC1 block, 8x8 uses four.
        self.assertEqual(len(data), 80 + 8 + 8 + 8 + 32)
        stream = io.BytesIO()
        source.save(stream, format="DDS", pixel_format="DXT1")
        header = stream.getvalue()[:128]
        decoded = Image.open(io.BytesIO(header + data[-32:])).convert("RGBA")
        self.assertEqual(decoded.size, (8, 8))
        pixel = decoded.getpixel((4, 4))
        for actual, expected in zip(pixel, (200, 64, 30, 255)):
            self.assertLessEqual(abs(actual - expected), 8)

    def test_bc3_normal_flag_and_mip_vector_normalization(self):
        import numpy as np
        source = Image.new("RGBA", (4, 4), (128, 128, 255, 255))
        data = module.encode_vtf(source, "DXT5", normal_map=True)
        self.assertEqual(struct.unpack_from("<I", data, 52)[0], 15)
        self.assertTrue(struct.unpack_from("<I", data, 20)[0] & 0x80)
        self.assertEqual(len(data), 80 + 16 * 3)
        field = np.zeros((16, 16), dtype=np.float32)
        field[:, 8:] = 0.4
        normal = module.normal_from_height(field, 2)
        for mip in module.mip_images(normal, normal_map=True):
            vectors = np.asarray(mip)[:, :, :3] / 127.5 - 1
            self.assertTrue(np.all(np.abs(np.linalg.norm(vectors, axis=2) - 1) < 0.02))
        self.assertNotEqual(normal.getpixel((7, 8)), normal.getpixel((4, 8)))

    def test_alpha_mask_flag_does_not_require_translucent_shader(self):
        data = module.encode_vtf(Image.new("RGBA", (4, 4), (10, 20, 30, 55)), "DXT5")
        self.assertTrue(struct.unpack_from("<I", data, 20)[0] & 0x2000)
        shader = module.lit("olive", "olive_normal", 18, 0.7)
        self.assertIn('"$basemapalphaphongmask" "1"', shader)
        self.assertIn('"$bumpmap" "t72a_ural/olive_normal"', shader)
        self.assertNotIn("$translucent", shader)

    def test_dirt_reduces_highlights_and_changes_surface_color(self):
        import numpy as np
        clean = np.full((4, 4, 3), 150, dtype=np.float32)
        zero, full = np.zeros((4, 4)), np.ones((4, 4))
        intact, intact_alpha = module.dirty_surface(clean, 80, zero, zero)
        dirty, dirty_alpha = module.dirty_surface(clean, 80, full, full)
        self.assertTrue(np.allclose(intact, clean))
        self.assertTrue(np.all(intact_alpha == 80))
        self.assertTrue(np.all(dirty < intact))
        self.assertTrue(np.all(dirty_alpha < intact_alpha * .25))
        self.assertTrue(np.all(dirty_alpha >= 3))
        shader = module.lit("olive", "olive_normal", 12, .1)
        self.assertIn('"$phongfresnelranges" "[0.02 0.08 0.2]"', shader)
        self.assertNotIn('"$envmap"', shader)


if __name__ == "__main__":
    unittest.main()
