-- Runtime contracts for original T64 IMesh rendering; no GMod session needed.
local root = arg[1] or "."
local V = {};V.__index=V
function Vector(x,y,z) return setmetatable({x=x,y=y,z=z},V) end
function V.__add(a,b) return Vector(a.x+b.x,a.y+b.y,a.z+b.z) end
function V.__sub(a,b) return Vector(a.x-b.x,a.y-b.y,a.z-b.z) end
function V.__mul(a,b) return Vector(a.x*b,a.y*b,a.z*b) end
function V.__div(a,b) return Vector(a.x/b,a.y/b,a.z/b) end
function V:Dot(b) return self.x*b.x+self.y*b.y+self.z*b.z end
function V:Cross(b) return Vector(self.y*b.z-self.z*b.y,self.z*b.x-self.x*b.z,self.x*b.y-self.y*b.x) end
function V:LengthSqr() return self:Dot(self) end
function V:GetNormalized() local n=math.sqrt(self:LengthSqr());if n==0 then return Vector(0,0,0) end;return self/n end
function Angle(p,y,r) return {p=p,y=y,r=r} end
local M={};M.__index=M
local function identity() return {{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}} end
function Matrix() return setmetatable({v=identity()},M) end
function M:Multiply(b)
 local a,out=self.v,identity()
 for i=1,4 do for j=1,4 do out[i][j]=0;for k=1,4 do out[i][j]=out[i][j]+a[i][k]*b[k][j] end end end
 self.v=out
end
function M:SetTranslation(v) self.v[1][4]=v.x;self.v[2][4]=v.y;self.v[3][4]=v.z end
local function rotation(a)
 local p,y=math.rad(a.p),math.rad(a.y)
 local cp,sp,cy,sy=math.cos(p),math.sin(p),math.cos(y),math.sin(y)
 return {{cy*cp,-sy,cy*sp,0},{sy*cp,cy,sy*sp,0},{-sp,0,cp,0},{0,0,0,1}}
end
function M:SetAngles(a) local t=Vector(self.v[1][4],self.v[2][4],self.v[3][4]);self.v=rotation(a);self:SetTranslation(t) end
function M:Rotate(a) self:Multiply(rotation(a)) end
function M:Translate(t) local m=identity();m[1][4]=t.x;m[2][4]=t.y;m[3][4]=t.z;self:Multiply(m) end
function M:Point(p) local a=self.v;return Vector(a[1][1]*p.x+a[1][2]*p.y+a[1][3]*p.z+a[1][4],a[2][1]*p.x+a[2][2]*p.y+a[2][3]*p.z+a[2][4],a[3][1]*p.x+a[3][2]*p.y+a[3][3]*p.z+a[3][4]) end
function IsValid(v) return v~=nil end
math.Clamp=function(n,a,b) return math.max(a,math.min(n,b)) end
math.AngleDifference=function(a,b) return (a-b+180)%360-180 end
local frame,dt=1,.02
function FrameNumber() return frame end
function FrameTime() return dt end
local fixture={Chunks={"fixture_hull","fixture_turret","fixture_gun","fixture_wheel","fixture_left","fixture_right"},Parts={
 hull={Kind="hull",Pivot={0,0,0}},turret={Kind="turret",Pivot={-8,0,65}},
 gun={Kind="gun",Pivot={45,0,82}},wheel_L1={Kind="wheel",Pivot={112,77,19},Side="Left"},
 track_left={Kind="track",Pivot={0,0,0},Side="Left"},track_right={Kind="track",Pivot={0,0,0},Side="Right"}}}
local names={"hull","turret","gun","wheel_L1","track_left","track_right"}
local triangle={0,0,0,0,0,1,0,0,1,0,0,0,0,1,1,0,0,1,0,0,0,1,0,1}
local extraChunks={}
function include(path)
 if path=="t64a_1971/geometry/index.lua" then return fixture end
 if extraChunks[path] then return extraChunks[path] end
 for i,p in ipairs(fixture.Chunks) do if path==p then return {Part=names[i],Material="t64a_1971/"..(i>=5 and "tracks" or "armor"),Vertices=triangle} end end
 error("unexpected include "..path)
end
function Material(name) return {name=name,GetString=function(_,key) return key=="$basetexture" and "t64a_1971/tracks_color" or nil end} end
local private={}
function CreateMaterial(name,shader,values)
 local v={name=name,values=values,SetMatrix=function(self,k,m) self[k]=m end};private[#private+1]=v;return v
end
local builds,destroyed,draws,errors=0,0,0,0
local fail=false
local failBuildAt
local buildSizes={}
local drawRecords,lastMaterial={},nil
function Mesh()
 return {BuildFromTriangles=function(self,vertices)
  builds=builds+1;buildSizes[#buildSizes+1]=#vertices
  self.Vertices=vertices
  assert(#vertices>0 and #vertices%3==0 and #vertices<=32766,"complete triangles under IMesh vertex limit")
  for _,vertex in ipairs(vertices) do assert(#vertex.userdata==4,"triangles require normalmap tangent data") end
  if builds==failBuildAt then error("injected upload failure") end
 end,Destroy=function() destroyed=destroyed+1 end,Draw=function(self)
  if fail then error("injected draw failure") end
  draws=draws+1;drawRecords[#drawRecords+1]={Mesh=self,Material=lastMaterial}
 end}
end
local hooks={}
hook={Add=function(event,_,callback) hooks[event]=callback end}
function ErrorNoHalt() errors=errors+1 end
local colour={.3,.4,.5};local blend=.7;local suppress=false;local depth=0;local lightingOrigin
render={GetColorModulation=function() return table.unpack(colour) end,GetBlend=function() return blend end,
 SetLightingOrigin=function(v) lightingOrigin=v end,SuppressEngineLighting=function(v) suppress=v end,ResetModelLighting=function() end,
 ComputeLighting=function() return Vector(.2,.3,.4) end,SetModelLighting=function() end,
 SetColorModulation=function(r,g,b) colour={r,g,b} end,SetBlend=function(v) blend=v end,SetMaterial=function(value) lastMaterial=value end}
cam={PushModelMatrix=function() depth=depth+1 end,PopModelMatrix=function() depth=depth-1 end}
ENT={}
dofile(root.."/lua/t64a_1971/cl_mesh.lua")
local function vehicle()
 local v=setmetatable({origin=Vector(0,0,0),bodyYaw=0,turretYaw=0,pitch=0,speed=100,
  T72Profile={Wheels={Left={Vector(112,77,19)},Radius=14.5},TrackUVUnits=10,
   Rig={TurretPivot=Vector(-8,0,65),GunPivot=Vector(45,0,82)},RenderMins={},RenderMaxs={}},callbacks={}}, {__index=ENT})
 function v:GetPos() return self.origin end
 function v:GetAngles() return Angle(0,self.bodyYaw,0) end
 function v:GetTurretYaw() return self.turretYaw end
 function v:GetTurretPitch() return self.pitch end
 function v:GetVelocity() return Vector(self.speed,0,0) end
 function v:GetForward() return Vector(1,0,0) end
 function v:GetColor() return {r=255,g=255,b=255,a=255} end
 function v:OBBCenter() return Vector(1,2,3) end
 function v:LocalToWorld(p)
  local a=math.rad(self.bodyYaw)
  return self.origin+Vector(p.x*math.cos(a)-p.y*math.sin(a),p.x*math.sin(a)+p.y*math.cos(a),p.z)
 end
 function v:DrawShadow() end
 function v:SetRenderBounds() end
 function v:CallOnRemove(name,f) self.callbacks[name]=f end
 return v
end
local n=0
local function check(value,message) n=n+1;assert(value,message) end
local function near(a,b,message) check((a-b):LengthSqr()<1e-8,message) end
local a,b=vehicle(),vehicle()
a:Draw();b:Draw()
check(builds==6 and draws==12,"share static original geometry across vehicles")
check(a._T64MeshCache==b._T64MeshCache,"shared cache")
check(a._T64TrackMaterials.Left~=b._T64TrackMaterials.Left,"track transforms stay per vehicle")
check(not suppress and depth==0 and blend==.7 and colour[1]==.3,"restore global render state")
local phase=a._T64WheelLeft;a:Draw();check(phase==a._T64WheelLeft,"update animation once per frame")
local matrices=a._T64TrackMaterials.Left
check(matrices['$basetexturetransform']==matrices['$bumptransform'],"normal/color track movement stays synchronized")
check(matrices['$basetexturetransform'].v[1][4]<0 and matrices['$basetexturetransform'].v[2][4]==0,"track moves longitudinal U")
a.turretYaw=90
near(a:T64PartMatrix(fixture.Parts.turret):Point(Vector(0,0,0)),Vector(-8,0,65),"turret yaw keeps pivot")
near(a:T64PartMatrix(fixture.Parts.gun):Point(Vector(0,0,0)),Vector(-8,53,82),"gun pivot follows turret yaw")
a.pitch=10
local p=a:T64PartMatrix(fixture.Parts.gun):Point(Vector(268,0,0))
near(p,Vector(-8,53+268*math.cos(math.rad(10)),82-268*math.sin(math.rad(10))),"gun point uses same pitch/yaw chain as firing")
a.origin=Vector(10,20,30);a.bodyYaw=90
near(a:T64PartMatrix(fixture.Parts.turret):Point(Vector(0,0,0)),Vector(10,12,95),"world body frame affects visual pivot")
fail=true;frame=2;a:Draw();fail=false
check(errors==1 and depth==0 and not suppress and blend==.7,"renderer failure restores stacks and lighting")
near(lightingOrigin,Vector(8,21,33),"light probe origin must transform OBB centre into world coordinates")
a.callbacks.T64GeneratedMeshRelease(a)
check(destroyed==0,"removing one tank must not destroy another tank's meshes")
b.callbacks.T64GeneratedMeshRelease(b)
check(destroyed==6,"last owner frees static meshes")
local c=vehicle();c:Draw();check(builds==12,"new tank rebuilds disposed cache")
hooks.ShutDown();check(destroyed==12,"shutdown destroys cached mesh resources")

-- Network shards with the same component/material share uploads, even when
-- separated by another component's shard. Different parts/materials stay apart.
fixture.Chunks={"batch_hull_1","batch_turret","batch_hull_2","batch_hull_steel","batch_track_steel","batch_track_moving"}
extraChunks.batch_hull_1={Part="hull",Material="t64a_1971/armor",Vertices=triangle}
local shiftedTriangle={}
for i=1,#triangle,8 do
 for offset=0,7 do shiftedTriangle[i+offset]=triangle[i+offset] end
 shiftedTriangle[i+2]=3;shiftedTriangle[i+6]=triangle[i+6]+.25;shiftedTriangle[i+7]=triangle[i+7]+.75
end
extraChunks.batch_hull_2={Part="hull",Material="t64a_1971/armor",Vertices=shiftedTriangle}
extraChunks.batch_turret={Part="turret",Material="t64a_1971/armor",Vertices=triangle}
extraChunks.batch_hull_steel={Part="hull",Material="t64a_1971/darksteel",Vertices=triangle}
extraChunks.batch_track_steel={Part="track_left",Material="t64a_1971/darksteel",Vertices=triangle}
extraChunks.batch_track_moving={Part="track_left",Material="t64a_1971/tracks",Vertices=triangle}
local batchStart=builds
local d,e=vehicle(),vehicle();d:Draw();e:Draw()
check(builds-batchStart==5,"merge disjoint network shards only for matching part and material")
check(buildSizes[batchStart+1]==6 and buildSizes[batchStart+2]==3 and buildSizes[batchStart+3]==3,"merged upload preserves triangle inventory")
local merged=d._T64MeshCache.Meshes[1].Mesh.Vertices
check(merged[4].pos.z==3 and merged[4].normal.z==1 and merged[4].u==.25 and merged[4].v==.75,"batching preserves source positions normals and UVs")
check(d._T64MeshCache==e._T64MeshCache,"batched geometry shares its cache")
local staticTrack,movingTrack
for _,item in ipairs(d._T64MeshCache.Meshes) do
 if item.Part=="track_left" then
  if item.MaterialPath=="t64a_1971/darksteel" then staticTrack=item else movingTrack=item end
 end
end
local staticDraws,movingDraws=0,0
for _,record in ipairs(drawRecords) do
 if record.Mesh==staticTrack.Mesh then
  assert(record.Material==staticTrack.Material,"track hardware keeps its static material")
  staticDraws=staticDraws+1
 elseif record.Mesh==movingTrack.Mesh then
  assert(record.Material==d._T64TrackMaterials.Left or record.Material==e._T64TrackMaterials.Left,"only track tread uses per-vehicle scrolling material")
  movingDraws=movingDraws+1
 end
end
check(staticDraws==2,"static track hardware material drawn for both vehicles")
check(movingDraws==2,"only the tread receives independent per-vehicle scrolling")
local destroyedStart=destroyed
d.callbacks.T64GeneratedMeshRelease(d)
check(destroyed==destroyedStart,"batched meshes stay alive while another owner remains")
e.callbacks.T64GeneratedMeshRelease(e)
check(destroyed-destroyedStart==5,"last owner frees every batched mesh")

-- Cross the upload limit inside a network shard. The split must happen at a
-- triangle boundary, retaining the exact count rather than dropping the tail.
local function repeatedTriangles(count)
 local data={}
 for i=1,count do for _,value in ipairs(triangle) do data[#data+1]=value end end
 return data
end
fixture.Chunks={}
for i=1,6 do
 local name="large_hull_"..i;fixture.Chunks[#fixture.Chunks+1]=name
 extraChunks[name]={Part="hull",Material="t64a_1971/armor",Vertices=repeatedTriangles(i==6 and 700 or 2048)}
end
batchStart=builds
local f=vehicle();f:Draw()
check(builds-batchStart==2,"split oversized component into bounded uploads")
check(buildSizes[batchStart+1]==32766 and buildSizes[batchStart+2]==54,"limit split preserves complete triangles and exact vertex count")
f.callbacks.T64GeneratedMeshRelease(f)

-- A later upload can fail after a full batch has already been allocated.
-- Both the successful resource and the failed upload's resource must be freed.
batchStart=builds;destroyedStart=destroyed;failBuildAt=builds+2
local g=vehicle();g:Draw();failBuildAt=nil
check(builds-batchStart==2 and destroyed-destroyedStart==2,"partial upload failure frees all allocated batches")
check(g._T64MeshCache==nil,"failed upload cannot acquire cache ownership")
g:Draw()
check(builds-batchStart==4 and g._T64MeshCache~=nil,"next attempt rebuilds a disposed failed cache")
g.callbacks.T64GeneratedMeshRelease(g)
check(destroyed-destroyedStart==4,"recovered cache releases all batches")
print("PASS: "..n.." T64 mesh caching, transforms, tangents, U-scroll and cleanup contracts (mock GMod)")
