-- Exercise the real shared-file include order and ammo DT initialization.
-- No Source physics or rendering is simulated here.
local root = arg[1] or "."
SERVER, CLIENT = true, false
function Vector(x,y,z) return {x=x,y=y,z=z} end
function Angle(p,y,r) return {p=p,y=y,r=r} end
function Material(name) return name end
function include(path)
    if path == "sh_weapons.lua" then
        return dofile(root .. "/lua/entities/lvs_t72a/" .. path)
    end
    return dofile(root .. "/lua/" .. path)
end
file = {Exists=function() return false end}
LVS = {SOUNDTYPE_NONE=0}
ENT = {WEAPONS={[1]={}}}
local registered = {}
function ENT:AddDT(kind,name)
    assert(not registered[name], "duplicate DT " .. name)
    registered[name] = kind
    local value = 0
    self["Get"..name] = function() return value end
    self["Set"..name] = function(_,new) value = new end
end
function ENT:AddWeapon(weapon) table.insert(self.WEAPONS[1],weapon) end
dofile(root .. "/lua/entities/lvs_t72a/shared.lua")
-- LVS registers weapons before calling the addon DT hook.
ENT:InitWeapons()
ENT:OnSetupDataTables()
assert(#ENT.WEAPONS[1] == 2)
assert(registered.T72ReloadEnd == "Float" and registered.T72AmmoType == "Int")
assert(ENT:GetT72ReloadEnd() == 0 and ENT:GetT72Range() == -1)
assert(ENT:GetT72AmmoType() == 1 and ENT:GetT72PendingAmmoType() == 1)
assert(ENT:T72GetAmmoTotal() == 39 and ENT:T72GetAmmoCount(1) == 18)
assert(ENT.TurretBallisticsProjectileVelocity == 72000)
assert(ENT.T72Profile.VisualYaw == 0, "do not add another model-root rotation")
print("PASS: shared includes, LVS constructor order, ammo DTs and reference orientation")
