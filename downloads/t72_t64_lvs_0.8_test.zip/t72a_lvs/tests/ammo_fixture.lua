-- Small LVS/GMod test double. Tests exercise production state/callback code.
return function(root, loadout)
    SERVER, CLIENT = true, false
    local state = {now = 100, commands = {}, shots = {}}
    function CurTime() return state.now end
    function Material(value) return value end
    function IsValid(value) return type(value) == "table" and value.valid ~= false end
    function Vector(x,y,z)
        return setmetatable({x=x,y=y,z=z}, {
            __unm=function(a) return Vector(-a.x,-a.y,-a.z) end,
            __mul=function(a,b) return Vector(a.x*b,a.y*b,a.z*b) end
        })
    end
    function EffectData()
        return {SetOrigin=function() end,SetAngles=function() end,SetScale=function() end}
    end
    util={Effect=function() end}
    DMG_BLAST=64
    concommand={Add=function(name,handler) state.commands[name]=handler end}
    ENT={}
    dofile(root.."/lua/t72a/sh_ammo.lua")
    dofile(root.."/lua/entities/lvs_t72a/sh_weapons.lua")
    local driver={held=false,lvsKeyDown=function(self) return self.held end}
    local v=setmetatable({T72A=true,T72AmmoLoadout=loadout,hp=2500,enabled=true,selected=1,reload=0,
        missing=false,WEAPONS={[1]={}},fields={},driver=driver}, {__index=ENT})
    function v:AddDT(_,name)
        self["Get"..name]=function(self) return self.fields[name] or 0 end
        self["Set"..name]=function(self,value) self.fields[name]=value end
    end
    function v:GetHP() return self.hp end
    function v:T72StartAutoloader() self.loaderCues=(self.loaderCues or 0)+1 end
    function v:GetTurretEnabled() return self.enabled end
    function v:GetSelectedWeapon() return self.selected end
    function v:GetAmmo()
        local weapon=self.WEAPONS[1][self.selected]
        return weapon._CurAmmo or weapon.Ammo
    end
    function v:GetNWAmmo() return self.nwAmmo end
    function v:SetNWAmmo(value) self.nwAmmo=value end
    function v:TakeAmmo(value)
        local weapon=self.WEAPONS[1][self.selected]
        weapon._CurAmmo=self:GetAmmo()-value
        self:SetNWAmmo(weapon._CurAmmo)
    end
    function v:GetT72ReloadEnd() return self.reload end
    function v:SetT72ReloadEnd(value) self.reload=value end
    function v:AddWeapon(weapon) self.WEAPONS[1][#self.WEAPONS[1]+1]=weapon end
    function v:GetDriver() return self.driver end
    function v:GetT72Muzzle(machineGun)
        if self.missing then return end
        return {Pos=Vector(machineGun and 2 or 1,0,0),Ang={Forward=function() return Vector(1,0,0) end}}
    end
    function v:LVSFireBullet(bullet) state.shots[#state.shots+1]=bullet end
    function v:EmitSound() end
    function v:GetPhysicsObject() return {valid=false} end
    function v:TurretUpdateBallistics(speed) self.ballistics=speed end
    driver.lvsGetVehicle=function() return v end
    v:InitWeapons()
    v:T72AmmoSystemDT()
    v:T72SyncCannonAmmo()
    state.vehicle=v
    return state
end
