-- Run: texlua tests/weapons.lua . (mock API; not a Source runtime test).
local root=arg[1] or "."
local state=dofile(root.."/tests/ammo_fixture.lua")(root)
local v=state.vehicle
local shots=state.shots
local cannon,mg=v.WEAPONS[1][1],v.WEAPONS[1][2]
local count=0
local function check(value,message) count=count+1;assert(value,message) end
check(#v.WEAPONS[1]==2,"register cannon and MG")
check(cannon.Ammo==39 and mg.Ammo==2000,"finite cannon and MG capacities")
check(v:T72GetAmmoTotal()==39,"round types share total 39")
cannon.OnSelect(v)
check(v.ballistics==72000,"default APFSDS ballistics")
cannon.Attack(v)
check(#shots==1 and v:GetT72AmmoAP()==17 and v:T72GetAmmoTotal()==38,"exactly one typed round spent")
check(v:GetNWAmmo()==38 and v:GetAmmo()==38,"LVS counter matches typed reserve total")
check(shots[1].EnableBallistics and shots[1].SplashDamage==nil,"APFSDS has direct damage, no HE splash")
check(v.reload==107.1,"autoloader deadline")
check(cannon.Attack(v)==true and #shots==1,"cannot fire during reload")
v.selected=2
mg.OnSelect(v)
mg.Attack(v)
check(#shots==2 and v:GetAmmo()==1999,"MG independent while cannon reloads")
check(v.ballistics==40000,"MG ballistics")
v.selected=1
check(cannon.Attack(v)==true and #shots==2,"weapon cycling cannot skip reload")
state.now=108
v.missing=true
check(cannon.Attack(v)==true and v:GetT72AmmoAP()==17,"missing muzzle costs no round")
v.missing=false
cannon.Attack(v)
check(#shots==3 and v:GetT72AmmoAP()==16,"cannon fires after reload")
v.hp=0
check(mg.Attack(v)==true and #shots==3,"destroyed vehicle cannot fire")
v.hp=2500;v.enabled=false
check(mg.Attack(v)==true and #shots==3,"disabled turret cannot fire")
v.enabled=true;v.selected=2
mg._CurAmmo=0
check(mg.Attack(v)==true and #shots==3,"empty MG cannot fire")
v.selected=1;v:SetT72AmmoAP(0)
state.now=120
check(cannon.Attack(v)==true and #shots==3,"empty loaded type cannot use other type's reserve")
print("PASS: "..count.." typed weapon contracts (mock API; GMod verification pending)")
