-- Sound lifecycle contracts; no actual GMod mixer or playback is simulated.
local root = arg[1] or "."
local now, emitted, stopped, removed, checks = 10, {}, {}, 0, 0
SERVER = true
CHAN_ITEM = 3
function CurTime() return now end
ENT = {OnRemoved=function() removed=removed+1 end}
dofile(root.."/lua/t72a/sh_autoloader.lua")
local vehicle = setmetatable({hp=2500,reload=17.1},{__index=ENT})
function vehicle:GetHP() return self.hp end
function vehicle:GetT72ReloadEnd() return self.reload end
function vehicle:EmitSound(...) emitted[#emitted+1]={...} end
function vehicle:StopSound(path) stopped[#stopped+1]=path end
local function check(value,message) checks=checks+1;assert(value,message) end
check(vehicle:T72StartAutoloader(),"valid reload starts cue")
check(#emitted==1 and emitted[1][1]=="t72a_ural/autoloader.wav","default tank sound")
check(not vehicle:T72StartAutoloader() and #emitted==1,"same deadline cannot stack cue")
now=11;vehicle.reload=18.1
check(vehicle:T72StartAutoloader(),"a new valid reload schedule restarts cue")
check(#stopped==1 and #emitted==2,"old cue stopped before replacement")
vehicle:T72AutoloaderThink()
check(#stopped==1,"cue retained while still loading")
now=18.1;vehicle:T72AutoloaderThink()
check(#stopped==2 and vehicle._T72LoaderSound==nil,"stop on reload deadline")
check(not vehicle:T72StartAutoloader(),"completed reload cannot play cue")
now=20;vehicle.reload=27.1;vehicle.hp=0
check(not vehicle:T72StartAutoloader() and #emitted==2,"destroyed tank cannot start audio")
vehicle.hp=2500;vehicle:T72StartAutoloader();vehicle.hp=0
vehicle:T72AutoloaderThink()
check(vehicle._T72LoaderSound==nil,"destruction stops cue")
vehicle.hp=2500;vehicle:T72StartAutoloader();vehicle:OnRemoved()
check(vehicle._T72LoaderSound==nil and removed==1,"remove preserves base hook and stops cue")
local other=setmetatable({hp=2500,reload=28,T72AutoloaderSound="t64a_1971/loader.wav"},{__index=vehicle})
check(other:T72StartAutoloader(),"other tank can use same helper")
check(emitted[#emitted][1]=="t64a_1971/loader.wav","variant uses its own cue")
print("PASS: "..checks.." autoloader sound lifecycle contracts (mock API)")
