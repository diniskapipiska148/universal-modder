-- HUD contract tests with optional SVG drawing-call preview, not a GMod render.
-- texlua tests/hud_smoke.lua . [/path/to/scope-preview.svg]
local root=arg[1] or "."
local recorded,labels,polygons,drawcalls={}, {},0,0
local current={r=255,g=255,b=255,a=255}
local fontSizes={}
local function xml(s) return tostring(s):gsub('&','&amp;'):gsub('<','&lt;'):gsub('>','&gt;'):gsub('"','&quot;') end
local function colour(c) return string.format('rgb(%d,%d,%d)',c.r,c.g,c.b) end
local function svgAttributes(c) return ' stroke="'..colour(c)..'" stroke-opacity="'..((c.a or 255)/255)..'"' end
local function record(value) drawcalls=drawcalls+1;recorded[#recorded+1]=value end
function Color(r,g,b,a) return {r=r,g=g,b=b,a=a or 255} end
TEXT_ALIGN_LEFT=0;TEXT_ALIGN_RIGHT=1;TEXT_ALIGN_CENTER=2;TEXT_ALIGN_TOP=3;MASK_SHOT=1
function IsValid(e) return e~=nil and e.valid~=false end
local now=100
function CurTime() return now end
math.Clamp=function(n,a,b) return math.max(a,math.min(n,b)) end
surface={}
function surface.CreateFont(name,data) fontSizes[name]=data.size end
function surface.SetDrawColor(c,g,b,a)
 if type(c)=='table' then current=c else current=Color(c,g,b,a) end
end
function surface.DrawLine(x1,y1,x2,y2)
 record(string.format('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f"%s/>',x1,y1,x2,y2,svgAttributes(current)))
end
function surface.DrawRect(x,y,w,h)
 record(string.format('<rect x="%.2f" y="%.2f" width="%.2f" height="%.2f" fill="%s" fill-opacity="%.2f"/>',x,y,w,h,colour(current),current.a/255))
end
function surface.DrawOutlinedRect(x,y,w,h,thickness)
 record(string.format('<rect x="%.2f" y="%.2f" width="%.2f" height="%.2f" fill="none" stroke-width="%.2f"%s/>',x,y,w,h,thickness or 1,svgAttributes(current)))
end
function surface.DrawCircle(x,y,r,red,green,blue,alpha)
 record(string.format('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="none"%s/>',x,y,r,svgAttributes(Color(red,green,blue,alpha))))
end
function surface.DrawPoly(points)
 polygons=polygons+1
 local result={}
 for _,p in ipairs(points) do result[#result+1]=string.format('%.2f,%.2f',p.x,p.y) end
 record('<polygon points="'..table.concat(result,' ')..'" fill="'..colour(current)..'" fill-opacity="'..(current.a/255)..'"/>')
end
draw={NoTexture=function() end}
function draw.RoundedBox(radius,x,y,w,h,c)
 record(string.format('<rect x="%.2f" y="%.2f" width="%.2f" height="%.2f" rx="%.2f" fill="%s" fill-opacity="%.2f"/>',x,y,w,h,radius,colour(c),c.a/255))
end
function draw.SimpleTextOutlined(value,font,x,y,c,align)
 labels[tostring(value)]=true
 local anchor=align==TEXT_ALIGN_RIGHT and 'end' or (align==TEXT_ALIGN_CENTER and 'middle' or 'start')
 record(string.format('<text x="%.2f" y="%.2f" font-family="DejaVu Sans" font-size="%d" fill="%s" text-anchor="%s" dominant-baseline="hanging">%s</text>',x,y,fontSizes[font] or 18,colour(c),anchor,xml(value)))
end
util={TraceLine=function() return {HitPos={ToScreen=function() return {visible=true,x=970,y=536} end}} end}
dofile(root..'/lua/t72a/cl_hud.lua')
local values={HP=2100,MaxHP=2500,Reverse=false,Gear=4,EngineActive=true,SelectedWeapon=1,NWAmmo=38,MaxAmmo=39,
 T72ReloadEnd=104,T72Range=538,TurretYaw=23, T72AmmoType=1,T72PendingAmmoType=2}
local vehicle={T72A=true,T72ReloadDuration=7.1,T72SightFOV=25}
for k in pairs(values) do vehicle['Get'..k]=function() return values[k] end end
function vehicle:GetAngles() return {y=354} end
local direction=setmetatable({},{__mul=function() return {} end})
local position=setmetatable({},{__add=function() return {} end})
function vehicle:GetT72Muzzle(mg)
 assert(mg==(values.SelectedWeapon==2),'bore marker used wrong weapon')
 return {Pos=position,Ang={Forward=function() return direction end}}
end
function vehicle:GetCrosshairFilterEnts() return {self} end
function vehicle:GetVelocity() return {Length=function() return 350 end} end
local counts={18,9,12}
function vehicle:T72GetAmmoCount(id) return counts[id] end
function vehicle:T72GetAmmoDefinition(id) return ({ {Short='БОПС'},{Short='КС'},{Short='ОФ'} })[id] end
local zoom,third=false,true
local pod={GetThirdPersonMode=function() return third end}
local ply={lvsKeyDown=function() return zoom end,GetVehicle=function() return pod end}
local function reset() labels={};recorded={};polygons=0 end
for _,size in ipairs({{800,600},{1280,720},{1920,1080},{3840,2160}}) do
 reset();third=true;zoom=true
 T72AHUD.Paint(vehicle,size[1],size[2],ply)
 assert(polygons==0,'third person must not receive optical mask')
 reset();third=false;zoom=false
 T72AHUD.Paint(vehicle,size[1],size[2],ply)
 assert(polygons==0,'unzoomed first person must not receive optical mask')
 reset();zoom=true
 T72AHUD.Paint(vehicle,size[1],size[2],ply)
 assert(polygons==72,'scoped first person must receive circular optical mask')
 assert(labels['БОПС'] and labels['КС'] and labels['ОФ'],'ammo selectors absent')
 assert(labels['мрад'],'calibrated angular reticle missing')
 assert(labels['→ КС'],'pending ammo change missing')
 assert(labels['ДАЛЬНОСТЬ 538 м'],'range readout missing')
end
local a=T72AHUD.SightLayout(1920,1080,25)
local b=T72AHUD.SightLayout(3840,2160,25)
assert(math.abs(b.pixelsPerMil/a.pixelsPerMil-2)<1e-9,'reticle must follow physical pixel scale')
assert(T72AHUD.SightLayout(1920,1080,15).pixelsPerMil>a.pixelsPerMil,'zoom must increase angular tick spacing')
assert(T72AHUD.SightLayout(2560,1080,25).pixelsPerMil==a.pixelsPerMil,'ultrawide aspect correction mismatch')
values.Gear=-1;reset();T72AHUD.Paint(vehicle,1920,1080,ply)
assert(labels['АВТО'],'automatic gearbox label absent')
values.SelectedWeapon=2;values.NWAmmo=0;values.HP=0;reset();T72AHUD.Paint(vehicle,1920,1080,ply)
assert(labels['УНИЧТ.'] and not labels['ГОТОВ'],'destroyed vehicle reports ready')
values.HP=100;reset();T72AHUD.Paint(vehicle,1920,1080,ply)
assert(labels['ПУСТО'] and not labels['ГОТОВ'],'empty MG reports ready')
values.SelectedWeapon=1;counts[2]=0;reset();T72AHUD.Paint(vehicle,1920,1080,ply)
assert(labels['ПУСТО'],'empty pending shell reserve reports ready')
counts[2]=9;values.HP=2100;values.Gear=4;reset();T72AHUD.Paint(vehicle,1920,1080,ply)
if arg[2] then
 local output=assert(io.open(arg[2],'w'))
 output:write('<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><rect width="1920" height="1080" fill="#65735d"/><path d="M0 600 L250 550 L500 580 L740 530 L1000 565 L1320 515 L1600 570 L1920 540 L1920 1080 L0 1080 Z" fill="#48533b"/>')
 output:write(table.concat(recorded,'\n'))
 output:write('<text x="12" y="1071" fill="#b8b8b8" font-family="DejaVu Sans" font-size="14">HUD layout preview on mock API — not an in-game screenshot</text></svg>')
 output:close()
end
vehicle.GetT72Range=nil;vehicle.GetT72ReloadEnd=nil
T72AHUD.Paint(vehicle,1920,1080,ply)
vehicle.T72A=false
local previous=drawcalls;T72AHUD.Paint(vehicle,1920,1080,ply)
assert(drawcalls==previous,'HUD leaked to unrelated vehicle')
print('PASS: HUD optics/normal mode, 4 resolutions, FOV angular scale, ammo cards/switch, status/empty/destroyed and unrelated-vehicle isolation (mock API)')
