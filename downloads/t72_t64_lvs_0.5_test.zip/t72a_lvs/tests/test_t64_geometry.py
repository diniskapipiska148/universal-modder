"""Original model export checks; these do not execute Garry's Mod."""
import importlib.util
import json
import math
from pathlib import Path
import re
import struct
import unittest
import zlib

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('t64_original_model_builder',ROOT/'tools/build_t64a_model.py')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)

class OriginalT64Geometry(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.parts,cls.triangles=model.build()
 def test_original_component_inventory_and_budget(self):
  self.assertEqual(len(self.parts),21)
  self.assertTrue({'hull','turret','gun','track_left','track_right'}<=set(self.parts))
  self.assertTrue(all('wheel_'+side+str(i) in self.parts for side in ('L','R') for i in range(1,7)))
  self.assertGreater(sum(map(len,self.triangles.values())),60000)
  self.assertLess(sum(map(len,self.triangles.values())),180000)
 def test_closed_main_hull_has_outward_faces(self):
  # Audit the actual continuous primary hull separately from attached hardware.
  count=model.QA.get('HullShellTriangleCount',0)
  self.assertGreaterEqual(count,12)
  inside=(0,0,45)
  for tri in self.triangles['hull','armor'][:count]:
   centre=tuple(sum(v[0][i] for v in tri)/3 for i in range(3))
   self.assertGreater(model.dot(tri[0][1],model.sub(centre,inside)),0)
 def test_finite_vertices_unit_normals_and_matching_winding(self):
  for key,triangles in self.triangles.items():
   for tri in triangles:
    a,b,c=[v[0] for v in tri]
    geometric=model.unit(model.cross(model.sub(b,a),model.sub(c,a)))
    for pos,normal,uv in tri:
     self.assertTrue(all(math.isfinite(x) for x in (*pos,*normal,*uv)))
     self.assertAlmostEqual(model.dot(normal,normal),1,places=5)
     self.assertGreater(model.dot(geometric,normal),-.001, key)
 def test_correct_logical_pivots_and_original_materials(self):
  self.assertEqual(self.parts['turret']['Pivot'],[-8,0,65])
  self.assertEqual(self.parts['gun']['Pivot'],[45,0,82])
  self.assertEqual(self.parts['wheel_L1']['Pivot'],[112,77,19])
  self.assertEqual(self.parts['wheel_R6']['Pivot'],[-98,-77,19])
  self.assertEqual(set(m for p,m in self.triangles),{'armor','darksteel','rubber','tracks','glass','lamp','wood','cloth'})
 def test_render_bounds_contain_full_turret_gun_and_wheel_sweeps(self):
  # Test the authored vertices, including attached fittings, against the actual
  # shipped bounds. A neutral-pose box misses a gun turned sideways or aft.
  import numpy as np
  profile=(ROOT/'lua/t64a_1971/sh_generated_profile.lua').read_text()
  def vector(name):
   match=re.search(r'\b'+name+r'\s*=\s*Vector\(([^)]+)\)',profile)
   self.assertIsNotNone(match,name)
   return np.array([float(value) for value in match.group(1).split(',')])
  render_min,render_max=vector('RenderMins'),vector('RenderMaxs')
  turret_pivot,gun_pivot=vector('TurretPivot'),vector('GunPivot')
  pitch_min,pitch_max=[math.radians(float(re.search(r'\b'+name+r'=([-\d.]+)',profile).group(1)))
                       for name in ('PitchMin','PitchMax')]
  def trig_range(a,b):
   # Exact extrema of a*cos(p)+b*sin(p) over the allowed pitch interval:
   # endpoints plus stationary angles. No sampling can skip a thin fitting.
   values=[a*math.cos(p)+b*math.sin(p) for p in (pitch_min,pitch_max)]
   stationary=np.arctan2(b,a)
   for turn in (-1,0,1):
    p=stationary+turn*math.pi
    values.append(np.where((p>=pitch_min)&(p<=pitch_max),a*np.cos(p)+b*np.sin(p),np.nan))
   return np.nanmin(values,axis=0),np.nanmax(values,axis=0)
  minima,maxima=[],[]
  for (name,_),triangles in self.triangles.items():
   part=self.parts[name];pivot=np.asarray(part['Pivot'],dtype=float)
   points=np.asarray([vertex[0] for triangle in triangles for vertex in triangle])
   if part['Kind'] in ('turret','gun'):
    if part['Kind']=='gun':
     points=points+pivot-gun_pivot
     offset=gun_pivot-turret_pivot
     xmin,xmax=trig_range(points[:,0],points[:,2])
     x_radius=np.maximum(np.abs(offset[0]+xmin),np.abs(offset[0]+xmax))
     radius=np.hypot(x_radius,offset[1]+points[:,1])
     zmin,zmax=trig_range(points[:,2],-points[:,0])
     zmin,zmax=zmin+gun_pivot[2],zmax+gun_pivot[2]
    else:
     points=points+pivot-turret_pivot
     radius=np.hypot(points[:,0],points[:,1])
     zmin=zmax=points[:,2]+turret_pivot[2]
    # All yaw angles are covered analytically by the horizontal radius.
    r=float(radius.max())
    minima.append([turret_pivot[0]-r,turret_pivot[1]-r,float(zmin.min())])
    maxima.append([turret_pivot[0]+r,turret_pivot[1]+r,float(zmax.max())])
   elif part['Kind']=='wheel':
    # Wheel animation is a full rotation about local Y, including idlers/gears.
    radius=np.hypot(points[:,0],points[:,2])
    r=float(radius.max())
    minima.append([pivot[0]-r,pivot[1]+float(points[:,1].min()),pivot[2]-r])
    maxima.append([pivot[0]+r,pivot[1]+float(points[:,1].max()),pivot[2]+r])
   else:
    points=points+pivot
    minima.append(points.min(axis=0));maxima.append(points.max(axis=0))
  actual_min=np.min(minima,axis=0);actual_max=np.max(maxima,axis=0)
  self.assertTrue(np.all(actual_min>=render_min-1e-6),
                  f'animated minimum {actual_min} exceeds RenderMins {render_min}')
  self.assertTrue(np.all(actual_max<=render_max+1e-6),
                  f'animated maximum {actual_max} exceeds RenderMaxs {render_max}')
 def test_repeat_build_does_not_duplicate_geometry(self):
  before=sum(map(len,self.triangles.values()))
  _,again=model.build()
  self.assertEqual(sum(map(len,again.values())),before)
 def test_exported_shards_fit_client_network_limit(self):
  paths=list((ROOT/'lua/t64a_1971/geometry').glob('chunk_*.lua'))
  self.assertGreater(len(paths),1)
  for p in paths:
   raw=p.read_bytes()
   self.assertLess(len(zlib.compress(raw)),60000,p.name)
   self.assertIn(b't64a_1971/',raw)
  data=json.loads((ROOT/'assets/source/t64a_1971/model_geometry.json').read_text())
  self.assertEqual(sum(len(m['triangles']) for m in data['meshes']),sum(map(len,self.triangles.values())))
 def test_portable_glb_container_is_complete(self):
  p=ROOT/'assets/source/t64a_1971/t64a_1971.glb'
  if not p.exists(): self.skipTest('optional original source export not generated')
  data=p.read_bytes()
  self.assertEqual(data[:4],b'glTF')
  self.assertEqual(struct.unpack_from('<II',data,4),(2,len(data)))
  n,kind=struct.unpack_from('<II',data,12)
  self.assertEqual(kind,0x4E4F534A)
  meta=json.loads(data[20:20+n]);self.assertGreater(len(meta['meshes']),10)
  self.assertGreater(len(meta.get('materials',[])),4)
  # An older editable model can be a valid GLB while containing the wrong tank.
  # Compare the shipped triangles to the runtime asset, and exclude studio data.
  count=0
  for mesh in meta['meshes']:
   for primitive in mesh['primitives']:
    self.assertEqual(primitive.get('mode',4),4)
    count+=meta['accessors'][primitive['indices']]['count']//3
  self.assertEqual(count,sum(map(len,self.triangles.values())))
  self.assertFalse(meta.get('cameras'))
  self.assertNotIn('KHR_lights_punctual',meta.get('extensionsUsed',[]))

if __name__=='__main__':unittest.main()
