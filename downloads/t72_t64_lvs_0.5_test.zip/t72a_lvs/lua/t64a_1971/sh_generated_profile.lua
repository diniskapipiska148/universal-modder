-- Original generated T-64A1971 game-art geometry; not an engineering survey.
local left,right={},{}
for i,x in ipairs({112,70,28,-14,-56,-98}) do left[i]=Vector(x,77,19);right[i]=Vector(x,-77,19) end
return {
 Ready=true,Model="models/hunter/blocks/cube025x025x025.mdl",VisualYaw=0,
 HullMins=Vector(-164,-70,29),HullMaxs=Vector(168,70,101),
 -- Include the complete yaw/pitch sweep of the long barrel, not just neutral pose.
 RenderMins=Vector(-336,-328,-4),RenderMaxs=Vector(320,328,168),
 DriverSeat={Pos=Vector(70,-15,45),Ang=Angle(0,-90,0)},
 Engine={Pos=Vector(-95,0,48),Ang=Angle(0,0,0)},
 Wheels={Left=left,Right=right,DriveIndex=3,Model="models/props_vehicles/tire001c_car.mdl",Radius=14.5,Width=14},
 Suspension={Height=7,MaxTravel=7,ControlArmLength=150,SpringConstant=42000,SpringDamping=1800,SpringRelativeDamping=2000},
 Turret={AimRate=16,PitchMin=-14,PitchMax=6},TrackUVUnits=10,
 Rig={TurretPivot=Vector(-8,0,65),GunPivot=Vector(45,0,82),CannonMuzzle=Vector(313,0,82),MGMuzzle=Vector(59,-9,79),Sight=Vector(60,-18,103)}
}
