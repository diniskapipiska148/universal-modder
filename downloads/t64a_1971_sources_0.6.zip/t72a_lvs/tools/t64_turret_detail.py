"""Original high-detail cast-turret and gun geometry for the T-64A study.

The public entry point is build(api), where api is build_t64a_model.  Only
the existing turret and gun logical parts are emitted; no mesh is imported.
This is authored game art, not a claim of measured factory geometry.
"""
from __future__ import annotations
import math

TAU = math.tau


def build(api):
    tri, quad, cyl = api.triangle, api.quad, api.cylinder
    add, sub, mul, unit, cross = api.add, api.sub, api.mul, api.unit, api.cross

    def axes(axis):
        n = unit(axis)
        u = unit(cross((0, 0, 1) if abs(n[2]) < .9 else (0, 1, 0), n))
        return n, u, cross(n, u)

    def point(c, u, v, x, y):
        return add(c, add(mul(u, x), mul(v, y)))

    def torus(part, mat, center, axis, radius, tube=.3, sectors=48, sides=8):
        n, u, v = axes(axis)
        def at(a, b):
            radial = add(mul(u, math.cos(a)), mul(v, math.sin(a)))
            normal = add(mul(radial, math.cos(b)), mul(n, math.sin(b)))
            return add(center, add(mul(radial, radius), mul(normal, tube))), normal
        for i in range(sectors):
            for j in range(sides):
                aa, ab = i / sectors * TAU, (i + 1) / sectors * TAU
                ba, bb = j / sides * TAU, (j + 1) / sides * TAU
                values = [at(aa, ba), at(ab, ba), at(ab, bb), at(aa, bb)]
                quad(part, mat, *[q[0] for q in values],
                     uv=[(i/sectors,j/sides),((i+1)/sectors,j/sides),
                         ((i+1)/sectors,(j+1)/sides),(i/sectors,(j+1)/sides)],
                     normals=[q[1] for q in values])

    def bevel_box(part, mat, center, size, bevel=.45, yaw=0):
        x, y, z = center
        hx, hy, hz = [q * .5 for q in size]
        bevel = min(bevel, hx * .45, hy * .45, hz * .45)
        co, si = math.cos(yaw), math.sin(yaw)
        def ring(inset, zz):
            a, b = hx - inset, hy - inset
            cut = max(bevel - inset, .05)
            xy = [(-a+cut,-b),(a-cut,-b),(a,-b+cut),(a,b-cut),
                  (a-cut,b),(-a+cut,b),(-a,b-cut),(-a,-b+cut)]
            return [(x+px*co-py*si,y+px*si+py*co,z+zz) for px,py in xy]
        layers = [ring(bevel,-hz),ring(0,-hz+bevel),
                  ring(0,hz-bevel),ring(bevel,hz)]
        for a, b in zip(layers,layers[1:]):
            for i in range(8):
                j=(i+1)%8
                quad(part,mat,a[i],a[j],b[j],b[i])
        for i in range(8):
            j=(i+1)%8
            tri(part,mat,(x,y,z-hz),layers[0][j],layers[0][i])
            tri(part,mat,(x,y,z+hz),layers[-1][i],layers[-1][j])

    def bolt(part, pos, radius=.8, height=.65, axis=(0,0,1), mat='darksteel'):
        n, _, _ = axes(axis)
        cyl(part,mat,pos,add(pos,mul(n,height)),radius,6)

    def handle(part, center, length=8, height=2, yaw=0, radius=.5):
        # A continuous bent rod, with welded feet, rather than three big blocks.
        x,y,z=center;co,si=math.cos(yaw),math.sin(yaw)
        path=[]
        for i in range(7):
            a=math.pi-i/6*math.pi*.5
            path.append((-length*.5+height+height*math.cos(a),height*math.sin(a)))
        path.append((length*.5-height,height))
        for i in range(1,7):
            a=math.pi*.5-i/6*math.pi*.5
            path.append((length*.5-height+height*math.cos(a),height*math.sin(a)))
        path=[(x+px*co,y+px*si,z+pz) for px,pz in path]
        for a,b in zip(path,path[1:]):cyl(part,'darksteel',a,b,radius,8)
        for sign in (-1,1):
            px=x+sign*length*.5*co;py=y+sign*length*.5*si
            bevel_box(part,'armor',(px,py,z-.15),(2.1,2.1,.6),.15)

    def line(part,mat,points,radius=.4,sectors=10):
        for a,b in zip(points,points[1:]):cyl(part,mat,a,b,radius,sectors)

    def optic_window(part,center,width,height,yaw=0):
        """A recessed optical face with four separate cast lip sections."""
        n=(math.cos(yaw),math.sin(yaw),0)
        side=(-math.sin(yaw),math.cos(yaw),0)
        def at(depth,lateral=0,vertical=0):
            return add(center,add(mul(n,depth),add(mul(side,lateral),(0,0,vertical))))
        bevel_box(part,'darksteel',at(-.24),(.30,width+.48,height+.48),.10,yaw)
        bevel_box(part,'glass',at(-.035),(.08,width-.20,height-.20),.035,yaw)
        for zoff in (-height*.5-.14,height*.5+.14):
            bevel_box(part,'armor',at(.12,0,zoff),(.56,width+.76,.35),.10,yaw)
        for yoff in (-width*.5-.14,width*.5+.14):
            bevel_box(part,'armor',at(.12,yoff),(.56,.35,height+.26),.10,yaw)

    def knuckle_hinge(part,center,length=5.4,axis=(0,1,0),radius=.54):
        n=unit(axis)
        # Separate sleeves expose the central pin and alternate hinge leaves.
        a=add(center,mul(n,-length*.5))
        cyl(part,'darksteel',add(a,mul(n,-.45)),add(a,mul(n,length+.45)),radius*.55,10)
        for frac,size in ((0,.27),(.34,.32),(.73,.27)):
            start=add(a,mul(n,length*frac));end=add(start,mul(n,length*size))
            cyl(part,'armor',start,end,radius,12)
        for sign in (-1,1):
            cap=add(center,mul(n,sign*(length*.5+.42)))
            bolt(part,cap,radius*.60,.22,mul(n,sign),mat='darksteel')

    # The screenshots show a very broad cast turret, not an egg perched on a
    # narrow ring. These asymmetric plan control points define its cheeks,
    # broad shoulders and pinched aft bustle independently of roof elevation.
    # Long near-straight shoulders and a short broad front distinguish the
    # revised cast shape from a circular/domed turret. The aft return is cut
    # tighter, while the two front cheeks keep their independent slopes.
    contour=[(61,-12),(61,12),(53,34),(41,52),(15,66),(-22,67),
             (-53,57),(-72,35),(-77,12),(-77,-16),(-65,-43),
             (-42,-62),(-6,-67),(22,-60),(44,-42),(56,-22)]
    def plan(t):
        t=(t%1)*len(contour);i=int(t);f=t-i
        a,b,c,d=[contour[k%len(contour)] for k in (i-1,i,i+1,i+2)]
        curved=tuple(.5*((2*b[j])+(-a[j]+c[j])*f+
            (2*a[j]-5*b[j]+4*c[j]-d[j])*f*f+
            (-a[j]+3*b[j]-3*c[j]+d[j])*f*f*f) for j in (0,1))
        return tuple(curved[j]*.68+(b[j]+(c[j]-b[j])*f)*.32 for j in (0,1))
    # The roof is a broad plate-like casting crown. Most side taper occurs in
    # a defined shoulder band; it no longer rolls continuously into an egg.
    layers=[(64.8,.87,.87,0),(66,.95,.95,0),(70.0,1,1,-.3),
            (80.5,1,1,-.5),(87.8,.98,.99,-1.2),
            (91.6,.91,.94,-2.5),(94.4,.83,.89,-3.8),
            (95.5,.79,.865,-4.5),(98.0,.77,.85,-4.9)]
    def shell_point(k,t):
        z,sx,sy,dx=layers[k];x,y=plan(t)
        # Small slow casting irregularities are geometric, without fake rings.
        bulge=.18*math.sin(t*TAU*7+.4)*math.sin(k/(len(layers)-1)*math.pi)
        return (x*sx+dx+bulge,y*sy+bulge*.6,z)
    def shell_normal(k,t):
        around=sub(shell_point(k,t+.0002),shell_point(k,t-.0002))
        up=sub(shell_point(min(k+1,len(layers)-1),t),shell_point(max(k-1,0),t))
        return unit(cross(around,up))
    sectors=120
    for k in range(len(layers)-1):
        for i in range(sectors):
            a,b=i/sectors,(i+1)/sectors
            coords=[shell_point(k,a),shell_point(k,b),shell_point(k+1,b),shell_point(k+1,a)]
            normals=[shell_normal(k,a),shell_normal(k,b),shell_normal(k+1,b),shell_normal(k+1,a)]
            quad('turret','armor',*coords,uv=[(p[0]/55,p[1]/55) for p in coords],normals=normals)
    for k,up in ((0,False),(len(layers)-1,True)):
        for i in range(sectors):
            a,b=shell_point(k,i/sectors),shell_point(k,(i+1)/sectors)
            tri('turret','armor',(-15,0,layers[k][0]),*((a,b) if up else (b,a)))
    cyl('turret','darksteel',(-8,0,63.8),(-8,0,65.1),52.2,96)
    torus('turret','darksteel',(-8,0,65.0),(0,0,1),52.8,.33,96,6)
    # A restrained cast parting bead. The seam is not a perfectly machined
    # decorative ring: tiny changes of width and height follow the shell.
    seam=[add(shell_point(2,i/120),(0,0,.07*math.sin(i*.71))) for i in range(121)]
    for i,(a,b) in enumerate(zip(seam,seam[1:])):
        cyl('turret','armor',a,b,.14+.025*math.sin(i*1.3),6)

    # The asymmetric TPD sight/rangefinder enclosure is the identifying block
    # on the left cheek. Three recessed covers, rather than fictitious circular
    # side windows, follow its long angled face.
    bevel_box('turret','armor',(14,61.2,86.8),(58,21,21),2.5,yaw=.06)
    bevel_box('turret','armor',(13.6,72.0,86.4),(54,1.2,18.8),.6,yaw=.06)
    for x in (-5,13,31):
        cy=72.7+(x-13)*.06
        bevel_box('turret','armor',(x,cy+.42,86.5),(15.85,.72,18.1),.65,yaw=.06)
        bevel_box('turret','darksteel',(x,cy+.84,86.5),(15.45,.10,17.7),.16,yaw=.06)
        bevel_box('turret','armor',(x,cy+.94,86.6),(15.10,.18,17.35),.16,yaw=.06)
        # Pressed sheet covers have a shallow reinforcing rectangle rather
        # than thick black screen-like bezels. Thin rails follow the cover yaw.
        def oncover(xx,zz,depth=1.07):
            return (xx,cy+(xx-x)*.06+depth,zz)
        outline=[oncover(x-4.7,81),oncover(x+4.7,81),oncover(x+5.2,81.5),
                 oncover(x+5.2,91.4),oncover(x+4.7,91.9),oncover(x-4.7,91.9),
                 oncover(x-5.2,91.4),oncover(x-5.2,81.5),oncover(x-4.7,81)]
        line('turret','armor',outline,.10,6)
        for xx in (x-5.4,x+5.4):
            bolt('turret',oncover(xx,80,1.1),.32,.23,(0,1,0))
        knuckle_hinge('turret',(x,cy+1.07,95.6),7.3,(1,.06,0),.42)
        bevel_box('turret','darksteel',oncover(x,78.9,1.18),(2.4,.50,2.1),.13,yaw=.06)
        bevel_box('turret','armor',oncover(x,79.4,1.48),(3.3,.34,.68),.12,yaw=.06)
    bevel_box('turret','armor',(39,39,99.4),(23,14,2.4),.8,yaw=-.2)
    for x,y in ((35,34),(46,37),(28,43)):
        bolt('turret',(x,y,100.6),.6,.55)

    # Commander cupola on the right: raised fixed periscope band and a low
    # domed hatch. The second hatch sits lower on the left rear roof.
    x,y,z=-25,-28,98
    cyl('turret','darksteel',(x,y,z-.2),(x,y,z+.65),19.5,72)
    cyl('turret','armor',(x,y,z+.5),(x,y,z+5.0),18.5,72,r2=18)
    torus('turret','darksteel',(x,y,z+4.8),(0,0,1),17.8,.30,64,6)
    api.dome('turret','armor',(x,y,z+5),(17.5,17.5,3.6),64,8)
    for deg in (-50,-10,30,70,110,150):
        angle=math.radians(deg);co,si=math.cos(angle),math.sin(angle)
        px=x+16.8*co;py=y+16.8*si
        bevel_box('turret','armor',(px,py,z+4),(6.3,4.5,4.2),.5,yaw=angle)
        optic_window('turret',(px+3.18*co,py+3.18*si,z+4.7),3.5,1.85,angle)
    handle('turret',(x+2,y,z+8.6),8,1.4,yaw=.3,radius=.4)
    for yy in (y-6,y+6):
        bevel_box('turret','armor',(x-16,yy,z+6),(4.7,3.0,3.0),.5)
        knuckle_hinge('turret',(x-17,yy,z+6),4.4,(0,1,0),.85)
        for sx in (-1,1):
            bolt('turret',(x-15.7,yy+sx*.9,z+7.55),.38,.3)
    # Raised locking lever, its pivot and the fixed hatch stop are independent
    # from the hatch shell; small spaces remain visible between the pieces.
    bevel_box('turret','armor',(x+15.7,y,z+6.8),(4.8,4.0,1.6),.35)
    cyl('turret','darksteel',(x+15.5,y,z+7.6),(x+15.5,y,z+8.4),1.0,16)
    bevel_box('turret','darksteel',(x+13.3,y,z+8.4),(6.4,1.0,.65),.20,yaw=.2)
    bevel_box('turret','armor',(x+20,y,z+4.3),(2.1,4.5,2.4),.4)
    # Commander observation head, a small angled optical barrel and support.
    bevel_box('turret','armor',(x+11,y+3,z+10),(10,7,5),1.0,yaw=-.15)
    cyl('turret','armor',(x+15,y+3,z+10),(x+23,y+3,z+12),3.9,28,r2=3.4)
    observation_end=(x+23,y+3,z+12);observation_axis=unit((8,0,2))
    cyl('turret','darksteel',add(observation_end,mul(observation_axis,.02)),add(observation_end,mul(observation_axis,.22)),3.0,32)
    cyl('turret','glass',add(observation_end,mul(observation_axis,.24)),add(observation_end,mul(observation_axis,.29)),2.65,32)
    torus('turret','armor',add(observation_end,mul(observation_axis,.32)),observation_axis,2.93,.18,32,5)
    lx,ly,lz=-35,24,98.0
    cyl('turret','darksteel',(lx,ly,lz),(lx,ly,lz+1),16.6,64)
    cyl('turret','armor',(lx,ly,lz+.9),(lx,ly,lz+2.7),15.8,64,r2=15.4)
    torus('turret','armor',(lx,ly,lz+2.8),(0,0,1),14.7,.35,64,6)
    handle('turret',(lx+1,ly,lz+3),8,1.4,yaw=-.35,radius=.42)
    for yy in (ly-5,ly+5):
        bevel_box('turret','armor',(lx-14,yy,lz+2.1),(4.5,3,3),.45)
        knuckle_hinge('turret',(lx-15,yy,lz+2.4),4.2,(0,1,0),.70)
        for sx in (-1,1):bolt('turret',(lx-13.7,yy+sx*.75,lz+3.55),.34,.25)
    bevel_box('turret','armor',(lx+14.6,ly,lz+1.7),(3.0,4.7,1.4),.3)
    cyl('turret','darksteel',(lx+14.6,ly,lz+2.3),(lx+14.6,ly,lz+3),.7,12)
    bevel_box('turret','darksteel',(lx+12.4,ly,lz+3.0),(5.9,.85,.6),.18,yaw=-.18)
    # Periscope and sight assembly ahead of the left hatch.
    bevel_box('turret','armor',(7,24,100.5),(16,12,6.5),1.2,yaw=.08)
    optic_window('turret',(15.9,24,100.8),8.0,3.3)
    bevel_box('turret','armor',(17,-23,99.5),(12,8,3.6),.7,yaw=.1)
    optic_window('turret',(23.05,-22.4,100.1),5.3,1.8,.1)
    # Bolted maintenance disc and roof seams following actual roof features.
    cyl('turret','darksteel',(-12,5,98),(-12,5,98.3),6.8,32)
    cyl('turret','armor',(-12,5,98.3),(-12,5,98.8),6.2,32)
    for deg in range(0,360,60):
        a=math.radians(deg);bolt('turret',(-12+5.2*math.cos(a),5+5.2*math.sin(a),98.8),.42,.4)
    line('turret','armor',[(4,-19,98.15),(17,-13,98.15),(23,-3,98.15)],.22,6)
    line('turret','armor',[(-44,5,98.15),(-49,4,98.15),(-53,-3,98.15)],.23,6)

    # Luna IR projector, set forward and to the left of the mantlet. The lip,
    # glass, tilted yoke and cable remain separate modeled features.
    bevel_box('turret','armor',(40,32,77.5),(15,17,5.5),1.0)
    for yy in (24,40):bevel_box('turret','darksteel',(44,yy,83.5),(3.2,2,14),.4)
    cyl('turret','armor',(40,32,87.0),(54,32,87.0),10.2,64,r2=9.7)
    cyl('turret','darksteel',(53.8,32,87),(55.2,32,87),10.1,64)
    # A shallow curved lens sits behind its rolled retaining lip. It catches
    # light as an optical component rather than a flat black disc.
    for j in range(4):
        r0,r1=j/4*8.85,(j+1)/4*8.85
        def lenspoint(r,a):
            return (55.28+.24*(1-(r/8.85)**2),32+r*math.cos(a),87+r*math.sin(a))
        for i in range(48):
            aa,bb=i/48*TAU,(i+1)/48*TAU
            vals=[lenspoint(r0,aa),lenspoint(r1,aa),lenspoint(r1,bb),lenspoint(r0,bb)]
            quad('turret','glass',*vals)
    torus('turret','armor',(55.55,32,87),(1,0,0),9.4,.38,64,6)
    # The two fine wires are a retaining guard, not the thick invented cage.
    for angle in (0,math.pi*.5):
        yy,zz=8.8*math.cos(angle),8.8*math.sin(angle)
        cyl('turret','darksteel',(55.8,32-yy,87-zz),(55.8,32+yy,87+zz),.16,6)
    for angle in range(0,360,60):
        aa=math.radians(angle)
        bolt('turret',(55.9,32+9.4*math.cos(aa),87+9.4*math.sin(aa)),.4,.35,(1,0,0))
    line('turret','darksteel',[(42,43,81),(32,46,82),(17,47,91),(10,42,96)],.5,10)
    for center,yaw in [((33,46,82),-.05),((18,47,91),.35)]:
        bevel_box('turret','armor',center,(3.1,2.6,1.1),.25,yaw=yaw)
        bolt('turret',add(center,(0,0,.7)),.38,.3)
    # Cable enters a small threaded gland and returns under a proper mounting
    # foot. These details stay behind the projector's frontal silhouette.
    cyl('turret','darksteel',(40,41.2,84.5),(40,44.0,84.5),1.15,12)
    for yy in (24,40):
        bolt('turret',(44,yy,90.7),.75,.5)
        bevel_box('turret','armor',(39,yy,78.1),(8,4,1.1),.3)

    # Thin stowage boxes follow the right rear cast shoulder. They do not form
    # the oversized rectangular bustle of v0.4.
    for x,y,sz,yaw in [(-35,-65,13,-.20),(-59,-53,13,-.55)]:
        bevel_box('turret','armor',(x,y,82),(22,8,sz),1.0,yaw=yaw)
        bevel_box('turret','armor',(x,y,89),(23,9,1.5),.45,yaw=yaw)
        bevel_box('turret','darksteel',(x,y-4.4,83),(4,1,4),.25,yaw=yaw)

    # OPVT snorkel tube across the turret rear is conspicuous in the reference.
    # Main cylindrical section, narrow curved neck, rolled lip and strap bands.
    cx,cz=-86,87.5
    cyl('turret','armor',(cx,-61,cz),(cx,51,cz),5.6,64)
    cyl('turret','armor',(cx,-64,cz),(cx,-61,cz),4.7,64,r2=5.6)
    torus('turret','darksteel',(cx,-63.7,cz),(0,1,0),4.7,.32,48,6)
    for yy in (-56,-24,10,43):
        cyl('turret','darksteel',(cx,yy-.72,cz),(cx,yy+.72,cz),5.84,48,caps=False)
        for edge in (-.72,.72):
            torus('turret','armor',(cx,yy+edge,cz),(0,1,0),5.84,.09,32,4)
        bevel_box('turret','armor',(-79,yy,83.5),(10,4,4),.5)
        cyl('turret','darksteel',(-81,yy,79.8),(-86,yy,82.1),.75,10)
        bevel_box('turret','darksteel',(cx-5.9,yy,cz),(.7,3.4,3.2),.22)
        bolt('turret',(cx-6.3,yy,cz),.58,.45,(-1,0,0))
    path=[(cx,51,cz),(cx,57,cz),(cx,62,cz+.5),(cx+1,66,cz+2.2),
          (cx+3.5,69,cz+4.4),(cx+7.5,70,cz+5.2),(cx+13,70,cz+5.4)]
    def swept_pipe(points,radius,sectors=40):
        frames=[]
        for k,p in enumerate(points):
            tangent=sub(points[min(k+1,len(points)-1)],points[max(k-1,0)])
            n,u,v=axes(tangent);frames.append((p,n,u,v))
        for k in range(len(frames)-1):
            for i in range(sectors):
                a,b=i/sectors*TAU,(i+1)/sectors*TAU
                values=[];normals=[]
                for j,angle in ((k,a),(k,b),(k+1,b),(k+1,a)):
                    p,n,u,v=frames[j];normal=add(mul(u,math.cos(angle)),mul(v,math.sin(angle)))
                    values.append(add(p,mul(normal,radius)));normals.append(normal)
                quad('turret','armor',*values,normals=normals)
        p,n,u,v=frames[-1]
        torus('turret','armor',p,n,radius,.38,48,6)
        cyl('turret','rubber',add(p,mul(n,-1.0)),add(p,mul(n,-.85)),radius-.45,48)
    swept_pipe(path,4.6)

    # Worn folded canvas behind the turret. A closed organic cross section with
    # sewn edges and narrow straps makes the roll part of the actual mesh.
    def canvas_roll(center,length,radius):
        xc,yc,zc=center;ns=56;nr=22
        def at(j,i):
            t=j/nr;angle=i/ns*TAU
            r=radius*(.91+.06*math.sin(t*TAU*3)+.045*math.sin(angle*5+t*8))
            return (xc+r*math.cos(angle),yc+(t-.5)*length,zc+r*.72*math.sin(angle))
        for j in range(nr):
            for i in range(ns):quad('turret','cloth',at(j,i),at(j+1,i),at(j+1,i+1),at(j,i+1))
        for j,sgn in ((0,-1),(nr,1)):
            for i in range(ns):
                a,b=at(j,i),at(j,i+1);tri('turret','cloth',(xc,yc+sgn*length*.5,zc),*((a,b) if sgn<0 else (b,a)))
        # A stitched longitudinal flap and two flattened straps follow the
        # elliptical canvas surface, instead of hovering circular metal hoops.
        line('turret','cloth',[add(at(j,ns*.16),(.10,0,.10)) for j in range(nr+1)],.14,6)
        for t in (.20,.80):
            halfwidth=1.0/length*nr
            for i in range(ns):
                values=[]
                for j,k in ((t*nr-halfwidth,i),(t*nr+halfwidth,i),
                            (t*nr+halfwidth,i+1),(t*nr-halfwidth,i+1)):
                    p=at(j,k)
                    values.append((xc+(p[0]-xc)*1.025,p[1],zc+(p[2]-zc)*1.025))
                quad('turret','cloth',*values)
            yy=yc+(t-.5)*length
            bevel_box('turret','darksteel',(xc-radius*.94,yy,zc),(.65,3.8,3.1),.20)
            bevel_box('turret','cloth',(xc-radius-.26,yy,zc),(.24,2.1,1.1),.07)
    canvas_roll((-72,0,79),92,8.5)
    # Lift eyes, rail and antenna follow the visible asymmetric roof fittings.
    for xx,yy,zz in ((30,-48,87),(34,48,87),(-55,-39,89),(-60,36,88)):
        bevel_box('turret','armor',(xx,yy,zz),(5.7,4,2),.55)
        torus('turret','armor',(xx,yy,zz+2.6),(0,1,0),2.0,.6,28,6)
    cyl('turret','armor',(-46,-2,98),(-46,-2,105),2.6,32,r2=1.8)
    torus('turret','darksteel',(-46,-2,104.5),(0,0,1),2.1,.28,32,6)
    cyl('turret','darksteel',(-46,-2,105),(-46.5,-1.8,161),.34,12,r2=.12)

    # Cloth mantlet cover: broad trapezoidal drape with irregular longitudinal
    # folds, rather than the uniformly corrugated vacuum-hose shape of v0.4.
    boot=[];nr=24;ns=72
    for j in range(nr+1):
        t=j/nr;boot.append((45+31*t,19*(1-t)+6.0*t,13.7*(1-t)+5.8*t))
    def cloth_point(k,a):
        x,ry,rz=boot[k];t=k/nr
        fold=(.9*math.sin(a*5+t*2.4)+.55*math.cos(a*8-t*5))*(math.sin(math.pi*t)**.7)
        sag=-1.1*math.sin(math.pi*t)*(1+math.sin(a))*.5
        return (x,(ry+fold)*math.cos(a),82+(rz+fold*.6)*math.sin(a)+sag)
    for j in range(nr):
        for i in range(ns):
            aa,bb=i/ns*TAU,(i+1)/ns*TAU
            vals=[cloth_point(j,aa),cloth_point(j,bb),cloth_point(j+1,bb),cloth_point(j+1,aa)]
            # Smoothed cloth normals derived from the actual drape surface.
            normals=[]
            for k,a in ((j,aa),(j,bb),(j+1,bb),(j+1,aa)):
                around=sub(cloth_point(k,a+.001),cloth_point(k,a-.001))
                along=sub(cloth_point(min(k+1,nr),a),cloth_point(max(k-1,0),a))
                normals.append(unit(cross(around,along)))
            quad('gun','cloth',*vals,normals=normals)
    for k in (0,nr):
        line('gun','darksteel',[cloth_point(k,i/ns*TAU) for i in range(ns+1)],.22,6)
    # Hem piping and two stitched joins follow the actual sagging drape. The
    # ribs are small enough to read as sewn canvas, not armoured corrugations.
    for angle in (.32*math.pi,1.26*math.pi):
        seam=[cloth_point(k,angle) for k in range(1,nr)]
        seam=[(p[0],p[1]*1.008,82+(p[2]-82)*1.008) for p in seam]
        line('gun','cloth',seam,.105,6)
    for i in range(12):
        angle=(i+.25)/12*TAU
        p=cloth_point(1,angle)
        cyl('gun','armor',(p[0]-.2,p[1]*1.007,82+(p[2]-82)*1.007),
            (p[0]+.18,p[1]*1.007,82+(p[2]-82)*1.007),.30,8)

    # The screenshot's extractor sits in the forward half of the exposed tube.
    # A slender lathed 2A26 with the same canonical bore/muzzle position.
    sections=[(73,5.95),(77,5.7),(79,4.7),(85,4.55),(185,4.15),
              (189,5.8),(192,6.1),(231,6.1),(235,5.7),(238,4.05),
              (302,3.55),(311.5,3.5),(313,3.5)]
    n=72
    for k in range(len(sections)-1):
        x0,r0=sections[k];x1,r1=sections[k+1]
        slope=(r0-r1)/(x1-x0)
        for i in range(n):
            aa,bb=i/n*TAU,(i+1)/n*TAU
            values=[(x0,r0*math.cos(aa),82+r0*math.sin(aa)),
                    (x0,r0*math.cos(bb),82+r0*math.sin(bb)),
                    (x1,r1*math.cos(bb),82+r1*math.sin(bb)),
                    (x1,r1*math.cos(aa),82+r1*math.sin(aa))]
            normals=[unit((slope,math.cos(a),math.sin(a))) for a in (aa,bb,bb,aa)]
            quad('gun','armor',*values,
                 uv=[(x0/40,i/n),(x0/40,(i+1)/n),(x1/40,(i+1)/n),(x1/40,i/n)],normals=normals)
    for xx,rr in ((79,4.75),(190,5.95),(234,5.85),(310.5,3.58)):
        torus('gun','armor',(xx,0,82),(1,0,0),rr,.16,64,6)
    # Extractor seam and small retaining screws are modeled, not painted.
    for xx in (192,231):
        for deg in (45,135,225,315):
            a=math.radians(deg)
            p=(xx,6.12*math.cos(a),82+6.12*math.sin(a))
            bolt('gun',p,.34,.3,(0,math.cos(a),math.sin(a)),mat='armor')
    for i in range(n):
        aa,bb=i/n*TAU,(i+1)/n*TAU
        outer=[(313,3.5*math.cos(a),82+3.5*math.sin(a)) for a in (aa,bb)]
        inner=[(313,2.85*math.cos(a),82+2.85*math.sin(a)) for a in (aa,bb)]
        quad('gun','darksteel',outer[0],outer[1],inner[1],inner[0])
        a,b=inner
        quad('gun','darksteel',b,(299,b[1],b[2]),(299,a[1],a[2]),a)
        tri('gun','rubber',(298.9,0,82),(298.9,a[1],a[2]),(298.9,b[1],b[2]))
    bevel_box('gun','darksteel',(53,-9,79),(10,4,5),.7)
    cyl('gun','darksteel',(54,-9,79),(59,-9,79),1.55,24,caps=False)
    torus('gun','darksteel',(59,-9,79),(1,0,0),1.55,.24,24,6)
