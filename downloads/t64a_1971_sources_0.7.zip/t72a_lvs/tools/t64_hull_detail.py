"""Original detailed welded T-64A-style hull assembly.

Game-art reconstruction, authored in canonical Source units. No imported mesh.
The exported hull is intentionally separate from turret and running gear.
"""
from __future__ import annotations
import math


def build(api):
    part = 'hull'
    def add(a,b): return tuple(a[i]+b[i] for i in range(3))
    def sub(a,b): return tuple(a[i]-b[i] for i in range(3))
    def mul(a,s): return tuple(v*s for v in a)
    def dot(a,b): return sum(a[i]*b[i] for i in range(3))
    def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
    def unit(a):
        length=math.sqrt(dot(a,a)); return mul(a,1/length) if length else (0,0,1)
    def transform(p,centre,yaw=0,pitch=0):
        cy,sy,cp,sp=math.cos(yaw),math.sin(yaw),math.cos(pitch),math.sin(pitch)
        x,y,z=p; x,z=x*cp+z*sp,-x*sp+z*cp
        return add(centre,(x*cy-y*sy,x*sy+y*cy,z))
    def face(mat,vertices,inside=None):
        vertices=list(vertices)
        if inside is not None:
            n=cross(sub(vertices[1],vertices[0]),sub(vertices[2],vertices[0]))
            centre=tuple(sum(p[i] for p in vertices)/len(vertices) for i in range(3))
            if dot(n,sub(centre,inside))<0: vertices.reverse()
        for i in range(1,len(vertices)-1): api.triangle(part,mat,vertices[0],vertices[i],vertices[i+1])
    def tube(mat,a,b,r,n=12): api.cylinder(part,mat,a,b,r,n)
    def bevel(mat,centre,size,b=.5,yaw=0,pitch=0):
        hx,hy,hz=[v*.5 for v in size]; b=min(b,hx*.65,hy*.65,hz*.65)
        def world(p):return transform(p,centre,yaw,pitch)
        # Six face plates, twelve chamfer strips and eight triangular corners.
        for axis in range(3):
            for sign in (-1,1):
                other=[i for i in range(3) if i!=axis]; h=(hx,hy,hz)
                points=[]
                for s1,s2 in ((-1,-1),(1,-1),(1,1),(-1,1)):
                    p=[0.,0.,0.];p[axis]=sign*h[axis]
                    p[other[0]]=s1*(h[other[0]]-b);p[other[1]]=s2*(h[other[1]]-b)
                    points.append(world(p))
                face(mat,points,centre)
        h=(hx,hy,hz)
        for axis in range(3):
            a,c=[i for i in range(3) if i!=axis]
            for sa in (-1,1):
                for sc in (-1,1):
                    points=[]
                    for t,edge in ((-1,0),(1,0),(1,1),(-1,1)):
                        p=[0.,0.,0.];p[axis]=t*(h[axis]-b)
                        p[a]=sa*(h[a]-(b if edge else 0));p[c]=sc*(h[c]-(0 if edge else b))
                        points.append(world(p))
                    face(mat,points,centre)
        for sx in (-1,1):
            for sy in (-1,1):
                for sz in (-1,1):
                    signs=(sx,sy,sz);points=[]
                    for axis in range(3):
                        points.append(world(tuple(signs[i]*(h[i]-(0 if i==axis else b)) for i in range(3))))
                    face(mat,points,centre)
    def ring(mat,centre,axis,radius,wire=.55,segments=28,sides=6):
        axis=unit(axis);seed=(0,0,1) if abs(axis[2])<.9 else (0,1,0)
        u=unit(cross(seed,axis));v=cross(axis,u)
        def point(i,j):
            a=i/segments*math.tau;b=j/sides*math.tau
            radial=add(mul(u,math.cos(a)),mul(v,math.sin(a)))
            return add(centre,add(mul(radial,radius+math.cos(b)*wire),mul(axis,math.sin(b)*wire)))
        for i in range(segments):
            for j in range(sides):
                pts=[point(i,j),point(i+1,j),point(i+1,j+1),point(i,j+1)]
                # Smooth vertex normals preserve the round steel section.
                normals=[]
                for ii,jj in ((i,j),(i+1,j),(i+1,j+1),(i,j+1)):
                    a=ii/segments*math.tau;b=jj/sides*math.tau
                    radial=add(mul(u,math.cos(a)),mul(v,math.sin(a)))
                    normals.append(add(mul(radial,math.cos(b)),mul(axis,math.sin(b))))
                api.quad(part,mat,*pts,normals=normals)
    def bolt(pos,r=1.05,axis=(0,0,1)):
        end=add(pos,mul(axis,.85));tube('darksteel',pos,end,r,6)
    def line(mat,points,r=.4,n=8):
        for a,b in zip(points,points[1:]):tube(mat,a,b,r,n)
    def weld(points):
        line('armor',points,.32,6)
    def ellipse_plate(mat,centre,rx,ry,height,n=36):
        top=[];bottom=[]
        for i in range(n):
            a=i/n*math.tau;top.append((centre[0]+rx*math.cos(a),centre[1]+ry*math.sin(a),centre[2]+height*.5))
            bottom.append((centre[0]+rx*math.cos(a),centre[1]+ry*math.sin(a),centre[2]-height*.5))
        for i in range(n):
            j=(i+1)%n;face(mat,[bottom[i],bottom[j],top[j],top[i]],centre)
        face(mat,top,centre);face(mat,bottom[::-1],centre)

    # Reference reconstruction: broad thin welded upper glacis, low hull deck,
    # tucked-in lower side plates, and a vertical transmission/rear plate.
    # This closed main shell is emitted first for winding verification.
    profile=[(-164,29,53.5),(148,29,53.5),(172,41.3,60.6),
             (173,45,64.5),(115,65.0,65),(-128,65.0,65),(-164,56.8,62)]
    centre=(0,0,45)
    sides={s:[(x,s*w,z) for x,z,w in profile] for s in (-1,1)}
    for i in range(len(profile)):
        j=(i+1)%len(profile)
        face('armor',[sides[-1][i],sides[1][i],sides[1][j],sides[-1][j]],centre)
    for s in (-1,1):face('armor',sides[s],centre)
    if hasattr(api,'QA'):api.QA['HullShellTriangleCount']=len(api.TRI[(part,'armor')])

    def glacis_z(x):return 65.0-(x-115)*(20.0/58)
    def glacis_strip(a,b,width=1.7,height=1.1):
        # Real welded angle-iron bars follow the sloping plate, not a horizontal
        # generic block placed through it.
        dx,dy=b[0]-a[0],b[1]-a[1];ll=math.hypot(dx,dy)
        nx,ny=-dy/ll*width*.5,dx/ll*width*.5
        lower=[(a[0]+nx,a[1]+ny,glacis_z(a[0])+.28),
               (b[0]+nx,b[1]+ny,glacis_z(b[0])+.28),
               (b[0]-nx,b[1]-ny,glacis_z(b[0])+.28),
               (a[0]-nx,a[1]-ny,glacis_z(a[0])+.28)]
        upper=[(x,y,z+height) for x,y,z in lower]
        face('armor',upper,(0,0,0))
        for i in range(4):face('armor',[lower[i],lower[(i+1)%4],upper[(i+1)%4],upper[i]])
    # A crisp welded transition separates the inclined upper front plate from
    # the horizontal roof. This is a real narrow step with its own top/edge
    # normals, not just a darker painted stripe across one smooth surface.
    bevel('darksteel',(113.6,0,65.10),(.30,128.7,.20),.04)
    bevel('armor',(115.0,0,65.65),(2.1,129.2,1.30),.16)
    tube('armor',(115.94,-64.0,65.20),(115.94,64.0,65.20),.24,7)
    for sign in (-1,1):
        # End welds connect the transverse lip to the hull shoulder seam.
        line('armor',[(113.9,sign*64.8,65.35),(116.1,sign*64.8,65.35),
                      (118.2,sign*64.7,64.10)],.22,7)
    # Characteristic V-shaped glacis splash rails and narrow weld seams.
    for sign in (-1,1):
        glacis_strip((115,sign*5),(156,sign*49),4.0,1.3)
        line('armor',[(115,sign*64.7,65.2),(173,sign*64.3,45.3)],.24,7)
        weld([(-162,sign*62.2,57),(-128,sign*65.1,65.2),(115,sign*65.1,65.2)])
        # Forged towing eyes are below the headlights, on the nose face.
        bevel('armor',(165,sign*47,46.6),(9.5,10.5,4),.9,pitch=math.radians(-8))
        ring('darksteel',(172,sign*47,46.7),(0,1,0),3.35,.85,24,7)
        for y in (sign*43.3,sign*50.7):bolt((165,y,49),.85)
    # Tow cable rests on the glacis, with twisted-wire traces and clamped eyes.
    for sign in (-1,1):
        pts=[(124,sign*57,glacis_z(124)+1.8),(128,sign*53,glacis_z(128)+1.8),
             (139,sign*27,glacis_z(139)+1.8),(147,sign*8,glacis_z(147)+1.8)]
        line('darksteel',pts,.8,12)
        # Thin helical strands avoid a perfectly smooth hose silhouette.
        a,b=pts[1],pts[-1];axis=unit(sub(b,a));u=unit(cross(axis,(0,0,1)));v=cross(axis,u)
        for strand in range(3):
            points=[]
            for j in range(45):
                t=j/44;ang=t*math.tau*10+strand*math.tau/3
                points.append(add(add(a,mul(sub(b,a),t)),add(mul(u,math.cos(ang)*.77),mul(v,math.sin(ang)*.77))))
            line('darksteel',points,.13,5)
        ring('darksteel',(123,sign*57,glacis_z(123)+1.6),(0,0,1),3.3,.7,24,6)
        ring('darksteel',(147,sign*8,glacis_z(147)+1.8),(0,0,1),2.0,.55,20,6)
        bevel('armor',(130,sign*47,glacis_z(130)+2.1),(4.8,5.5,1.1),.2,pitch=math.radians(18))
        bolt((130,sign*47,glacis_z(130)+2.8),.6)
    # Five short driver-grip ribs on the front upper centre, clearly visible in
    # the top reference instead of an invented full-width splash wall.
    for x in (115,120,125,130,135):
        line('armor',[(x,-6,glacis_z(x)+.6),(x,6,glacis_z(x)+.6)],.43,8)

    # Pressed fenders at deck level: these are narrow load-carrying shelves,
    # entirely open beneath. NO side armour leaves or their hinge brackets.
    stations=[(-170,42),(-166,50),(-153,55.7),(-134,57.3),
              (120,57.3),(149,55.4),(165,48.7),(173,37.5)]
    for sign in (-1,1):
        for (xa,za),(xb,zb) in zip(stations,stations[1:]):
            pts=[(xa,sign*65.2,za+.5),(xa,sign*91.8,za),
                 (xb,sign*91.8,zb),(xb,sign*65.2,zb+.5)]
            face('armor',pts,(0,0,0))
            face('armor',[(x,y,z-.8) for x,y,z in pts[::-1]],(0,0,100))
            face('armor',[(xa,sign*91.8,za),(xa,sign*91.8,za-.8),
                          (xb,sign*91.8,zb-.8),(xb,sign*91.8,zb)])
        line('armor',[(x,sign*91.8,z+.2) for x,z in stations],.46,8)
        # Pressed end panels have four long embossed ribs following their drop.
        for y in (69,75,81,87):
            line('armor',[(144,sign*y,56.3),(154,sign*y,53.5),
                          (163,sign*y,48.8),(168,sign*y,42.8)],.36,8)
        # Fuel tanks and tool lockers: long, shallow and individually stamped,
        # with asymmetric lengths and lids corresponding to the photo layout.
        layout=[(-119,62),(-56,59),(5,58),(65,57),(124,54)] if sign>0 else [(-122,56),(-64,56),(-5,57),(55,58),(116,61)]
        for index,(x,length) in enumerate(layout):
            top=64.7 if index<4 else 62.8
            width=22.8
            bevel('armor',(x,sign*78.3,top-3.1),(length,width,6.2),.85)
            bevel('darksteel',(x,sign*78.3,top+.03),(length-1.2,width-.8,.30),.12)
            bevel('armor',(x,sign*78.3,top+.32),(length-.55,width-.25,.52),.2)
            # Elongated, round-cornered pressed recesses. Long straight sides
            # distinguish these from the old circular/oval rings. The inside
            # floor is a little below the lip, with only a hairline dark seam.
            def rounded_rect(cx,cy,w,h,r,z):
                points=[]
                for sx,sy,begin in ((1,1,0),(-1,1,math.pi*.5),(-1,-1,math.pi),(1,-1,math.pi*1.5)):
                    ccx=cx+sx*(w*.5-r);ccy=cy+sy*(h*.5-r)
                    for k in range(6):
                        aa=begin+k/5*math.pi*.5
                        points.append((ccx+r*math.cos(aa),ccy+r*math.sin(aa),z))
                return points
            for stamp,off in enumerate((-length*.30,0,length*.30)):
                cx,cy=x+off,sign*78.3
                width=min(length*.105,6.1)
                height=16.4-(1.8 if (index+stamp+(sign<0))%3==0 else 0)
                cy+=sign*(.65 if (index+stamp)%2 else -.65)
                outside=rounded_rect(cx,cy,width,height,1.3,top+.92)
                inside=rounded_rect(cx,cy,width-.8,height-.8,.9,top+.67)
                face('armor',inside,(0,0,0))
                for k in range(len(outside)):
                    j=(k+1)%len(outside)
                    face('armor',[outside[k],outside[j],inside[j],inside[k]],(0,0,0))
                line('darksteel',inside+[inside[0]],.065,5)
            # Two narrow transverse pressed ribs separate the three recesses.
            for offset in (-length*.15,length*.15):
                xx=x+offset
                bevel('armor',(xx,sign*78.3,top+.85),(.75,18.8,.40),.16)
            for xx in (x-length*.35,x+length*.35):
                # Internal hinge barrels and shallow outer retaining catches.
                tube('darksteel',(xx-2,sign*67.8,top+.58),(xx+2,sign*67.8,top+.58),.48,10)
                bevel('darksteel',(xx,sign*90.1,top-1.3),(2.2,1.1,2.8),.18)
                bevel('armor',(xx,sign*90.8,top-1.0),(1.1,.6,1.7),.12)
            if index in (0,2):
                cx=x-length*.35
                tube('darksteel',(cx,sign*74,top+.62),(cx,sign*74,top+1.1),2.2,24)
                tube('armor',(cx,sign*74,top+1.1),(cx,sign*74,top+1.7),2.05,20)
                line('darksteel',[(cx-1.3,sign*74,top+1.8),(cx+1.3,sign*74,top+1.8)],.35,8)
        # Front headlight pairs sit inboard, on the sloped nose, with curved
        # protective cages rather than square aquarium-like fender boxes.
        for lampindex,y in enumerate((52,61)):
            z=glacis_z(151)+4.4
            tube('armor',(147,sign*y,z),(155,sign*y,z),3.2,32)
            tube('darksteel',(154.8,sign*y,z),(155.4,sign*y,z),3.4,32)
            tube('lamp' if lampindex==0 else 'glass',(155.45,sign*y,z),(155.58,sign*y,z),2.6,32)
        for y in (48,65):
            line('darksteel',[(145,sign*y,glacis_z(145)+.6),
                              (147,sign*y,glacis_z(147)+9.0),
                              (156,sign*y,glacis_z(156)+10.5),
                              (159,sign*y,glacis_z(159)+1.4)],.49,9)
        line('darksteel',[(155,sign*48,glacis_z(155)+10),(155,sign*65,glacis_z(155)+10)],.45,9)
        # Only the small fixed shelf braces remain; nothing hangs in front of
        # road wheels and no later rubber skirt is added.
        for x in (-133,-73,-12,49,111):
            face('armor',[(x-2,sign*65,55),(x+2,sign*65,55),
                          (x+2,sign*89,57),(x-2,sign*89,57)])
            bolt((x,sign*89,57.8),.65)

    # Driver hatch below the gun, with a flatter pressed lid, hinge and single
    # wide forward vision slot. Small side episcopes follow the rim.
    ellipse_plate('darksteel',(91,0,65.3),16.3,14.8,1.1,48)
    ellipse_plate('armor',(91,0,66.1),15.6,14.1,1.0,48)
    ellipse_plate('armor',(90.4,0,66.9),13.8,12.6,.7,48)
    for y in (-8,8):tube('darksteel',(77,y-1.7,67),(77,y+1.7,67),.65,12)
    line('darksteel',[(88,-3,67.3),(88,-3,69),(88,3,69),(88,3,67.3)],.43,8)
    bevel('armor',(107.7,0,67.7),(6.7,15.8,4),.6,pitch=math.radians(-8))
    bevel('darksteel',(111,0,67.7),(.55,13.1,1.9),.12)
    bevel('glass',(111.3,0,67.7),(.09,11.4,1.15),.035)
    for y in (-11.5,11.5):
        bevel('armor',(101.5,y,67.5),(7.5,5.4,2.4),.45,yaw=math.copysign(.32,y))
        bevel('glass',(104.7,y,67.8),(.3,3.8,1.15),.07,yaw=math.copysign(.32,y))

    # Two separate low engine-deck intake meshes. The photo has dark wire mesh,
    # not a mattress of thick exposed crossbars. Thin welded frames sit flush.
    for y,sy in ((-25,44),(25,44)):
        cx=-111;length=46
        bevel('darksteel',(cx,y,65.15),(length,sy,.7),.25)
        for yy in (y-sy*.5,y+sy*.5):bevel('armor',(cx,yy,65.9),(length+2,1.6,1.5),.3)
        for xx in (cx-length*.5,cx+length*.5):bevel('armor',(xx,y,65.9),(1.6,sy,1.5),.3)
        # Crossing thin metal wires; moderate density stays readable at distance.
        for i in range(27):
            x=cx-length*.5+1+i*(length-2)/26
            tube('darksteel',(x,y-sy*.5+1,65.75),(x,y+sy*.5-1,65.75),.16,5)
        for i in range(18):
            yy=y-sy*.5+1+i*(sy-2)/17
            tube('darksteel',(cx-length*.5+1,yy,65.92),(cx+length*.5-1,yy,65.92),.16,5)
        for xx in (cx-length*.4,cx,cx+length*.4):
            for yy in (y-sy*.5,y+sy*.5):bolt((xx,yy,66.8),.5)
    # A separate transmission access cover behind the grille, with rounded
    # access caps and characteristic small longitudinal louvres at one side.
    bevel('darksteel',(-151,0,63.7),(23,99,.7),.25)
    bevel('armor',(-151,0,64.3),(22,98,.8),.3)
    for y in (-18,18):
        ellipse_plate('darksteel',(-151,y,64.9),5.2,3.4,.4,28)
        ellipse_plate('armor',(-151,y,65.25),4.5,2.8,.3,28)
        line('darksteel',[(-153,y,65.5),(-149,y,65.5)],.28,8)
    for y in (-42,42):
        for x in (-158,-145):bolt((x,y,65.2),.55)
    for x in (-161,-157,-153,-149,-145):
        bevel('darksteel',(x,54,64.95),(1.8,13,.6),.15)
        bevel('armor',(x,54.8,65.4),(.6,11,.8),.15)
    # Side service covers near the turret ring, not enormous featureless boxes.
    for y in (-49,49):
        bevel('darksteel',(-55,y,65.35),(20,22,.4),.2)
        bevel('armor',(-55,y,65.8),(19,21,.5),.2)
        for xx in (-61,-49):
            for yy in (y-7,y+7):bolt((xx,yy,66.3),.48)

    # Broad rear exhaust/louvre aperture and welded corner boxes, as seen in the
    # straight rear photograph. No auxiliary fuel drums are fitted in this build.
    bevel('darksteel',(-165.3,0,57.0),(2.2,108,10.8),.35)
    for z in (53.6,55.7,57.8,59.9):
        bevel('armor',(-167.0,0,z),(2.1,106,.72),.17,pitch=math.radians(-10))
    for y in (-38,0,38):bevel('darksteel',(-167.3,y,56.9),(1.2,1.2,8.2),.18)
    for sign in (-1,1):
        bevel('armor',(-163,sign*73,58),(14,24,10),.9)
        bevel('armor',(-163.5,sign*73,63.1),(14.4,24.5,.9),.3)
        for y in (sign*66,sign*80):bolt((-165,y,64),.65)
        bevel('darksteel',(-171,sign*73,57),(1.1,7,4.5),.3)
        bevel('lamp',(-171.7,sign*73,57),(.22,4.7,2.8),.14)
    # Rear plate detail: framed hatches, towing bosses, shackles and mounting bolts.
    for y in (-44,0,44):
        bevel('darksteel',(-165,y,39.3),(1.7,24,11),.4)
        bevel('armor',(-166,y,39.3),(1.1,22.5,9.8),.3)
        for yy in (y-8,y+8):
            for z in (36.1,42.6):bolt((-167,yy,z),.6,axis=(-1,0,0))
        if y:
            ring('darksteel',(-169,y,35.5),(0,1,0),3.1,.9,24,7)
            bevel('armor',(-166,y,34.5),(6,6,4),.55)
    # Rough self-recovery timber, not additional metal drums. Individual vertex
    # radii and end grain rings make this a real wooden log in the silhouette.
    cy=0;cx=-173.3;cz=49.0;half=88.5;n=40
    def logpoint(y,i):
        a=i/n*math.tau
        radius=4.8+.23*math.sin(a*5+.8)+.14*math.sin(a*11+y*.035)
        return (cx+math.cos(a)*radius,y,cz+math.sin(a)*radius)
    for i in range(n):
        j=(i+1)%n
        pts=[logpoint(-half,i),logpoint(-half,j),logpoint(half,j),logpoint(half,i)]
        api.quad(part,'wood',*pts,uv=[(0,i/n),(0,j/n),(5,j/n),(5,i/n)])
    for sign in (-1,1):
        yy=sign*half
        for i in range(n):
            a,b=logpoint(yy,i),logpoint(yy,(i+1)%n)
            face('wood',[(cx,yy,cz),a,b],(cx,0,cz))
        for rr in (1.5,2.8,4.1):ring('wood',(cx,yy+sign*.05,cz),(0,1,0),rr,.08,40,5)
    for y in (-54,54):
        # Flat retaining straps pass around the timber and tie into the rear.
        for i in range(24):
            a=i/24*math.tau;b=(i+1)/24*math.tau
            coords=[(cx+5.15*math.cos(t),y+dy,cz+5.15*math.sin(t))
                    for t,dy in ((a,-1.1),(b,-1.1),(b,1.1),(a,1.1))]
            face('darksteel',coords,(cx,y,cz))
        bevel('darksteel',(-168,y,47),(10,3.8,3.2),.35)
        bolt((-164,y,49),.85)
    # Restrained tiedowns and deck cable: these stay within the hull silhouette.
    for sign in (-1,1):
        for x in (-135,-65,25):
            line('darksteel',[(x,sign*62,65),(x,sign*62,67),(x+5,sign*62,67),(x+5,sign*62,65)],.38,8)
        line('darksteel',[(-139,sign*58,64.8),(-119,sign*60,66),(-84,sign*60,66),(-68,sign*58,65)],.6,10)
        ring('darksteel',(-138,sign*58,65),(0,0,1),2.6,.55,24,6)
        for x in (-121,-83):bevel('armor',(x,sign*60,66.5),(3,3.8,1.1),.2)
