-- Source's sequence 0 already rotates this model into LVS's +X-forward frame.
-- Keep all bone/material edits on a private clientside visual instance.
local materials = include("t72a/sh_materials.lua")
local materialSerial = 0

local function removeVisual(vehicle)
    if IsValid(vehicle.T72Visual) then vehicle.T72Visual:Remove() end
    vehicle.T72Visual = nil
end

local function privateTrackMaterial(side)
    materialSerial = materialSerial + 1
    local original = Material(materials.TrackMaterial)
    local parameters = {["$model"] = "1"}
    -- Inherit the generated track finish, including detail/normal maps, while
    -- keeping its scrolling transform private to this vehicle and belt.
    for _, key in ipairs({"$basetexture", "$bumpmap", "$detail", "$detailscale",
        "$detailblendmode", "$detailblendfactor", "$color2", "$phong",
        "$phongexponent", "$phongboost", "$phongexponenttexture",
        "$basemapalphaphongmask", "$normalmapalphaphongmask",
        "$phongfresnelranges", "$phongalbedotint"}) do
        local value = original:GetString(key)
        if value and value ~= "" then parameters[key] = value end
    end
    parameters["$basetexture"] = parameters["$basetexture"] or "t72a_ural/neutral"
    return CreateMaterial("t72a_ural_tracks_" .. side .. "_" .. materialSerial,
        "VertexLitGeneric", parameters)
end

function ENT:T72EnsureVisual()
    if IsValid(self.T72Visual) then return self.T72Visual end
    local profile = self.T72Profile
    if not profile or not profile.Model or not util.IsValidModel(profile.Model) then return end
    local visual = ClientsideModel(profile.Model, RENDERGROUP_OPAQUE)
    if not IsValid(visual) then return end
    visual:SetNoDraw(true)
    visual:SetSkin(0)
    -- Pin the real runtime reference pose, not the MDL bind-pose orientation.
    visual:ResetSequence(0)
    visual:SetCycle(0)
    visual:SetPlaybackRate(0)
    for _, group in ipairs(visual:GetBodyGroups()) do visual:SetBodygroup(group.id, 0) end
    for id, name in ipairs(visual:GetMaterials()) do
        if id <= 32 then
            local replacement = materials.Resolve(name)
            visual:SetSubMaterial(id - 1, replacement)
            if replacement == materials.TrackMaterial then self._T72TrackSlot = id - 1 end
        end
    end
    if self._T72TrackSlot then
        self._T72TrackMaterials = {
            Left = privateTrackMaterial("left"), Right = privateTrackMaterial("right")
        }
    end
    self.T72Visual = visual
    self:DrawShadow(false)
    self:SetRenderBounds(profile.RenderMins, profile.RenderMaxs)
    self:CallOnRemove("T72UralVisualCleanup", removeVisual)
    self._T72VisualWheelBones = {Left = {}, Right = {}}
    self._T72VisualTrackBones = {Left = {}, Right = {}}
    for _, side in ipairs({"Left", "Right"}) do
        for _, name in ipairs((profile.WheelBones or {})[side] or {}) do
            local id = visual:LookupBone(name)
            if id then table.insert(self._T72VisualWheelBones[side], id) end
            -- The belt deformation bones are children of each rotating wheel.
            -- Their local offset is on the spin axis: counter-rotate them to
            -- keep the continuous belt in place while the roadwheel turns.
            if name:match("^%[wheels%]") then
                local track = visual:LookupBone((name:gsub("^%[wheels%]", "[TRACKS]")))
                if track then table.insert(self._T72VisualTrackBones[side], track) end
            end
        end
    end
    return visual
end

function ENT:T72AnimateRunningGear(visual)
    local frame = FrameNumber()
    if self._T72RunningGearFrame == frame then return end
    self._T72RunningGearFrame = frame
    local dt = math.Clamp(FrameTime(), 0.0001, 0.1)
    local yaw = self:GetAngles().y
    local yawRate = self._T72LastYaw and math.rad(math.AngleDifference(yaw, self._T72LastYaw)) / dt or 0
    self._T72LastYaw = yaw
    local forward = self:GetVelocity():Dot(self:GetForward())
    local spacing = math.abs(self.T72Profile.Wheels.Left[1].y)
    local radius = math.max(self.T72Profile.Wheels.Radius or 15.684, 1)
    local speed = {Left = forward - yawRate * spacing, Right = forward + yawRate * spacing}
    for _, side in ipairs({"Left", "Right"}) do
        local phaseKey, scrollKey = "_T72WheelPhase" .. side, "_T72TrackScroll" .. side
        self[phaseKey] = ((self[phaseKey] or 0) + math.deg(speed[side] * dt / radius)) % 360
        for _, bone in ipairs(self._T72VisualWheelBones[side]) do
            visual:ManipulateBoneAngles(bone, Angle(-self[phaseKey], 0, 0))
        end
        for _, bone in ipairs(self._T72VisualTrackBones[side]) do
            visual:ManipulateBoneAngles(bone, Angle(self[phaseKey], 0, 0))
        end
        if self._T72TrackMaterials then
            self[scrollKey] = ((self[scrollKey] or 0) + speed[side] * dt / 100) % 1
            local matrix = Matrix()
            matrix:Translate(Vector(0, self[scrollKey], 0))
            self._T72TrackMaterials[side]:SetMatrix("$basetexturetransform", matrix)
            self._T72TrackMaterials[side]:SetMatrix("$bumptransform", matrix)
        end
    end
end

function ENT:T72DrawBelts(visual, flags)
    if not self._T72TrackMaterials or self._T72DisableSplitTracks then
        visual:DrawModel(flags)
        return
    end
    -- The model has one material slot for both belts. Render each half once
    -- against the hull's centre plane so each side can scroll independently.
    -- No recompiled mesh or global material changes are required.
    local previous = render.EnableClipping(true)
    local pushed = false
    local ok, message = xpcall(function()
        local right = self:GetRight()
        for _, side in ipairs({"Left", "Right"}) do
            local normal = side == "Left" and -right or right
            render.PushCustomClipPlane(normal, normal:Dot(self:GetPos()))
            pushed = true
            visual:SetSubMaterial(self._T72TrackSlot, "!" .. self._T72TrackMaterials[side]:GetName())
            visual:DrawModel(flags)
            render.PopCustomClipPlane()
            pushed = false
        end
    end, debug.traceback)
    if pushed then render.PopCustomClipPlane() end
    render.EnableClipping(previous)
    if not ok then
        self._T72DisableSplitTracks = true
        ErrorNoHalt("[T-72 Ural] Split track rendering disabled: " .. tostring(message) .. "\n")
    end
end

function ENT:Draw(flags)
    local visual = self:T72EnsureVisual()
    if not IsValid(visual) then return end
    visual:SetPos(self:GetPos())
    visual:SetAngles(self:LocalToWorldAngles(Angle(0, self.T72Profile.VisualYaw or 0, 0)))
    visual:SetColor(self:GetColor())
    self:T72ApplyVisualTurret(visual)
    self:T72AnimateRunningGear(visual)
    visual:SetupBones()
    self:T72DrawBelts(visual, flags)
end

function ENT:DrawTranslucent() end
