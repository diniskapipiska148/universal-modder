-- Original server-authoritative ammunition state. Counts include the loaded
-- round; only a successful shot consumes one. No module/penetration simulation.
T72Ammo = T72Ammo or {}
T72Ammo.Types = {
    {Name = "APFSDS", Short = "БОПС", Label = "Бронебойный подкалиберный", Count = 18,
        Velocity = 72000, Damage = 1450, Force = 4500, HullSize = 0},
    {Name = "HEAT", Short = "КС", Label = "Кумулятивный", Count = 9,
        Velocity = 30000, Damage = 1000, Force = 1800, HullSize = 1,
        SplashDamage = 160, SplashDamageRadius = 100},
    {Name = "HE", Short = "ОФС", Label = "Осколочно-фугасный", Count = 12,
        Velocity = 26000, Damage = 450, Force = 500, HullSize = 2,
        SplashDamage = 800, SplashDamageRadius = 240}
}
local fields = {"T72AmmoAP", "T72AmmoHEAT", "T72AmmoHE"}

function ENT:T72GetAmmoDefinition(id)
    return T72Ammo.Types[id or self:GetT72AmmoType()] or T72Ammo.Types[1]
end
function ENT:T72GetAmmoCount(id)
    local field = fields[id or self:GetT72AmmoType()]
    return field and self["Get" .. field](self) or 0
end
function ENT:T72GetAmmoTotal()
    return self:GetT72AmmoAP() + self:GetT72AmmoHEAT() + self:GetT72AmmoHE()
end
function ENT:T72AmmoSystemDT()
    self:AddDT("Int", "T72AmmoType")
    self:AddDT("Int", "T72PendingAmmoType")
    for _, field in ipairs(fields) do self:AddDT("Int", field) end
    if SERVER then
        self:SetT72AmmoType(1)
        self:SetT72PendingAmmoType(1)
        for id, field in ipairs(fields) do self["Set" .. field](self, T72Ammo.Types[id].Count) end
        self:TurretUpdateBallistics(T72Ammo.Types[1].Velocity)
    end
end

if SERVER then
    function ENT:T72SyncCannonAmmo()
        local weapon = self.WEAPONS and self.WEAPONS[1] and self.WEAPONS[1][1]
        if weapon then weapon._CurAmmo = self:T72GetAmmoTotal() end
        if self:GetSelectedWeapon() == 1 then self:SetNWAmmo(self:T72GetAmmoTotal()) end
    end
    function ENT:T72RequestAmmo(id)
        if self:GetHP() <= 0 or not T72Ammo.Types[id] or self:T72GetAmmoCount(id) <= 0 then return false end
        if id == self:GetT72PendingAmmoType() then return false end
        if CurTime() < (self._T72NextAmmoSwitch or 0) then return false end
        self._T72NextAmmoSwitch = CurTime() + 0.2
        self:SetT72PendingAmmoType(id)
        -- Neither weapon cycling nor a late type change can shorten a reload.
        self:SetT72ReloadEnd(math.max(self:GetT72ReloadEnd(), CurTime() + self.T72ReloadDuration))
        self:EmitSound("buttons/button14.wav", 65, 100, 0.35)
        return true
    end
    function ENT:T72CycleAmmo()
        local selected = self:GetT72PendingAmmoType()
        for offset = 1, #T72Ammo.Types do
            local id = (selected - 1 + offset) % #T72Ammo.Types + 1
            if self:T72GetAmmoCount(id) > 0 and id ~= selected then return self:T72RequestAmmo(id) end
        end
        return false
    end
    function ENT:T72AmmoThink()
        if self:GetHP() <= 0 then return end
        if CurTime() >= self:GetT72ReloadEnd() and self:GetT72AmmoType() ~= self:GetT72PendingAmmoType() then
            self:SetT72AmmoType(self:GetT72PendingAmmoType())
            if self:GetSelectedWeapon() == 1 then
                self:TurretUpdateBallistics(self:T72GetAmmoDefinition().Velocity)
            end
        end
    end
    function ENT:T72ConsumeLoadedShell()
        local id = self:GetT72AmmoType()
        local field = fields[id]
        if not field or self:T72GetAmmoCount(id) <= 0 then return false end
        self["Set" .. field](self, self:T72GetAmmoCount(id) - 1)
        self:SetT72ReloadEnd(CurTime() + self.T72ReloadDuration)
        self:T72SyncCannonAmmo()
        return true
    end
    -- LVS' standard ammo tool calls this method. Restore both finite reserves
    -- and MG ammo while retaining the type choice and any existing reload.
    function ENT:WeaponRestoreAmmo()
        local changed = false
        for id, field in ipairs(fields) do
            local maximum = T72Ammo.Types[id].Count
            if self["Get" .. field](self) ~= maximum then
                self["Set" .. field](self, maximum)
                changed = true
            end
        end
        if changed then
            self:SetT72ReloadEnd(math.max(self:GetT72ReloadEnd(), CurTime() + self.T72ReloadDuration))
        end
        local mg = self.WEAPONS and self.WEAPONS[1] and self.WEAPONS[1][2]
        if mg and (mg._CurAmmo or mg.Ammo) ~= mg.Ammo then
            mg._CurAmmo = mg.Ammo
            changed = true
        end
        self:T72SyncCannonAmmo()
        if self:GetSelectedWeapon() == 2 and mg then self:SetNWAmmo(mg._CurAmmo or mg.Ammo) end
        return changed
    end
    if concommand then
        concommand.Add("t72a_ammo_next", function(ply)
            if not IsValid(ply) or not ply.lvsGetVehicle then return end
            local vehicle = ply:lvsGetVehicle()
            if not IsValid(vehicle) or not vehicle.T72A or not vehicle.T72CycleAmmo then return end
            if vehicle:GetDriver() ~= ply then return end
            vehicle:T72CycleAmmo()
        end)
    end
end
