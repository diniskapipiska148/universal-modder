-- Original vector sight/HUD, using no graphics or UI files from War Thunder.
-- All distances/ammunition come from the vehicle; the bore marker is NOT impact prediction.
T72AHUD = T72AHUD or {}
local ink = Color(228,239,213,245)
local dim = Color(156,177,147,235)
local green = Color(159,216,112,255)
local amber = Color(244,191,90,255)
local red = Color(238,101,85,255)
local black = Color(0,0,0,235)
local panel = Color(12,20,14,220)
local lastScale
local function fonts(scale)
    if scale == lastScale then return end
    lastScale=scale
    for name,size in pairs({Small=18,Normal=23,Large=34}) do
        surface.CreateFont("T72A_HUD_"..name,{font="Roboto",size=math.max(11,math.floor(size*scale)),weight=550,extended=true})
    end
end
local function text(value,font,x,y,colour,align)
    draw.SimpleTextOutlined(tostring(value),"T72A_HUD_"..font,x,y,colour or ink,
        align or TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP,1,black)
end
local function line(x1,y1,x2,y2,colour)
    surface.SetDrawColor(colour or ink)
    surface.DrawLine(x1,y1,x2,y2)
end
local function box(x,y,w,h,scale)
    draw.RoundedBox(3*scale,x,y,w,h,panel)
    surface.SetDrawColor(87,113,81,170)
    surface.DrawOutlinedRect(x,y,w,h,1)
end
local function ring(x,y,r,fraction,colour)
    surface.SetDrawColor(colour)
    for i=1,math.floor(math.Clamp(fraction,0,1)*64) do
        local a=(i-1)/64*math.pi*2-math.pi*.5
        local b=i/64*math.pi*2-math.pi*.5
        surface.DrawLine(x+math.cos(a)*r,y+math.sin(a)*r,x+math.cos(b)*r,y+math.sin(b)*r)
    end
end
local function firstPerson(ply)
    local pod=ply.GetVehicle and ply:GetVehicle()
    return IsValid(pod) and pod.GetThirdPersonMode and not pod:GetThirdPersonMode()
end
-- Exposed for contract tests and to keep optical scale independent of HUD text scale.
function T72AHUD.SightLayout(width,height,fov)
    fov=math.Clamp(tonumber(fov) or 25,5,120)
    -- Source camera FOV is horizontal at 4:3. Preserve its vertical projection
    -- on wider screens, as Source's aspect-ratio correction does.
    local focal=height*(4/3)/(2*math.tan(math.rad(fov)*.5))
    return {x=width*.5,y=height*.5,r=height*.405,fov=fov,pixelsPerMil=focal*.001}
end
local function opticalMask(lens,width,height)
    draw.NoTexture()
    local outer=width+height
    surface.SetDrawColor(0,0,0,255)
    for i=0,71 do
        local a=i/72*math.pi*2-.0007
        local b=(i+1)/72*math.pi*2+.0007
        surface.DrawPoly({
            {x=lens.x+math.cos(a)*lens.r,y=lens.y+math.sin(a)*lens.r},
            {x=lens.x+math.cos(a)*outer,y=lens.y+math.sin(a)*outer},
            {x=lens.x+math.cos(b)*outer,y=lens.y+math.sin(b)*outer},
            {x=lens.x+math.cos(b)*lens.r,y=lens.y+math.sin(b)*lens.r}
        })
    end
    -- Thin concentric falloff, so the edge reads as optics rather than a flat cutout.
    for step=0,9 do
        local radius=lens.r-step*height*.0018
        surface.DrawCircle(lens.x,lens.y,radius,0,0,0,220-step*19)
    end
    ring(lens.x,lens.y,lens.r*.986,1,Color(67,82,52,220))
end
local function stadia(lens,scale)
    local x0=lens.x-lens.r*.68
    local y0=lens.y+lens.r*.56
    local width=lens.r*.49
    line(x0,y0,x0+width,y0,dim)
    local previous
    for i,range in ipairs({400,800,1200,1600}) do
        local x=x0+(i-1)*width/3
        local height=2.7/range*lens.pixelsPerMil*1000
        local y=y0-height
        line(x,y-3*scale,x,y+3*scale,dim)
        if previous then line(previous.x,previous.y,x,y,dim) end
        previous={x=x,y=y}
        text(string.format("%d",range/100),"Small",x,y0+5*scale,dim,TEXT_ALIGN_CENTER)
    end
    text("2,7 м / ×100 м","Small",x0,y0+27*scale,dim)
end
local function opticalReticle(lens,scale)
    local x,y=lens.x,lens.y
    local mil=lens.pixelsPerMil
    local maximum=math.floor(lens.r*.71/(mil*10))*10
    maximum=math.Clamp(maximum,20,100)
    local span=maximum*mil
    local gap=3*scale
    line(x-span,y,x-gap,y)
    line(x+gap,y,x+span,y)
    line(x,y-lens.r*.44,x,y-gap)
    line(x,y+gap,x,y+lens.r*.70)
    -- Angular 5 mrad ticks; labelled in mrad, not an invented ballistic ladder.
    for value=-maximum,maximum,5 do
        if value~=0 then
            local major=value%20==0
            local h=(major and 9 or 4)*scale
            local xpos=x+value*mil
            line(xpos,y-h,xpos,y+h,major and ink or dim)
            if major then text(math.abs(value),"Small",xpos,y+13*scale,dim,TEXT_ALIGN_CENTER) end
        end
    end
    for value=10,maximum,10 do
        local ypos=y+value*mil
        if ypos<y+lens.r*.69 then
            local w=(value%20==0 and 8 or 4)*scale
            line(x-w,ypos,x+w,ypos,dim)
            if value%20==0 then text(value,"Small",x+12*scale,ypos-7*scale,dim) end
        end
    end
    line(x-5*scale,y+5*scale,x,y,green)
    line(x,y,x+5*scale,y+5*scale,green)
    text("мрад","Small",x+span+8*scale,y-7*scale,dim)
    stadia(lens,scale)
end
local function boreMarker(vehicle,width,height,scale,lens)
    local muzzle=vehicle.GetT72Muzzle and vehicle:GetT72Muzzle(vehicle:GetSelectedWeapon()==2)
    if not muzzle or not muzzle.Pos or not muzzle.Ang then return end
    local trace=util.TraceLine({start=muzzle.Pos,endpos=muzzle.Pos+muzzle.Ang:Forward()*100000,
        filter=vehicle:GetCrosshairFilterEnts(),mask=MASK_SHOT})
    local screen=trace.HitPos:ToScreen()
    if not screen.visible then return end
    if lens and (screen.x-lens.x)^2+(screen.y-lens.y)^2>(lens.r*.95)^2 then return end
    if screen.x<8 or screen.x>width-8 or screen.y<8 or screen.y>height-8 then return end
    surface.SetDrawColor(green)
    surface.DrawCircle(screen.x,screen.y,6*scale,green.r,green.g,green.b,green.a)
    line(screen.x-10*scale,screen.y,screen.x-7*scale,screen.y,green)
    line(screen.x+7*scale,screen.y,screen.x+10*scale,screen.y,green)
end
local function compass(vehicle,width,scale)
    local turret=vehicle.GetTurretYaw and vehicle:GetTurretYaw() or 0
    local heading=(360-vehicle:GetAngles().y-turret)%360
    local centre=width*.5
    local y=23*scale
    local step=4*scale
    for offset=-45,45,5 do
        local bearing=(math.floor(heading/5)*5+offset)%360
        local position=centre+((bearing-heading+540)%360-180)*step
        local major=bearing%15==0
        line(position,y+21*scale,position,y+(major and 32 or 27)*scale,dim)
        if major then text(string.format("%03d",bearing),"Small",position,y,dim,TEXT_ALIGN_CENTER) end
    end
    line(centre,y+34*scale,centre-4*scale,y+40*scale,green)
    line(centre,y+34*scale,centre+4*scale,y+40*scale,green)
    local relative=(turret+180)%360-180
    text(string.format("БАШНЯ %+03d°",math.floor(relative+.5)),"Small",centre,y+46*scale,ink,TEXT_ALIGN_CENTER)
end
local function vehicleInfo(vehicle,width,height,scale)
    local margin,w,h=22*scale,272*scale,146*scale
    local x,y=margin,height-margin-h
    box(x,y,w,h,scale)
    text("Т-72 «УРАЛ»","Normal",x+12*scale,y+9*scale)
    local hp=math.max(vehicle:GetHP(),0)
    local max=math.max(vehicle:GetMaxHP(),1)
    local fraction=math.Clamp(hp/max,0,1)
    local colour=fraction>.5 and green or (fraction>.25 and amber or red)
    text(string.format("HP %d / %d",math.ceil(hp),max),"Small",x+12*scale,y+39*scale,colour)
    draw.RoundedBox(0,x+12*scale,y+64*scale,w-24*scale,4*scale,dim)
    draw.RoundedBox(0,x+12*scale,y+64*scale,(w-24*scale)*fraction,4*scale,colour)
    local speed=vehicle:GetVelocity():Length()*.09144
    text(string.format("%02d км/ч",math.floor(speed+.5)),"Normal",x+12*scale,y+82*scale)
    local gear=vehicle:GetGear()
    gear=vehicle:GetReverse() and "R" or (gear==-1 and "АВТО" or tostring(gear))
    text(gear,"Normal",x+w-12*scale,y+82*scale,ink,TEXT_ALIGN_RIGHT)
    text(vehicle:GetEngineActive() and "ДВИГАТЕЛЬ ВКЛ" or "ДВИГАТЕЛЬ ВЫКЛ","Small",x+12*scale,y+117*scale,
        vehicle:GetEngineActive() and green or amber)
end
local function ammoDefinition(vehicle,id)
    if vehicle.T72GetAmmoDefinition then return vehicle:T72GetAmmoDefinition(id) or {} end
    return (T72Ammo and T72Ammo.Types and T72Ammo.Types[id]) or {}
end
local function ammoCount(vehicle,id)
    if vehicle.T72GetAmmoCount then return vehicle:T72GetAmmoCount(id) end
    if id==1 then return vehicle:GetNWAmmo() end
    return 0
end
local function ammoCards(vehicle,width,height,scale)
    local cardW,cardH,gap=108*scale,65*scale,6*scale
    local x=width*.5-(cardW*3+gap*2)*.5
    local y=height-22*scale-cardH
    local active=vehicle.GetT72AmmoType and vehicle:GetT72AmmoType() or 1
    local pending=vehicle.GetT72PendingAmmoType and vehicle:GetT72PendingAmmoType() or active
    for id=1,3 do
        local definition=ammoDefinition(vehicle,id)
        local xpos=x+(id-1)*(cardW+gap)
        local colour=id==pending and amber or dim
        box(xpos,y,cardW,cardH,scale)
        if id==pending then
            surface.SetDrawColor(amber)
            surface.DrawOutlinedRect(xpos,y,cardW,cardH,2*scale)
        end
        if id==active then draw.RoundedBox(0,xpos+3*scale,y+cardH-4*scale,cardW-6*scale,2*scale,green) end
        text(definition.Short or ({"БОПС","КС","ОФ"})[id],"Small",xpos+10*scale,y+7*scale,colour)
        text(ammoCount(vehicle,id),"Normal",xpos+cardW-10*scale,y+30*scale,ink,TEXT_ALIGN_RIGHT)
        -- Simple original shell silhouette, no borrowed game icon.
        line(xpos+13*scale,y+47*scale,xpos+35*scale,y+47*scale,colour)
        line(xpos+13*scale,y+42*scale,xpos+35*scale,y+42*scale,colour)
        line(xpos+35*scale,y+42*scale,xpos+42*scale,y+44.5*scale,colour)
        line(xpos+42*scale,y+44.5*scale,xpos+35*scale,y+47*scale,colour)
    end
    text("ALT — ТИП СНАРЯДА","Small",width*.5,y-25*scale,dim,TEXT_ALIGN_CENTER)
end
local function weaponInfo(vehicle,width,height,scale)
    local margin,w,h=22*scale,300*scale,146*scale
    local x,y=width-margin-w,height-margin-h
    box(x,y,w,h,scale)
    local selected=vehicle:GetSelectedWeapon()
    local active=vehicle.GetT72AmmoType and vehicle:GetT72AmmoType() or 1
    local pending=vehicle.GetT72PendingAmmoType and vehicle:GetT72PendingAmmoType() or active
    local definition=ammoDefinition(vehicle,active)
    local name=selected==2 and "ПКТ 7,62 мм" or ("125 мм / "..(definition.Short or "ОФ"))
    text(name,"Normal",x+12*scale,y+9*scale)
    local remaining=selected==1 and vehicle.GetT72ReloadEnd and math.max(vehicle:GetT72ReloadEnd()-CurTime(),0) or 0
    local duration=vehicle.T72ReloadDuration or 7.1
    local ammo=selected==1 and ammoCount(vehicle,remaining>0 and pending or active) or vehicle:GetNWAmmo()
    local available=vehicle:GetHP()>0 and ammo>0
    local status=vehicle:GetHP()<=0 and "УНИЧТ." or (ammo<=0 and "ПУСТО" or
        (remaining>0 and string.format("%.1f с",remaining) or "ГОТОВ"))
    local colour=not available and red or (remaining>0 and amber or green)
    text(status,"Normal",x+12*scale,y+42*scale,colour)
    if selected==1 and active~=pending then
        local nextDefinition=ammoDefinition(vehicle,pending)
        text("→ "..(nextDefinition.Short or tostring(pending)),"Small",x+12*scale,y+75*scale,amber)
    else
        text(string.format("БОЕЗАПАС %d",math.max(ammo,0)),"Small",x+12*scale,y+75*scale,dim)
    end
    local rx,ry=x+w-42*scale,y+62*scale
    ring(rx,ry,23*scale,1,dim)
    ring(rx,ry,23*scale,available and (1-math.Clamp(remaining/duration,0,1)) or 0,colour)
    local range=vehicle.GetT72Range and vehicle:GetT72Range() or 0
    text(range>0 and string.format("ДАЛЬНОСТЬ %d м",math.floor(range+.5)) or "ДАЛЬНОСТЬ —",
        "Small",x+12*scale,y+117*scale,dim)
end
function T72AHUD.Paint(vehicle,width,height,ply)
    if not IsValid(vehicle) or not IsValid(ply) or not vehicle.T72A then return end
    local scale=math.Clamp(math.min(width/1600,height/1000),.5,2.2)
    fonts(scale)
    local scoped=firstPerson(ply) and ply:lvsKeyDown("ZOOM")
    local lens
    if scoped then
        lens=T72AHUD.SightLayout(width,height,vehicle.T72SightFOV or 25)
        opticalMask(lens,width,height)
        opticalReticle(lens,scale)
        text(vehicle:GetSelectedWeapon()==2 and "ОПТИЧЕСКИЙ ПРИЦЕЛ / ПКТ" or "ОПТИЧЕСКИЙ ПРИЦЕЛ / 125 мм","Small",22*scale,25*scale,dim)
        text(string.format("ПОЛЕ %.0f°",lens.fov),"Small",width-22*scale,25*scale,dim,TEXT_ALIGN_RIGHT)
        text("○ ОСЬ СТВОЛА","Small",lens.x,lens.y+lens.r*.78,dim,TEXT_ALIGN_CENTER)
    else
        local x,y=width*.5,height*.5
        line(x-14*scale,y,x-5*scale,y)
        line(x+5*scale,y,x+14*scale,y)
        line(x,y-14*scale,x,y-5*scale)
        line(x,y+5*scale,x,y+14*scale)
    end
    boreMarker(vehicle,width,height,scale,lens)
    compass(vehicle,width,scale)
    vehicleInfo(vehicle,width,height,scale)
    weaponInfo(vehicle,width,height,scale)
    ammoCards(vehicle,width,height,scale)
end
function T72AHUD.SuppressBasePanels(definition)
    definition.LVSHudPaintVehicleHealth=function() end
    definition.LVSHudPaintInfoText=function() end
    definition.LVSHudPaintCarMenu=function() end
end
