AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("sh_weapons.lua")
AddCSLuaFile("t72a/sh_profile.lua")
AddCSLuaFile("t72a/sh_ammo.lua")
AddCSLuaFile("t72a/cl_hud.lua")
AddCSLuaFile("t72a/sh_bone_turret.lua")
AddCSLuaFile("t72a/sh_materials.lua")
AddCSLuaFile("t72a/cl_visual.lua")
include("shared.lua")

local function profileError(self)
    local p = self.T72Profile
    if p.Ready ~= true then
        return "The model profile is not enabled. See README_RU.md."
    end
    if not isstring(p.Model) or p.Model == "" or not util.IsValidModel(p.Model) then
        return "The T-72 Ural model is missing. Enable Workshop 2884416595 and its required content."
    end
    if not p.DriverSeat or not p.Engine or not p.Wheels or not p.Suspension then
        return "The model profile is incomplete (seat/engine/wheels/suspension)."
    end
    if not istable(p.Rig) or not isstring(p.Rig.TurretBone) or not isstring(p.Rig.GunBone)
        or not p.Rig.CannonMuzzle or not p.Rig.MGMuzzle or not p.HullMins or not p.HullMaxs then
        return "The measured bone/physics profile is incomplete."
    end
    if not istable(p.Wheels.Left) or not istable(p.Wheels.Right)
        or #p.Wheels.Left < 2 or #p.Wheels.Left ~= #p.Wheels.Right then
        return "The model profile is missing matched left/right running gear."
    end
    if not isstring(p.Wheels.Model) or not util.IsValidModel(p.Wheels.Model) then
        return "The wheel physics model is missing."
    end
    local driveIndex = p.Wheels.DriveIndex or 1
    if driveIndex < 1 or driveIndex > #p.Wheels.Left or driveIndex % 1 ~= 0 then
        return "The track drive wheel index is outside the wheel list."
    end

end

function ENT:SpawnFunction(ply, tr, className)
    local reason = profileError(self)
    if reason then
        if IsValid(ply) then ply:ChatPrint("[T-72 Ural] " .. reason) end
        return
    end
    return baseclass.Get("lvs_base").SpawnFunction(self, ply, tr, className)
end

function ENT:Initialize()
    local reason = profileError(self)
    if reason then
        ErrorNoHalt("[T-72 Ural] " .. reason .. "\n")
        self:Remove()
        return
    end
    baseclass.Get("lvs_base").Initialize(self)
end

-- The source model faces -Y, while LVS expects +X. Leave its files untouched:
-- use a canonical simplified collision hull, and rotate only the client visual.
function ENT:PhysicsInit()
    self:PhysicsInitBox(self.T72Profile.HullMins, self.T72Profile.HullMaxs)
    self:SetCollisionBounds(self.T72Profile.HullMins, self.T72Profile.HullMaxs)
    return IsValid(self:GetPhysicsObject())
end

function ENT:OnSpawn()
    local p = self.T72Profile
    for _, name in ipairs({p.Rig.TurretBone, p.Rig.GunBone}) do
        if self:LookupBone(name) == nil then
            ErrorNoHalt("[T-72 Ural] Required bone missing: " .. name .. "\n")
            self:Remove()
            return
        end
    end
    local seat = self:AddDriverSeat(p.DriverSeat.Pos, p.DriverSeat.Ang)
    if not IsValid(seat) then self:Remove() return end
    seat.HidePlayer = true
    self:AddEngine(p.Engine.Pos, p.Engine.Ang)
end

-- AddEngine is retained for LVS engine controls/sound. Its damage boxes are
-- intentionally bypassed so there is only one combat-health pool.
function ENT:CalcComponentDamage()
    return false
end

function ENT:TakeCollisionDamage(damage, attacker)
    if not IsValid(attacker) then attacker = game.GetWorld() end
    local info = DamageInfo()
    info:SetDamage((math.min(damage / 4000, 1) ^ 2) * 200)
    info:SetAttacker(attacker)
    info:SetInflictor(attacker)
    info:SetDamageType(DMG_CRUSH + DMG_VEHICLE)
    self:TakeDamageInfo(info)
end

function ENT:TracksCreate()
    local p = self.T72Profile
    local wheels = p.Wheels
    if p.TrackPhysicsModel then self:CreateTrackPhysics(p.TrackPhysicsModel) end
    local left, right = {}, {}
    for i, pos in ipairs(wheels.Left) do
        left[i] = self:AddWheel({
            hide = true, wheeltype = LVS.WHEELTYPE_LEFT,
            pos = pos, mdl = wheels.Model, radius = wheels.Radius, width = wheels.Width
        })
    end
    for i, pos in ipairs(wheels.Right) do
        right[i] = self:AddWheel({
            hide = true, wheeltype = LVS.WHEELTYPE_RIGHT,
            pos = pos, mdl = wheels.Model, radius = wheels.Radius, width = wheels.Width
        })
    end
    self:CreateWheelChain(left)
    self:CreateWheelChain(right)
    self:SetTrackDriveWheelLeft(left[wheels.DriveIndex or 1])
    self:SetTrackDriveWheelRight(right[wheels.DriveIndex or 1])
    local axles = p.Axles or {}
    if #axles == 0 then
        for i = 1, math.min(#left, #right) do
            axles[i] = {
                LeftIndex = i, RightIndex = i,
                SteerType = i == 1 and "front" or (i == #left and "rear" or "none"),
                SteerAngle = 25
            }
        end
    end
    local steerTypes = {
        front = LVS.WHEEL_STEER_FRONT,
        rear = LVS.WHEEL_STEER_REAR,
        none = LVS.WHEEL_STEER_NONE
    }
    for _, axle in ipairs(axles) do
        self:DefineAxle({
            Axle = {
                ForwardAngle = Angle(0, 0, 0),
                SteerType = steerTypes[axle.SteerType or "none"],
                SteerAngle = axle.SteerAngle or 0,
                TorqueFactor = axle.TorqueFactor or 1,
                BrakeFactor = 1, UseHandbrake = true
            },
            Wheels = { left[axle.LeftIndex], right[axle.RightIndex] },
            Suspension = table.Copy(p.Suspension)
        })
    end
end

-- The turret module normally supplies OnTick. Preserve that behavior while
-- reporting a server-measured bore distance (not a client-supplied target).
function ENT:OnTick()
    self:AimTurret()
    if (self._T72NextRange or 0) > CurTime() then return end
    self._T72NextRange = CurTime() + 0.25
    local muzzle = self:GetT72Muzzle(false)
    if not muzzle then self:SetT72Range(-1) return end
    local trace = util.TraceLine({
        start = muzzle.Pos,
        endpos = muzzle.Pos + muzzle.Ang:Forward() * 100000,
        filter = self:GetCrosshairFilterEnts(),
        mask = MASK_SHOT
    })
    self:SetT72Range(trace.Hit and not trace.HitSky
        and muzzle.Pos:Distance(trace.HitPos) * 0.01905 or -1)
end
