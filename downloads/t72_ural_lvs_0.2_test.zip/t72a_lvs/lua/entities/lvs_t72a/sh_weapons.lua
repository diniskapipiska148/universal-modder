-- Original gameplay code. All firing, ammo and damage are server authoritative.
ENT.T72ReloadDuration = 7.1
ENT.T72ShellVelocity = 72000 -- default APFSDS velocity; each round has its own.

function ENT:InitWeapons()
    local cannon = {}
    cannon.Ammo = 39
    cannon.Delay = self.T72ReloadDuration
    cannon.HeatRateUp = 0
    cannon.HeatRateDown = 1
    cannon.UseableByAI = false
    cannon.Icon = Material("lvs/weapons/bullet.png")
    cannon.OnThink = function(vehicle)
        vehicle:T72AmmoThink()
        local driver = vehicle:GetDriver()
        local held = IsValid(driver) and driver:lvsKeyDown("CAR_SWAP_AMMO") or false
        if held and not vehicle._T72SwapAmmoHeld and vehicle:GetSelectedWeapon() == 1 then
            vehicle:T72CycleAmmo()
        end
        vehicle._T72SwapAmmoHeld = held
    end
    cannon.Attack = function(vehicle)
        vehicle:T72AmmoThink()
        if vehicle:GetHP() <= 0 or vehicle:T72GetAmmoCount() <= 0 or not vehicle:GetTurretEnabled()
            or CurTime() < vehicle:GetT72ReloadEnd() then return true end
        local muzzle = vehicle:GetT72Muzzle(false)
        if not muzzle then return true end
        local ammo = vehicle:T72GetAmmoDefinition()
        local bullet = {
            Src = muzzle.Pos, Dir = muzzle.Ang:Forward(), Spread = Vector(0, 0, 0),
            EnableBallistics = true, Velocity = ammo.Velocity,
            Force = ammo.Force, HullSize = ammo.HullSize, Damage = ammo.Damage,
            TracerName = "lvs_tracer_cannon",
            Attacker = vehicle:GetDriver()
        }
        if ammo.SplashDamage then
            bullet.SplashDamage = ammo.SplashDamage
            bullet.SplashDamageRadius = ammo.SplashDamageRadius
            bullet.SplashDamageEffect = "lvs_bullet_impact_explosive"
            bullet.SplashDamageType = DMG_BLAST
        end
        vehicle:LVSFireBullet(bullet)
        vehicle:T72ConsumeLoadedShell()
        vehicle:EmitSound("weapons/explode3.wav", 100, 85, 1)
        local effect = EffectData()
        effect:SetOrigin(muzzle.Pos)
        effect:SetAngles(muzzle.Ang)
        effect:SetScale(4)
        util.Effect("MuzzleFlash", effect, true, true)
        local physics = vehicle:GetPhysicsObject()
        if IsValid(physics) then
            physics:ApplyForceOffset(-muzzle.Ang:Forward() * 180000, muzzle.Pos)
        end
    end
    cannon.OnSelect = function(vehicle)
        vehicle:T72AmmoThink()
        vehicle:TurretUpdateBallistics(vehicle:T72GetAmmoDefinition().Velocity)
    end
    self:AddWeapon(cannon)

    local mg = {}
    mg.Ammo = 2000
    mg.Delay = 0.1
    mg.HeatRateUp = 0
    mg.HeatRateDown = 1
    mg.UseableByAI = false
    mg.Icon = Material("lvs/weapons/bullet.png")
    mg.Attack = function(vehicle)
        if vehicle:GetHP() <= 0 or vehicle:GetAmmo() <= 0 or not vehicle:GetTurretEnabled() then return true end
        local muzzle = vehicle:GetT72Muzzle(true)
        if not muzzle then return true end
        local driver = vehicle:GetDriver()
        vehicle:LVSFireBullet({
            Attacker = IsValid(driver) and driver or vehicle,
            Src = muzzle.Pos, Dir = muzzle.Ang:Forward(),
            Spread = Vector(0.003, 0.003, 0), Num = 1,
            TracerName = "lvs_tracer_yellow_small", Force = 8, Damage = 18,
            EnableBallistics = true, Velocity = 40000, HullSize = 0
        })
        vehicle:TakeAmmo(1)
        vehicle:EmitSound("weapons/ar2/fire1.wav", 85, 120, 0.75)
    end
    mg.OnSelect = function(vehicle)
        vehicle:TurretUpdateBallistics(40000)
    end
    self:AddWeapon(mg)
end
