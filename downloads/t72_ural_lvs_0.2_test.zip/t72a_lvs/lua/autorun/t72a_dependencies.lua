if SERVER then
    AddCSLuaFile()
    resource.AddWorkshop("2912816023")
    resource.AddWorkshop("2884416595")
    for _, name in ipairs(file.Find("materials/t72a_ural/*", "GAME")) do
        resource.AddFile("materials/t72a_ural/" .. name)
    end
end
-- Read-only diagnostic, usable without lua_run or elevated server privileges.
concommand.Add("t72a_check", function(ply)
    local function report(message)
        message = "[T-72 Ural] " .. message
        print(message)
        if SERVER and IsValid(ply) then ply:PrintMessage(HUD_PRINTCONSOLE, message) end
    end
    report("realm: " .. (SERVER and "server" or "client"))
    local base = scripted_ents.GetStored("lvs_tank_wheeldrive")
    report("LVS tank base: " .. (base and "OK" or "MISSING"))
    local mdl = "models/damik/ussr/t-72 ural/t-72 ural (prop).mdl"
    report("model: " .. (file.Exists(mdl, "GAME") and "OK" or "MISSING") .. " | " .. mdl)
    for _, ext in ipairs({"vvd", "dx90.vtx", "phy"}) do
        local path = mdl:sub(1, -5) .. "." .. ext
        report(ext .. ": " .. (file.Exists(path, "GAME") and "OK" or "MISSING"))
    end
    report("new texture: " .. (file.Exists("materials/t72a_ural/olive.vtf", "GAME") and "OK" or "MISSING"))
    report("spawn class: lvs_t72a | category: [LVS] - Т-72 Урал")
end)
