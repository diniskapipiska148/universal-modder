-- Original generated T-64A1971 game-art geometry; not an engineering survey.
local left,right={},{}
left[1]=Vector(96.32,77,20.5);right[1]=Vector(96.32,-77,20.5)
left[2]=Vector(60.2,77,20.5);right[2]=Vector(60.2,-77,20.5)
left[3]=Vector(24.08,77,20.5);right[3]=Vector(24.08,-77,20.5)
left[4]=Vector(-12.04,77,20.5);right[4]=Vector(-12.04,-77,20.5)
left[5]=Vector(-48.16,77,20.5);right[5]=Vector(-48.16,-77,20.5)
left[6]=Vector(-84.28,77,20.5);right[6]=Vector(-84.28,-77,20.5)
return {
 Ready=true,Model="models/hunter/blocks/cube025x025x025.mdl",VisualYaw=0,
 HullMins=Vector(-143,-70,29),HullMaxs=Vector(148,70,115),
 -- Include the complete yaw/pitch sweep of the long barrel, not just neutral pose.
 RenderMins=Vector(-336,-328,-4),RenderMaxs=Vector(320,328,176),
 DriverSeat={Pos=Vector(60.2,-15,51.4286),Ang=Angle(0,-90,0)},
 Engine={Pos=Vector(-81.7,0,55.7143),Ang=Angle(0,0,0)},
 Wheels={Left=left,Right=right,DriveIndex=3,Model="models/props_vehicles/tire001c_car.mdl",Radius=16,Width=14},
 Suspension={Height=7,MaxTravel=7,ControlArmLength=150,SpringConstant=42000,SpringDamping=1800,SpringRelativeDamping=2000},
 Turret={AimRate=16,PitchMin=-14,PitchMax=6},TrackUVUnits=8.8,
 Rig={TurretPivot=Vector(-6.88,0,80),GunPivot=Vector(41.88,0,95.64),CannonMuzzle=Vector(288.44,0,95.64),MGMuzzle=Vector(54.76,-8.28,92.88),Sight=Vector(55.68,-16.56,114.96)}
}
