"""Original detailed welded T-64A-style hull assembly.

Game-art reconstruction, authored in canonical Source units. No imported mesh.
The exported hull is intentionally separate from turret and running gear.
"""
from __future__ import annotations
import math


def build(api):
    part = 'hull'
    def add(a,b): return tuple(a[i]+b[i] for i in range(3))
    def sub(a,b): return tuple(a[i]-b[i] for i in range(3))
    def mul(a,s): return tuple(v*s for v in a)
    def dot(a,b): return sum(a[i]*b[i] for i in range(3))
    def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
    def unit(a):
        length=math.sqrt(dot(a,a)); return mul(a,1/length) if length else (0,0,1)
    def transform(p,centre,yaw=0,pitch=0):
        cy,sy,cp,sp=math.cos(yaw),math.sin(yaw),math.cos(pitch),math.sin(pitch)
        x,y,z=p; x,z=x*cp+z*sp,-x*sp+z*cp
        return add(centre,(x*cy-y*sy,x*sy+y*cy,z))
    def face(mat,vertices,inside=None):
        vertices=list(vertices)
        if inside is not None:
            n=cross(sub(vertices[1],vertices[0]),sub(vertices[2],vertices[0]))
            centre=tuple(sum(p[i] for p in vertices)/len(vertices) for i in range(3))
            if dot(n,sub(centre,inside))<0: vertices.reverse()
        for i in range(1,len(vertices)-1): api.triangle(part,mat,vertices[0],vertices[i],vertices[i+1])
    def tube(mat,a,b,r,n=12): api.cylinder(part,mat,a,b,r,n)
    def bevel(mat,centre,size,b=.5,yaw=0,pitch=0):
        hx,hy,hz=[v*.5 for v in size]; b=min(b,hx*.65,hy*.65,hz*.65)
        def world(p):return transform(p,centre,yaw,pitch)
        # Six face plates, twelve chamfer strips and eight triangular corners.
        for axis in range(3):
            for sign in (-1,1):
                other=[i for i in range(3) if i!=axis]; h=(hx,hy,hz)
                points=[]
                for s1,s2 in ((-1,-1),(1,-1),(1,1),(-1,1)):
                    p=[0.,0.,0.];p[axis]=sign*h[axis]
                    p[other[0]]=s1*(h[other[0]]-b);p[other[1]]=s2*(h[other[1]]-b)
                    points.append(world(p))
                face(mat,points,centre)
        h=(hx,hy,hz)
        for axis in range(3):
            a,c=[i for i in range(3) if i!=axis]
            for sa in (-1,1):
                for sc in (-1,1):
                    points=[]
                    for t,edge in ((-1,0),(1,0),(1,1),(-1,1)):
                        p=[0.,0.,0.];p[axis]=t*(h[axis]-b)
                        p[a]=sa*(h[a]-(b if edge else 0));p[c]=sc*(h[c]-(0 if edge else b))
                        points.append(world(p))
                    face(mat,points,centre)
        for sx in (-1,1):
            for sy in (-1,1):
                for sz in (-1,1):
                    signs=(sx,sy,sz);points=[]
                    for axis in range(3):
                        points.append(world(tuple(signs[i]*(h[i]-(0 if i==axis else b)) for i in range(3))))
                    face(mat,points,centre)
    def ring(mat,centre,axis,radius,wire=.55,segments=28,sides=6):
        axis=unit(axis);seed=(0,0,1) if abs(axis[2])<.9 else (0,1,0)
        u=unit(cross(seed,axis));v=cross(axis,u)
        def point(i,j):
            a=i/segments*math.tau;b=j/sides*math.tau
            radial=add(mul(u,math.cos(a)),mul(v,math.sin(a)))
            return add(centre,add(mul(radial,radius+math.cos(b)*wire),mul(axis,math.sin(b)*wire)))
        for i in range(segments):
            for j in range(sides):
                pts=[point(i,j),point(i+1,j),point(i+1,j+1),point(i,j+1)]
                # Smooth vertex normals preserve the round steel section.
                normals=[]
                for ii,jj in ((i,j),(i+1,j),(i+1,j+1),(i,j+1)):
                    a=ii/segments*math.tau;b=jj/sides*math.tau
                    radial=add(mul(u,math.cos(a)),mul(v,math.sin(a)))
                    normals.append(add(mul(radial,math.cos(b)),mul(axis,math.sin(b))))
                api.quad(part,mat,*pts,normals=normals)
    def bolt(pos,r=1.05,axis=(0,0,1)):
        end=add(pos,mul(axis,.85));tube('darksteel',pos,end,r,6)
    def line(mat,points,r=.4,n=8):
        for a,b in zip(points,points[1:]):tube(mat,a,b,r,n)
    def weld(points):
        line('armor',points,.32,6)
    def ellipse_plate(mat,centre,rx,ry,height,n=36):
        top=[];bottom=[]
        for i in range(n):
            a=i/n*math.tau;top.append((centre[0]+rx*math.cos(a),centre[1]+ry*math.sin(a),centre[2]+height*.5))
            bottom.append((centre[0]+rx*math.cos(a),centre[1]+ry*math.sin(a),centre[2]-height*.5))
        for i in range(n):
            j=(i+1)%n;face(mat,[bottom[i],bottom[j],top[j],top[i]],centre)
        face(mat,top,centre);face(mat,bottom[::-1],centre)

    # Chamfered welded hull cross section: thin nose, sloping glacis, low deck.
    # Width changes describe the lower hull shoulders without an oversized box.
    profile=[(-164,30,58), (149,30,58), (172,42.5,61), (173,46.5,63),
             (115,64.8,65), (-128,64.8,65), (-164,54.5,61)]
    centre=(0,0,45)
    sides={s:[(x,s*w,z) for x,z,w in profile] for s in (-1,1)}
    for i in range(len(profile)):
        j=(i+1)%len(profile)
        face('armor',[sides[-1][i],sides[1][i],sides[1][j],sides[-1][j]],centre)
    for s in (-1,1):face('armor',sides[s],centre)
    if hasattr(api,'QA'):api.QA['HullShellTriangleCount']=len(api.TRI[(part,'armor')])

    # Glacis plate seams, splash rail, towing bosses and weld beads.
    bevel('armor',(144,0,56.8),(60,125,1.8),.65,pitch=math.radians(17.5))
    bevel('darksteel',(117.4,0,64.9),(1.15,122,1),.22)
    bevel('armor',(112.5,0,67.1),(3.5,123,3.6),.6)
    for s in (-1,1):
        weld([(115,s*65.3,65.2),(170,s*63.2,47.8)])
        weld([(-162,s*61.1,54.8),(-128,s*65.3,65.2),(112,s*65.3,65.2)])
        bevel('armor',(163,s*46,45.2),(9,12,5.4),1,pitch=math.radians(-4))
        ring('darksteel',(170,s*46,45.5),(0,1,0),3.4,.85,20,6)
        bolt((164,s*50,49),1.2);bolt((164,s*42,49),1.2)
    # Thin pressed fenders with rolled outer rails and curved/drooping ends.
    stations=[(-171,38),(-168,46),(-154,50),(-126,50.8),(100,50.8),(145,49.5),(166,44),(171,36)]
    for s in (-1,1):
        for (xa,za),(xb,zb) in zip(stations,stations[1:]):
            verts=[(xa,s*65.3,za+.5),(xa,s*94,za),(xb,s*94,zb),(xb,s*65.3,zb+.5)]
            face('armor',verts,(0,0,0))
            face('armor',[(x,y,z-.9) for x,y,z in verts[::-1]],(0,0,100))
            face('darksteel',[(xa,s*94,za-.9),(xb,s*94,zb-.9),(xb,s*94,zb),(xa,s*94,za)])
        line('armor',[(x,s*94,z+.2) for x,z in stations],.65,10)
        # Practical fender tool bins: lids, thin lips, hinges and toggle latches.
        for x,length in [(-101,48),(-42,49),(28,46)]:
            bevel('armor',(x,s*79.5,54.5),(length,23,7.2),1)
            bevel('darksteel',(x,s*79.5,58.1),(length-2,21.8,.55),.15)
            bevel('armor',(x,s*79.5,58.6),(length-1,22.4,1),.25)
            for xx in (x-length*.31,x+length*.31):
                tube('darksteel',(xx-2,s*69.5,59.2),(xx+2,s*69.5,59.2),.75,10)
                bevel('darksteel',(xx,s*91.4,55.4),(2,1.4,3.8),.2)
        # Four light early armour leaves. Their clipped corners and folds are
        # sheet metal, not thick rectangular hanging blocks.
        for i,x in enumerate((91,35,-21,-77)):
            yaw=s*math.radians(18 if i<2 else 14)
            local=[(-18,0,0),(18,0,0),(18,2.2,-13.5),(14,3.1,-17.5),(-15,3.1,-17.5),(-18,2.2,-13.5)]
            front=[transform((xx,s*yy,zz),(x,s*88.8,49.5),yaw) for xx,yy,zz in local]
            rear=[(xx,yy-s*.65,zz) for xx,yy,zz in front]
            face('armor',front,(x,0,40));face('armor',rear[::-1],(x,s*150,40))
            for k in range(len(front)):
                j=(k+1)%len(front);face('armor',[front[k],rear[k],rear[j],front[j]])
            line('armor',front+[front[0]],.23,6)
            a=transform((-15,0,0),(x,s*88.8,50.5),yaw);b=transform((15,0,0),(x,s*88.8,50.5),yaw)
            tube('darksteel',a,b,1.05,12)
            for fraction in (.15,.45,.75):
                c=add(a,mul(sub(b,a),fraction));tube('armor',c,add(c,mul(unit(sub(b,a)),3.6)),1.38,10)
            line('darksteel',[(x,s*68,49),(x,s*79,46.5),(x,s*88,49.5)],.65,8)
        # Small formed guards around the front lamps, including metal lens rim.
        lamp=(147,s*74,56)
        tube('armor',(143,s*74,56),(153,s*74,56),4.6,28)
        tube('lamp',(153.08,s*74,56),(153.3,s*74,56),3.7,28)
        ring('darksteel',(153.35,s*74,56),(1,0,0),4.05,.35,28,6)
        for yy in (s*68,s*80):
            line('darksteel',[(141,yy,51),(143,yy,62),(155,yy,62),(158,yy,51)],.55,8)
        tube('darksteel',(155,s*68,62),(155,s*80,62),.55,8)
        tube('darksteel',(144,s*68,62),(144,s*80,62),.5,8)
        # Fenders are bolted to triangular brackets, with visible lower edges.
        for x in (-136,-82,-22,43,111):
            face('armor',[(x-3,s*65,47),(x+3,s*65,47),(x+3,s*91,49),(x-3,s*91,49)])
            bolt((x,s*90,51.1),.9)

    # Engine/transmission deck: framed well, mesh below individual louvres.
    bevel('darksteel',(-86,0,65.5),(97,96,2.4),.6)
    bevel('armor',(-86,-49,67),(101,2.4,2.5),.55)
    bevel('armor',(-86,49,67),(101,2.4,2.5),.55)
    for x in (-136,-36):bevel('armor',(x,0,67),(2.4,96,2.5),.5)
    for y in range(-44,45,8):tube('darksteel',(-132,y,66),(-40,y,66),.28,6)
    for i in range(24):
        x=-131+i*3.9;bevel('armor',(x,0,68.3),(1.7,91,2.3),.4,pitch=math.radians(13))
    # Raised hinges and flush access lids, separated by dark gasket lines.
    for x,y,sx,sy in [(-147,0,23,74),(-31,-43,16,15),(-31,43,16,15),(79,40,35,32),(79,-40,35,32)]:
        bevel('darksteel',(x,y,65.5),(sx+.8,sy+.8,.6),.2)
        bevel('armor',(x,y,66.2),(sx,sy,1),.3)
        for xx in (-sx*.36,sx*.36):
            for yy in (-sy*.34,sy*.34):bolt((x+xx,y+yy,66.8),.72)
        for yy in (-sy*.27,sy*.27):tube('darksteel',(x-sx*.5-.2,y+yy-1.8,67),(x-sx*.5-.2,y+yy+1.8,67),.65,10)
    bevel('darksteel',(-163.7,0,54.8),(2.1,66,9.2),.5)
    for y in range(-27,28,6):bevel('armor',(-165,y,55),(1.2,2.1,6.5),.25)
    # Central, low driver hatch: pressed rim, recessed lid and actual glass slot.
    ellipse_plate('darksteel',(86,0,65.9),18.1,16.1,1.2,40)
    ellipse_plate('armor',(86,0,67),17.4,15.4,1.2,40)
    ellipse_plate('armor',(85.5,0,68.0),15.6,13.6,1,40)
    for y in (-9,9):tube('darksteel',(70,y-2.2,68.4),(70,y+2.2,68.4),.85,10)
    bevel('darksteel',(87,0,69),(7,2,1.3),.35)
    for y in (-5,5):tube('darksteel',(84,y,68.8),(84,y,70.8),.55,8)
    tube('darksteel',(84,-5,70.8),(84,5,70.8),.55,8)
    # Three inset periscope windows, each protected by a chamfered cover.
    for y in (-12,0,12):
        bevel('armor',(106,y,68.2),(10,9.5,5.8),.8,pitch=math.radians(-5))
        bevel('darksteel',(110.95,y,68.2),(.65,7.8,2.5),.16)
        bevel('glass',(111.33,y,68.3),(.16,6.5,1.6),.05)

    # Rear auxiliary drums sit in actual saddles rather than float above deck.
    for s in (-1,1):
        centre=(-177,s*40,55.5);radius=13.7;half=19.5
        tube('armor',add(centre,(0,-half,0)),add(centre,(0,half,0)),radius,40)
        for y in (centre[1]-half-.2,centre[1]+half+.2):
            tube('darksteel',(centre[0],y-.3,centre[2]),(centre[0],y+.3,centre[2]),radius-.45,40)
            ring('armor',(centre[0],y,centre[2]),(0,1,0),radius-.35,.55,36,6)
        for y in (centre[1]-12,centre[1]+12):
            ring('darksteel',(centre[0],y,centre[2]),(0,1,0),radius+.35,.58,36,6)
            bevel('darksteel',(centre[0]+1.2,y,41.6),(23,4.5,3),.5)
            line('darksteel',[(-159,y,47),(-168,y,41.3),(-188,y,41.3)],1.05,10)
            bevel('armor',(-163,y,47.5),(8,5,3),.5)
            bolt((-162,y,49.1),1.1)
        # Filler and retention chain are readable close-up.
        tube('darksteel',(-177,centre[1]+5,68.7),(-177,centre[1]+5,70.2),2.4,12)
        tube('armor',(-177,centre[1]+5,70.2),(-177,centre[1]+5,70.9),2.6,10)
        bevel('darksteel',(-177,centre[1]+5,71.2),(4,1,1),.2)
    # Rear light cages and tow eyes.
    for s in (-1,1):
        bevel('darksteel',(-165,s*61,47),(3,6,5),.6)
        bevel('lamp',(-166.7,s*61,47),(.6,4.2,3.6),.3)
        ring('darksteel',(-167,s*48,34),(0,1,0),3.6,1.05,22,7)
    # Long tow cables and their coiled eye ends, not unconnected rods.
    for s in (-1,1):
        points=[(-148,s*59,59),(-132,s*60,63),(-102,s*60,66.8),(-64,s*60,67.3),(-39,s*58,65.7)]
        line('darksteel',points,.8,10)
        ring('darksteel',(-37,s*57.7,65.7),(0,0,1),3.5,.65,20,6)
        ring('darksteel',(-150,s*59,59),(0,1,0),3.3,.65,20,6)
        # Rope collars and retaining clamps.
        for x in (-121,-89,-58):
            bevel('armor',(x,s*60,68),(3.3,4.2,1.8),.35)
            bolt((x,s*60,69),.68)
    # Tie-down loops, tool clamps, shovel and a restrained rear stowage bag.
    for s in (-1,1):
        for x in (-116,-52,21,82):
            line('darksteel',[(x,s*60,66),(x,s*60,69),(x+6,s*60,69),(x+6,s*60,66)],.5,8)
    tube('darksteel',(-114,-86,60.2),(-42,-86,60.2),.8,12)
    bevel('darksteel',(-37,-86,60.5),(14,7,.9),.35,yaw=math.radians(-8))
    for x in (-101,-55):bevel('armor',(x,-86,61.2),(3.5,7,1.2),.25)
    # Welded lifting tabs give the plain hull perimeter a believable scale.
    for x in (-137,108):
        for y in (-53,53):
            bevel('armor',(x,y,66.1),(10,6,1.2),.4)
            ring('darksteel',(x,y,68.3),(0,1,0),2.8,.65,20,6)
