"""Original detailed T-64A running gear, expressed in the author's mesh API.

All shapes are authored here: no imported mesh or sampled texture is used.
The paired road wheels are dished steel pressings with a narrow resilient rim.
Track shoes, grousers, guide horns and hinge ends have actual geometry.
"""
from __future__ import annotations
import math


def _add(a, b): return tuple(x+y for x,y in zip(a,b))
def _sub(a, b): return tuple(x-y for x,y in zip(a,b))
def _mul(a, t): return tuple(x*t for x in a)
def _dot(a, b): return sum(x*y for x,y in zip(a,b))
def _cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def _unit(a):
    d=math.sqrt(_dot(a,a));return _mul(a,1/d) if d>1e-12 else (0,0,1)


def _lathe(api, part, material, center, profile, sides=32):
    """Closed, smooth-around-axis lathe about Y; profile=(axial offset,radius)."""
    area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(profile,profile[1:]+profile[:1]))
    orientation=1 if area>0 else -1
    for a,b in zip(profile,profile[1:]+profile[:1]):
        dy,dr=b[0]-a[0],b[1]-a[1]
        for i in range(sides):
            t0,t1=i*math.tau/sides,(i+1)*math.tau/sides
            def v(p,t):return (center[0]+p[1]*math.cos(t),center[1]+p[0],center[2]+p[1]*math.sin(t))
            def n(t):return _unit((-dy*math.cos(t)*orientation,dr*orientation,-dy*math.sin(t)*orientation))
            vertices=[v(a,t0),v(a,t1),v(b,t1),v(b,t0)]
            normals=[n(t0),n(t1),n(t1),n(t0)]
            if _dot(_cross(_sub(vertices[1],vertices[0]),_sub(vertices[2],vertices[0])),normals[0])<0:
                vertices.reverse();normals.reverse()
            api.quad(part,material,*vertices,normals=normals)


def _local(center, tangent, normal, point):
    return _add(center,_add(_mul(tangent,point[0]),_add((0,point[1],0),_mul(normal,point[2]))))


def _oriented_box(api, part, mat, center, tangent, normal, dimensions):
    a,b,c=(v*.5 for v in dimensions)
    vertices=[_local(center,tangent,normal,p) for p in
        [(-a,-b,-c),(a,-b,-c),(a,b,-c),(-a,b,-c),(-a,-b,c),(a,-b,c),(a,b,c),(-a,b,c)]]
    for ids in ((0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)):
        api.quad(part,mat,*[vertices[i] for i in ids])


def _pressed_rib(api,part,x,y,z,angle,side):
    # A pressed ridge follows the sloped dish rather than floating over it.
    def p(r,a,depth):return (x+r*math.cos(a),y+side*depth,z+r*math.sin(a))
    lower=[p(5.4,angle-.065,5.8),p(11.4,angle-.035,3.5),
           p(11.4,angle+.035,3.5),p(5.4,angle+.065,5.8)]
    upper=[(a,b+side*.36,c) for a,b,c in lower]
    vertices=lower+upper
    # This is a sealed narrow embossing. Orient all sides away from its center.
    centre=tuple(sum(v[j] for v in vertices)/8 for j in range(3))
    for ids in ((0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)):
        vs=[vertices[i] for i in ids]
        mean=tuple(sum(v[j] for v in vs)/4 for j in range(3))
        if _dot(_cross(_sub(vs[1],vs[0]),_sub(vs[2],vs[0])),_sub(mean,centre))<0:vs.reverse()
        api.quad(part,'darksteel',*vs)


def _roadwheel(api,part,x,y,z,side):
    # Actual recessed steel profile, bevels and rolled rim, not nested flat disks.
    _lathe(api,part,'darksteel',(x,y,z),[
        (-5.5,4.1),(-2.9,8.9),(-3.3,11.6),(-5.1,12.8),
        (-5.5,13.4),(5.5,13.4),(5.1,12.8),(3.3,11.6),(2.9,8.9),(5.5,4.1)],32)
    _lathe(api,part,'rubber',(x,y,z),[
        (-5.7,13.28),(-5.7,14.02),(-4.9,14.5),(4.9,14.5),(5.7,14.02),(5.7,13.28)],32)
    # A raised lip catches light without the broad glossy face of the old wheel.
    for sign in (-1,1):
        _lathe(api,part,'darksteel',(x,y,z),[
            (sign*5.5,12.65),(sign*5.85,12.92),(sign*5.85,13.18),(sign*5.5,13.42)],32)
    api.cylinder(part,'armor',(x,y-6.7,z),(x,y+6.7,z),4.25,24)
    api.cylinder(part,'darksteel',(x,y+side*6.7,z),(x,y+side*7.05,z),3.6,24)
    api.cylinder(part,'armor',(x,y+side*7.05,z),(x,y+side*7.75,z),2.25,20)
    for i in range(6):
        a=i*math.tau/6
        _pressed_rib(api,part,x,y,z,a,side)
        xx,zz=x+5.7*math.cos(a),z+5.7*math.sin(a)
        api.cylinder(part,'darksteel',(xx,y+side*5.75,zz),(xx,y+side*6.35,zz),.78,6)
    # Oil-plug detail on the hub cover.
    api.cylinder(part,'darksteel',(x+1.2,y+side*7.75,z+.9),(x+1.2,y+side*8.05,z+.9),.48,6)


def _idler(api,part,x,y,z,side):
    _lathe(api,part,'darksteel',(x,y,z),[
        (-5.6,4),(-3.4,10.5),(-6.8,15.1),(-7.1,17.0),
        (7.1,17.0),(6.8,15.1),(3.4,10.5),(5.6,4)],36)
    # Two contact bands with a recessed guide channel in between.
    for yy in (-5.5,5.5):
        _lathe(api,part,'darksteel',(x,y+yy,z),[(-1.8,16.2),(-1.3,17.65),(1.3,17.65),(1.8,16.2)],36)
    api.cylinder(part,'armor',(x,y-7.7,z),(x,y+7.7,z),4,24)
    for i in range(8):
        a=i*math.tau/8
        xx,zz=x+7*math.cos(a),z+7*math.sin(a)
        api.cylinder(part,'darksteel',(xx,y+side*5.1,zz),(xx,y+side*5.7,zz),.85,6)
    api.cylinder(part,'darksteel',(x,y+side*7.7,z),(x,y+side*8.25,z),2.35,20)


def _toothed_ring(api,part,x,y,z,offset):
    n=60
    radii=[18.1 if i%5 in (1,2) else 15.5 for i in range(n)]
    for i in range(n):
        j=(i+1)%n; a,b=i*math.tau/n,j*math.tau/n
        # A proper annular star profile, with discrete tooth tips and roots.
        points=[]
        for yy,radius,t in ((offset-.95,radii[i],a),(offset-.95,radii[j],b),
                            (offset+.95,radii[j],b),(offset+.95,radii[i],a)):
            points.append((x+radius*math.cos(t),y+yy,z+radius*math.sin(t)))
        target=(math.cos((a+b)*.5),0,math.sin((a+b)*.5))
        if i==n-1:target=(math.cos(a+math.pi/n),0,math.sin(a+math.pi/n))
        if _dot(_cross(_sub(points[1],points[0]),_sub(points[2],points[0])),target)<0:points.reverse()
        api.quad(part,'darksteel',*points)
        for sign in (-1,1):
            yy=y+offset+sign*.95
            vs=[(x+9*math.cos(a),yy,z+9*math.sin(a)),(x+9*math.cos(b),yy,z+9*math.sin(b)),
                (x+radii[j]*math.cos(b),yy,z+radii[j]*math.sin(b)),(x+radii[i]*math.cos(a),yy,z+radii[i]*math.sin(a))]
            if _cross(_sub(vs[1],vs[0]),_sub(vs[2],vs[0]))[1]*sign<0:vs.reverse()
            api.quad(part,'darksteel',*vs)


def _sprocket(api,part,x,y,z,side):
    _lathe(api,part,'darksteel',(x,y,z),[(-7.2,3.5),(-6.4,8.8),(-2.2,12.5),
        (2.2,12.5),(6.4,8.8),(7.2,3.5)],32)
    for offset in (-6.2,6.2):_toothed_ring(api,part,x,y,z,offset)
    api.cylinder(part,'armor',(x,y-7.8,z),(x,y+7.8,z),4.7,24)
    for i in range(8):
        a=i*math.tau/8
        xx,zz=x+7.1*math.cos(a),z+7.1*math.sin(a)
        api.cylinder(part,'darksteel',(xx,y+side*6.7,zz),(xx,y+side*7.4,zz),.92,6)
    api.cylinder(part,'darksteel',(x,y+side*7.8,z),(x,y+side*8.25,z),3.1,24)


def _path(distance):
    length,radius=273.,19.5
    total=2*length+2*math.pi*radius
    s=distance%total
    if s<length:return (-132+s,43.5),(1,0,0)
    s-=length
    if s<math.pi*radius:
        a=math.pi*.5-s/radius
        return (141+radius*math.cos(a),24+radius*math.sin(a)),(math.sin(a),0,-math.cos(a))
    s-=math.pi*radius
    if s<length:return (141-s,4.5),(-1,0,0)
    s-=length;a=-math.pi*.5-s/radius
    return (-132+radius*math.cos(a),24+radius*math.sin(a)),(math.sin(a),0,-math.cos(a))


def _shoe(api,part,y,distance,pitch):
    (x,z),tangent=_path(distance)
    normal=(-tangent[2],0,tangent[0]);center=(x,y,z)
    # Chamfered eight-sided shoe with thickness, separated hinge gaps.
    length= pitch-.38; half=length*.5; wide=14.5; bevel=1.25
    outline=[(-half+bevel,-wide),(half-bevel,-wide),(half,-wide+bevel),
             (half,wide-bevel),(half-bevel,wide),(-half+bevel,wide),
             (-half,wide-bevel),(-half,-wide+bevel)]
    lower=[_local(center,tangent,normal,(a,b,-.8)) for a,b in outline]
    upper=[_local(center,tangent,normal,(a*.98,b*.98,.55)) for a,b in outline]
    def uv(v):
        q=_sub(v,center)
        return ((distance+_dot(q,tangent))/10,(_dot(q,(0,1,0))+wide)/(wide*2))
    for i in range(8):
        j=(i+1)%8
        api.triangle(part,'tracks',center,upper[i],upper[j],uv=[uv(center),uv(upper[i]),uv(upper[j])])
        base=_local(center,tangent,normal,(0,0,-.8))
        api.triangle(part,'darksteel',base,lower[j],lower[i])
        api.quad(part,'darksteel',lower[i],lower[j],upper[j],upper[i])
    _oriented_box(api,part,'darksteel',_local(center,tangent,normal,(0,0,.94)),tangent,normal,(1.5,26.4,.8))
    # Guide horn: a tapered triangular prism, actually visible inside each link.
    local=[(-2,-2.0,-.8),(2,-2.0,-.8),(0,-1.2,-4.2),(-2,2.0,-.8),(2,2.0,-.8),(0,1.2,-4.2)]
    vertices=[_local(center,tangent,normal,p) for p in local]
    centroid=tuple(sum(v[j] for v in vertices)/6 for j in range(3))
    for ids in ((0,2,1),(3,4,5),(0,1,4,3),(1,2,5,4),(2,0,3,5)):
        vs=[vertices[i] for i in ids];middle=tuple(sum(v[j] for v in vs)/len(vs) for j in range(3))
        if _dot(_cross(_sub(vs[1],vs[0]),_sub(vs[2],vs[0])),_sub(middle,centroid))<0:vs.reverse()
        (api.triangle if len(vs)==3 else api.quad)(part,'darksteel',*vs)
    # Hinge/pin ends at both exposed edges, with small face plugs.
    for sign in (-1,1):
        a=_local(center,tangent,normal,(-half+.4,sign*13.7,-.1))
        b=_local(center,tangent,normal,(-half+.4,sign*15.05,-.1))
        api.cylinder(part,'darksteel',a,b,.85,8)


def build(api):
    """Add detailed authored components to the main builder's registered parts."""
    for side,label,y,sign in [('Left','L',77,1),('Right','R',-77,-1)]:
        for i,x in enumerate([112,70,28,-14,-56,-98],1):
            _roadwheel(api,f'wheel_{label}{i}',x,y,19,sign)
            # Torsion-arm casting and shock body are fixed to the hull.
            api.cylinder('hull','darksteel',(x-12,sign*64,29),(x,sign*70,19),2.15,12)
            api.cylinder('hull','darksteel',(x-12,sign*63,29),(x-12,sign*70,29),3.0,16)
            if i in (1,2,6):
                api.cylinder('hull','darksteel',(x-8,sign*65,38),(x+2,sign*70,21),1.65,12)
                api.cylinder('hull','darksteel',(x-8,sign*65,38),(x-3,sign*67.5,29.5),2.15,12)
        for name,x,function in [('idler',141,_idler),('sprocket',-132,_sprocket)]:
            partname=f'{name}_{label}'
            api.part(partname,'wheel',(x,y,24),side)
            api.PARTS[partname]['Radius']=17.5
            function(api,partname,x,y,24,sign)
        # Three return rollers with their own brackets and dished caps.
        for x in (-91,-6,78):
            api.cylinder('hull','darksteel',(x,sign*62,37),(x,sign*76,37),1.6,12)
            _lathe(api,'hull','rubber',(x,y,37),[(-6,2.1),(-5.4,5.4),(5.4,5.4),(6,2.1)],20)
            api.cylinder('hull','armor',(x,y+sign*6.1,37),(x,y+sign*6.5,37),2.4,16)
        total=2*273+2*math.pi*19.5;count=76; pitch=total/count
        for i in range(count):_shoe(api,'track_'+side.lower(),y,(i+.5)*pitch,pitch)

