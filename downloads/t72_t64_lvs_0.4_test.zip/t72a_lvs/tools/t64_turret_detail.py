"""Original high-detail cast-turret and gun geometry for the T-64A study.

The public entry point is build(api), where api is build_t64a_model.  Only
the existing turret and gun logical parts are emitted; no mesh is imported.
This is authored game art, not a claim of measured factory geometry.
"""
from __future__ import annotations
import math

TAU = math.tau


def build(api):
    tri, quad, cyl = api.triangle, api.quad, api.cylinder
    add, sub, mul, unit, cross = api.add, api.sub, api.mul, api.unit, api.cross

    def axes(axis):
        n = unit(axis)
        u = unit(cross((0, 0, 1) if abs(n[2]) < .9 else (0, 1, 0), n))
        return n, u, cross(n, u)

    def point(c, u, v, x, y):
        return add(c, add(mul(u, x), mul(v, y)))

    def torus(part, mat, center, axis, radius, tube=.3, sectors=48, sides=8):
        n, u, v = axes(axis)
        def at(a, b):
            radial = add(mul(u, math.cos(a)), mul(v, math.sin(a)))
            normal = add(mul(radial, math.cos(b)), mul(n, math.sin(b)))
            return add(center, add(mul(radial, radius), mul(normal, tube))), normal
        for i in range(sectors):
            for j in range(sides):
                aa, ab = i / sectors * TAU, (i + 1) / sectors * TAU
                ba, bb = j / sides * TAU, (j + 1) / sides * TAU
                values = [at(aa, ba), at(ab, ba), at(ab, bb), at(aa, bb)]
                quad(part, mat, *[q[0] for q in values],
                     uv=[(i/sectors,j/sides),((i+1)/sectors,j/sides),
                         ((i+1)/sectors,(j+1)/sides),(i/sectors,(j+1)/sides)],
                     normals=[q[1] for q in values])

    def bevel_box(part, mat, center, size, bevel=.45, yaw=0):
        x, y, z = center
        hx, hy, hz = [q * .5 for q in size]
        bevel = min(bevel, hx * .45, hy * .45, hz * .45)
        co, si = math.cos(yaw), math.sin(yaw)
        def ring(inset, zz):
            a, b = hx - inset, hy - inset
            cut = max(bevel - inset, .05)
            xy = [(-a+cut,-b),(a-cut,-b),(a,-b+cut),(a,b-cut),
                  (a-cut,b),(-a+cut,b),(-a,b-cut),(-a,-b+cut)]
            return [(x+px*co-py*si,y+px*si+py*co,z+zz) for px,py in xy]
        layers = [ring(bevel,-hz),ring(0,-hz+bevel),
                  ring(0,hz-bevel),ring(bevel,hz)]
        for a, b in zip(layers,layers[1:]):
            for i in range(8):
                j=(i+1)%8
                quad(part,mat,a[i],a[j],b[j],b[i])
        for i in range(8):
            j=(i+1)%8
            tri(part,mat,(x,y,z-hz),layers[0][j],layers[0][i])
            tri(part,mat,(x,y,z+hz),layers[-1][i],layers[-1][j])

    def bolt(part, pos, radius=.8, height=.65, axis=(0,0,1), mat='darksteel'):
        n, _, _ = axes(axis)
        cyl(part,mat,pos,add(pos,mul(n,height)),radius,6)

    def handle(part, center, length=8, height=2, yaw=0, radius=.5):
        # A continuous bent rod, with welded feet, rather than three big blocks.
        x,y,z=center;co,si=math.cos(yaw),math.sin(yaw)
        path=[]
        for i in range(7):
            a=math.pi-i/6*math.pi*.5
            path.append((-length*.5+height+height*math.cos(a),height*math.sin(a)))
        path.append((length*.5-height,height))
        for i in range(1,7):
            a=math.pi*.5-i/6*math.pi*.5
            path.append((length*.5-height+height*math.cos(a),height*math.sin(a)))
        path=[(x+px*co,y+px*si,z+pz) for px,pz in path]
        for a,b in zip(path,path[1:]):cyl(part,'darksteel',a,b,radius,8)
        for sign in (-1,1):
            px=x+sign*length*.5*co;py=y+sign*length*.5*si
            bevel_box(part,'armor',(px,py,z-.15),(2.1,2.1,.6),.15)

    # One connected low cast shell.  Front and rear sections are asymmetrical;
    # no disconnected hemisphere cheeks are used.
    shell=[(64.9,-8,60.5,51.5),(66.0,-8,63.2,53.5),
           (69.5,-8,65.0,54.2),(74.5,-8.5,63.6,53.5),
           (80.0,-9.5,60.5,50.7),(85.0,-10.5,56.7,46.8),
           (89.5,-12,51.7,42.3),(93.2,-13.4,45.7,37.2),
           (96.0,-14.7,37.9,30.8),(97.0,-15,31.8,25.9)]
    sectors=80
    def shell_point(layer, angle):
        z,cx,rx,ry=shell[layer]
        front=max(math.cos(angle),0)
        # Restrained cast geometry undulation, with a broad rather than spherical nose.
        shape=1+.007*math.sin(angle*5)+.004*math.sin(angle*9+.8)
        x=cx+rx*math.cos(angle)*shape
        y=ry*math.sin(angle)*(1+.035*front)
        return (x,y,z)
    def shell_normal(layer,angle):
        around=sub(shell_point(layer,angle+.002),shell_point(layer,angle-.002))
        vertical=sub(shell_point(min(layer+1,len(shell)-1),angle),
                     shell_point(max(layer-1,0),angle))
        return unit(cross(around,vertical))
    for k in range(len(shell)-1):
        for i in range(sectors):
            a,b=i/sectors*TAU,(i+1)/sectors*TAU
            coords=[shell_point(k,a),shell_point(k,b),shell_point(k+1,b),shell_point(k+1,a)]
            normals=[shell_normal(k,a),shell_normal(k,b),shell_normal(k+1,b),shell_normal(k+1,a)]
            # World-scale planar top projection preserves the paint's grain density.
            quad('turret','armor',*coords,uv=[(q[0]/55,q[1]/55) for q in coords],normals=normals)
    for k,up in [(0,False),(len(shell)-1,True)]:
        for i in range(sectors):
            a,b=shell_point(k,i/sectors*TAU),shell_point(k,(i+1)/sectors*TAU)
            center=(shell[k][1],0,shell[k][0])
            tri('turret','armor',center,*( (a,b) if up else (b,a)))
    cyl('turret','darksteel',(-8,0,63.9),(-8,0,65.1),48.2,80)
    torus('turret','darksteel',(-8,0,65.3),(0,0,1),49,.36,80,8)

    # Roof fittings: low cupola, lid seat, hinges, stops and actual framed optics.
    for x,y,r,z,commander in [(-27,-22,14.5,97,True),(-12,23,14.0,96.6,False)]:
        cyl('turret','darksteel',(x,y,z-.4),(x,y,z+.5),r+1.6,56)
        cyl('turret','armor',(x,y,z+.4),(x,y,z+3.7),r+.7,56)
        torus('turret','armor',(x,y,z+1.1),(0,0,1),r+1,.45,56,8)
        cyl('turret','armor',(x,y,z+3.7),(x,y,z+5.4),r,56)
        torus('turret','darksteel',(x,y,z+3.55),(0,0,1),r-.2,.20,56,6)
        for a in range(0,360,30):
            rad=math.radians(a)
            bolt('turret',(x+(r+1.3)*math.cos(rad),y+(r+1.3)*math.sin(rad),z+1.5),.48,.48)
        handle('turret',(x+2,y,z+5.4),8,1.6,yaw=.15,radius=.48)
        for yy in (y-5,y+5):
            bevel_box('turret','armor',(x-r+1,yy,z+4),(5,3,3),.5)
            cyl('turret','darksteel',(x-r-.5,yy-2,z+4),(x-r-.5,yy+2,z+4),1,16)
        if commander:
            for aa in (-65,-25,15,55,95):
                angle=math.radians(aa)
                px=x+(r-.8)*math.cos(angle);py=y+(r-.8)*math.sin(angle)
                bevel_box('turret','armor',(px,py,z+2.7),(7.4,4.7,3.6),.45,yaw=angle)
                bevel_box('turret','darksteel',(px+.2*math.cos(angle),py+.2*math.sin(angle),z+4.1),(5.9,3.2,.9),.15,yaw=angle)
                bevel_box('turret','glass',(px+.2*math.cos(angle),py+.2*math.sin(angle),z+4.6),(4.9,2.1,.25),.08,yaw=angle)

    # Optical rangefinder housings sit into the cast sides, rather than giant spheres.
    for sign in (-1,1):
        cy=sign*47
        bevel_box('turret','armor',(4,cy,85),(19,9,12),1.7,yaw=sign*.06)
        cyl('turret','darksteel',(5,cy-sign,85),(5,cy+sign*5.8,85),5.1,32)
        cyl('turret','armor',(5,cy+sign*4.6,85),(5,cy+sign*6.1,85),5.7,32)
        cyl('turret','glass',(5,cy+sign*6.2,85),(5,cy+sign*6.35,85),4.25,32)
        torus('turret','darksteel',(5,cy+sign*6.4,85),(0,1,0),4.65,.24,32,6)
        for xx in (-2,12):bolt('turret',(xx,cy,91.1),.6,.6)

    # Luna-style IR searchlight, offset left of the gun: stepped housing,
    # retaining ring, lens, protective cross-bars and mounting yoke.
    bevel_box('turret','armor',(41,31,77),(13,17,6),1.0)
    for yy in (24,38):bevel_box('turret','darksteel',(45,yy,83),(5,2,13),.5)
    cyl('turret','armor',(41,31,87),(54,31,87),10.3,48,r2=9.5)
    cyl('turret','darksteel',(53.6,31,87),(55,31,87),10.1,48)
    cyl('turret','glass',(55.1,31,87),(55.25,31,87),8.7,48)
    torus('turret','armor',(55.5,31,87),(1,0,0),9.3,.45,48,8)
    for angle in (0,math.pi*.5):
        y,z=8.6*math.cos(angle),8.6*math.sin(angle)
        cyl('turret','darksteel',(56,31-y,87-z),(56,31+y,87+z),.33,8)
    for angle in range(0,360,60):
        aa=math.radians(angle)
        bolt('turret',(55.7,31+9.35*math.cos(aa),87+9.35*math.sin(aa)),.48,.45,(1,0,0))

    # Rear stowage box with a rolled lid, catches and restrained weld seams.
    bevel_box('turret','armor',(-65,0,81),(22,79,16),1.2)
    bevel_box('turret','armor',(-65,0,89.8),(23.6,81,2.4),.7)
    for yy in (-29,-10,10,29):
        bevel_box('turret','darksteel',(-77,yy,83),(1.3,5,7),.3)
        bevel_box('turret','armor',(-77.9,yy,84),(1.4,3,3.5),.22)
        cyl('turret','darksteel',(-77.5,yy-2.5,86),(-77.5,yy+2.5,86),.55,10)
    for yy in (-36,36):handle('turret',(-65,yy,91),7,1.5,radius=.42)
    # Cable-routing clips and lift lugs attach to the shell's broad shoulders.
    for yy in (-39,39):
        for xx,z in [(-39,86),(21,84)]:
            bevel_box('turret','armor',(xx,yy,z),(6,4,2.5),.7)
            torus('turret','darksteel',(xx,yy,z+3),(0,1,0),2.6,.8,24,8)
    cyl('turret','armor',(-37,30,93.5),(-37,30,102),2.8,24,r2=1.8)
    torus('turret','darksteel',(-37,30,101),(0,0,1),2.2,.3,24,6)
    cyl('turret','darksteel',(-37,30,102),(-37.5,30.3,161),.4,12,r2=.17)

    # Flexible fabric mantlet boot: one continuous elliptical shell with folds.
    boot=[]
    for j in range(21):
        t=j/20
        x=44+t*35
        fold=math.sin(t*math.pi*10)*(.9-.4*t)
        ry=18*(1-t)+7.3*t+fold
        rz=16*(1-t)+6.6*t+fold*.8
        boot.append((x,ry,rz))
    sectors=56
    for j in range(len(boot)-1):
        for i in range(sectors):
            aa,bb=i/sectors*TAU,(i+1)/sectors*TAU
            def bpoint(k,a):
                x,ry,rz=boot[k]
                t=k/(len(boot)-1)
                # Real cloth is not an axially perfect vacuum hose. Add broad
                # unequal drape folds without changing the working barrel axis.
                wrinkle=.55*math.sin(a*3+t*3.3)*math.sin(math.pi*t)
                drape=.6*math.sin(a*2+.7)*math.sin(math.pi*t)
                return (x,(ry+wrinkle)*math.cos(a),82+(rz+wrinkle)*math.sin(a)+drape)
            vals=[bpoint(j,aa),bpoint(j,bb),bpoint(j+1,bb),bpoint(j+1,aa)]
            # Angle tangent crossed with the +X axis gives the outer normal.
            quad('gun','armor',vals[0],vals[1],vals[2],vals[3])
    for x,ry,rz in (boot[0],boot[-1]):
        for i in range(56):
            aa,bb=i/56*TAU,(i+1)/56*TAU
            a=(x,ry*math.cos(aa),82+rz*math.sin(aa))
            b=(x,ry*math.cos(bb),82+rz*math.sin(bb))
            cyl('gun','darksteel',a,b,.25,6)

    # Bare early 125 mm tube: continuous stepped lathe, fume extractor and
    # narrow retaining rings. No post-period full thermal jacket is invented.
    sections=[(76,7.2),(79,6.7),(81,5.15),(86,4.9),(141,4.6),
              (144,5.9),(146,6.2),(175,6.2),(179,5.8),(181,4.45),
              (250,4.0),(308,3.65),(312.8,3.7),(313,3.7)]
    n=64
    for k in range(len(sections)-1):
        x0,r0=sections[k];x1,r1=sections[k+1]
        slope=(r0-r1)/max(x1-x0,.01)
        for i in range(n):
            aa,bb=i/n*TAU,(i+1)/n*TAU
            values=[(x0,r0*math.cos(aa),82+r0*math.sin(aa)),
                    (x0,r0*math.cos(bb),82+r0*math.sin(bb)),
                    (x1,r1*math.cos(bb),82+r1*math.sin(bb)),
                    (x1,r1*math.cos(aa),82+r1*math.sin(aa))]
            normals=[unit((slope,math.cos(a),math.sin(a))) for a in (aa,bb,bb,aa)]
            quad('gun','armor',*values,
                 uv=[(x0/40,i/n),(x0/40,(i+1)/n),(x1/40,(i+1)/n),(x1/40,i/n)],
                 normals=normals)
    for xx,rr in ((82,5.2),(143.8,5.95),(178.8,5.85),(251,4.13)):
        torus('gun','darksteel',(xx,0,82),(1,0,0),rr,.18,64,6)
    # Annular muzzle rim and a recessed black bore, maintaining x=313 socket.
    for i in range(n):
        aa,bb=i/n*TAU,(i+1)/n*TAU
        outer=[(313,3.7*math.cos(a),82+3.7*math.sin(a)) for a in (aa,bb)]
        inner=[(313,2.85*math.cos(a),82+2.85*math.sin(a)) for a in (aa,bb)]
        quad('gun','darksteel',outer[0],outer[1],inner[1],inner[0])
        a,b=inner
        quad('gun','darksteel',b,(299,b[1],b[2]),(299,a[1],a[2]),a)
        tri('gun','rubber',(298.9,0,82),(298.9,a[1],a[2]),(298.9,b[1],b[2]))
    # Coaxial opening, thin lip and fixed aperture beside the boot.
    bevel_box('gun','darksteel',(53,-9,79),(10,4,5),.7)
    cyl('gun','darksteel',(54,-9,79),(59,-9,79),1.55,24,caps=False)
    torus('gun','darksteel',(59,-9,79),(1,0,0),1.55,.24,24,6)

