"""Original model export checks; these do not execute Garry's Mod."""
import importlib.util
import json
import math
from pathlib import Path
import struct
import unittest
import zlib

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('t64_original_model_builder',ROOT/'tools/build_t64a_model.py')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)

class OriginalT64Geometry(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.parts,cls.triangles=model.build()
 def test_original_component_inventory_and_budget(self):
  self.assertEqual(len(self.parts),21)
  self.assertTrue({'hull','turret','gun','track_left','track_right'}<=set(self.parts))
  self.assertTrue(all('wheel_'+side+str(i) in self.parts for side in ('L','R') for i in range(1,7)))
  self.assertGreater(sum(map(len,self.triangles.values())),60000)
  self.assertLess(sum(map(len,self.triangles.values())),150000)
 def test_closed_main_hull_has_outward_faces(self):
  # Audit the actual continuous primary hull separately from attached hardware.
  count=model.QA.get('HullShellTriangleCount',0)
  self.assertGreaterEqual(count,12)
  inside=(0,0,45)
  for tri in self.triangles['hull','armor'][:count]:
   centre=tuple(sum(v[0][i] for v in tri)/3 for i in range(3))
   self.assertGreater(model.dot(tri[0][1],model.sub(centre,inside)),0)
 def test_finite_vertices_unit_normals_and_matching_winding(self):
  for key,triangles in self.triangles.items():
   for tri in triangles:
    a,b,c=[v[0] for v in tri]
    geometric=model.unit(model.cross(model.sub(b,a),model.sub(c,a)))
    for pos,normal,uv in tri:
     self.assertTrue(all(math.isfinite(x) for x in (*pos,*normal,*uv)))
     self.assertAlmostEqual(model.dot(normal,normal),1,places=5)
     self.assertGreater(model.dot(geometric,normal),-.001, key)
 def test_correct_logical_pivots_and_original_materials(self):
  self.assertEqual(self.parts['turret']['Pivot'],[-8,0,65])
  self.assertEqual(self.parts['gun']['Pivot'],[45,0,82])
  self.assertEqual(self.parts['wheel_L1']['Pivot'],[112,77,19])
  self.assertEqual(self.parts['wheel_R6']['Pivot'],[-98,-77,19])
  self.assertEqual(set(m for p,m in self.triangles),{'armor','darksteel','rubber','tracks','glass','lamp'})
 def test_repeat_build_does_not_duplicate_geometry(self):
  before=sum(map(len,self.triangles.values()))
  _,again=model.build()
  self.assertEqual(sum(map(len,again.values())),before)
 def test_exported_shards_fit_client_network_limit(self):
  paths=list((ROOT/'lua/t64a_1971/geometry').glob('chunk_*.lua'))
  self.assertGreater(len(paths),1)
  for p in paths:
   raw=p.read_bytes()
   self.assertLess(len(zlib.compress(raw)),60000,p.name)
   self.assertIn(b't64a_1971/',raw)
  data=json.loads((ROOT/'assets/source/t64a_1971/model_geometry.json').read_text())
  self.assertEqual(sum(len(m['triangles']) for m in data['meshes']),sum(map(len,self.triangles.values())))
 def test_portable_glb_container_is_complete(self):
  p=ROOT/'assets/source/t64a_1971/t64a_1971.glb'
  if not p.exists(): self.skipTest('optional original source export not generated')
  data=p.read_bytes()
  self.assertEqual(data[:4],b'glTF')
  self.assertEqual(struct.unpack_from('<II',data,4),(2,len(data)))
  n,kind=struct.unpack_from('<II',data,12)
  self.assertEqual(kind,0x4E4F534A)
  meta=json.loads(data[20:20+n]);self.assertGreater(len(meta['meshes']),10)
  self.assertGreater(len(meta.get('materials',[])),4)

if __name__=='__main__':unittest.main()
