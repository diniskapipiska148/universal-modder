-- Runtime contracts for original T64 IMesh rendering; no GMod session needed.
local root = arg[1] or "."
local V = {};V.__index=V
function Vector(x,y,z) return setmetatable({x=x,y=y,z=z},V) end
function V.__add(a,b) return Vector(a.x+b.x,a.y+b.y,a.z+b.z) end
function V.__sub(a,b) return Vector(a.x-b.x,a.y-b.y,a.z-b.z) end
function V.__mul(a,b) return Vector(a.x*b,a.y*b,a.z*b) end
function V.__div(a,b) return Vector(a.x/b,a.y/b,a.z/b) end
function V:Dot(b) return self.x*b.x+self.y*b.y+self.z*b.z end
function V:Cross(b) return Vector(self.y*b.z-self.z*b.y,self.z*b.x-self.x*b.z,self.x*b.y-self.y*b.x) end
function V:LengthSqr() return self:Dot(self) end
function V:GetNormalized() local n=math.sqrt(self:LengthSqr());if n==0 then return Vector(0,0,0) end;return self/n end
function Angle(p,y,r) return {p=p,y=y,r=r} end
local M={};M.__index=M
local function identity() return {{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}} end
function Matrix() return setmetatable({v=identity()},M) end
function M:Multiply(b)
 local a,out=self.v,identity()
 for i=1,4 do for j=1,4 do out[i][j]=0;for k=1,4 do out[i][j]=out[i][j]+a[i][k]*b[k][j] end end end
 self.v=out
end
function M:SetTranslation(v) self.v[1][4]=v.x;self.v[2][4]=v.y;self.v[3][4]=v.z end
local function rotation(a)
 local p,y=math.rad(a.p),math.rad(a.y)
 local cp,sp,cy,sy=math.cos(p),math.sin(p),math.cos(y),math.sin(y)
 return {{cy*cp,-sy,cy*sp,0},{sy*cp,cy,sy*sp,0},{-sp,0,cp,0},{0,0,0,1}}
end
function M:SetAngles(a) local t=Vector(self.v[1][4],self.v[2][4],self.v[3][4]);self.v=rotation(a);self:SetTranslation(t) end
function M:Rotate(a) self:Multiply(rotation(a)) end
function M:Translate(t) local m=identity();m[1][4]=t.x;m[2][4]=t.y;m[3][4]=t.z;self:Multiply(m) end
function M:Point(p) local a=self.v;return Vector(a[1][1]*p.x+a[1][2]*p.y+a[1][3]*p.z+a[1][4],a[2][1]*p.x+a[2][2]*p.y+a[2][3]*p.z+a[2][4],a[3][1]*p.x+a[3][2]*p.y+a[3][3]*p.z+a[3][4]) end
function IsValid(v) return v~=nil end
math.Clamp=function(n,a,b) return math.max(a,math.min(n,b)) end
math.AngleDifference=function(a,b) return (a-b+180)%360-180 end
local frame,dt=1,.02
function FrameNumber() return frame end
function FrameTime() return dt end
local fixture={Chunks={"fixture_hull","fixture_turret","fixture_gun","fixture_wheel","fixture_left","fixture_right"},Parts={
 hull={Kind="hull",Pivot={0,0,0}},turret={Kind="turret",Pivot={-8,0,65}},
 gun={Kind="gun",Pivot={45,0,82}},wheel_L1={Kind="wheel",Pivot={112,77,19},Side="Left"},
 track_left={Kind="track",Pivot={0,0,0},Side="Left"},track_right={Kind="track",Pivot={0,0,0},Side="Right"}}}
local names={"hull","turret","gun","wheel_L1","track_left","track_right"}
local triangle={0,0,0,0,0,1,0,0,1,0,0,0,0,1,1,0,0,1,0,0,0,1,0,1}
function include(path)
 if path=="t64a_1971/geometry/index.lua" then return fixture end
 for i,p in ipairs(fixture.Chunks) do if path==p then return {Part=names[i],Material="t64a_1971/"..(i>=5 and "tracks" or "armor"),Vertices=triangle} end end
 error("unexpected include "..path)
end
function Material(name) return {name=name,GetString=function(_,key) return key=="$basetexture" and "t64a_1971/tracks_color" or nil end} end
local private={}
function CreateMaterial(name,shader,values)
 local v={name=name,values=values,SetMatrix=function(self,k,m) self[k]=m end};private[#private+1]=v;return v
end
local builds,destroyed,draws,errors=0,0,0,0
local fail=false
function Mesh()
 return {BuildFromTriangles=function(_,vertices)
  builds=builds+1;assert(#vertices==3 and #vertices[1].userdata==4,"triangles require normalmap tangent data")
 end,Destroy=function() destroyed=destroyed+1 end,Draw=function() if fail then error("injected draw failure") end;draws=draws+1 end}
end
local hooks={}
hook={Add=function(event,_,callback) hooks[event]=callback end}
function ErrorNoHalt() errors=errors+1 end
local colour={.3,.4,.5};local blend=.7;local suppress=false;local depth=0;local lightingOrigin
render={GetColorModulation=function() return table.unpack(colour) end,GetBlend=function() return blend end,
 SetLightingOrigin=function(v) lightingOrigin=v end,SuppressEngineLighting=function(v) suppress=v end,ResetModelLighting=function() end,
 ComputeLighting=function() return Vector(.2,.3,.4) end,SetModelLighting=function() end,
 SetColorModulation=function(r,g,b) colour={r,g,b} end,SetBlend=function(v) blend=v end,SetMaterial=function() end}
cam={PushModelMatrix=function() depth=depth+1 end,PopModelMatrix=function() depth=depth-1 end}
ENT={}
dofile(root.."/lua/t64a_1971/cl_mesh.lua")
local function vehicle()
 local v=setmetatable({origin=Vector(0,0,0),bodyYaw=0,turretYaw=0,pitch=0,speed=100,
  T72Profile={Wheels={Left={Vector(112,77,19)},Radius=14.5},TrackUVUnits=10,
   Rig={TurretPivot=Vector(-8,0,65),GunPivot=Vector(45,0,82)},RenderMins={},RenderMaxs={}},callbacks={}}, {__index=ENT})
 function v:GetPos() return self.origin end
 function v:GetAngles() return Angle(0,self.bodyYaw,0) end
 function v:GetTurretYaw() return self.turretYaw end
 function v:GetTurretPitch() return self.pitch end
 function v:GetVelocity() return Vector(self.speed,0,0) end
 function v:GetForward() return Vector(1,0,0) end
 function v:GetColor() return {r=255,g=255,b=255,a=255} end
 function v:OBBCenter() return Vector(1,2,3) end
 function v:LocalToWorld(p)
  local a=math.rad(self.bodyYaw)
  return self.origin+Vector(p.x*math.cos(a)-p.y*math.sin(a),p.x*math.sin(a)+p.y*math.cos(a),p.z)
 end
 function v:DrawShadow() end
 function v:SetRenderBounds() end
 function v:CallOnRemove(name,f) self.callbacks[name]=f end
 return v
end
local n=0
local function check(value,message) n=n+1;assert(value,message) end
local function near(a,b,message) check((a-b):LengthSqr()<1e-8,message) end
local a,b=vehicle(),vehicle()
a:Draw();b:Draw()
check(builds==6 and draws==12,"share static original geometry across vehicles")
check(a._T64MeshCache==b._T64MeshCache,"shared cache")
check(a._T64TrackMaterials.Left~=b._T64TrackMaterials.Left,"track transforms stay per vehicle")
check(not suppress and depth==0 and blend==.7 and colour[1]==.3,"restore global render state")
local phase=a._T64WheelLeft;a:Draw();check(phase==a._T64WheelLeft,"update animation once per frame")
local matrices=a._T64TrackMaterials.Left
check(matrices['$basetexturetransform']==matrices['$bumptransform'],"normal/color track movement stays synchronized")
check(matrices['$basetexturetransform'].v[1][4]<0 and matrices['$basetexturetransform'].v[2][4]==0,"track moves longitudinal U")
a.turretYaw=90
near(a:T64PartMatrix(fixture.Parts.turret):Point(Vector(0,0,0)),Vector(-8,0,65),"turret yaw keeps pivot")
near(a:T64PartMatrix(fixture.Parts.gun):Point(Vector(0,0,0)),Vector(-8,53,82),"gun pivot follows turret yaw")
a.pitch=10
local p=a:T64PartMatrix(fixture.Parts.gun):Point(Vector(268,0,0))
near(p,Vector(-8,53+268*math.cos(math.rad(10)),82-268*math.sin(math.rad(10))),"gun point uses same pitch/yaw chain as firing")
a.origin=Vector(10,20,30);a.bodyYaw=90
near(a:T64PartMatrix(fixture.Parts.turret):Point(Vector(0,0,0)),Vector(10,12,95),"world body frame affects visual pivot")
fail=true;frame=2;a:Draw();fail=false
check(errors==1 and depth==0 and not suppress and blend==.7,"renderer failure restores stacks and lighting")
near(lightingOrigin,Vector(8,21,33),"light probe origin must transform OBB centre into world coordinates")
a.callbacks.T64GeneratedMeshRelease(a)
check(destroyed==0,"removing one tank must not destroy another tank's meshes")
b.callbacks.T64GeneratedMeshRelease(b)
check(destroyed==6,"last owner frees static meshes")
local c=vehicle();c:Draw();check(builds==12,"new tank rebuilds disposed cache")
hooks.ShutDown();check(destroyed==12,"shutdown destroys cached mesh resources")
print("PASS: "..n.." T64 mesh caching, transforms, tangents, U-scroll and cleanup contracts (mock GMod)")
