-- Original generated mesh renderer. No external tank MDL is loaded here.
local definition = include("t64a_1971/geometry/index.lua")
local store = {Meshes = {}, Refs = 0, Built = false, Dead = false}
local serial = 0
local directions = {Vector(0,0,1), Vector(0,0,-1), Vector(1,0,0),
    Vector(-1,0,0), Vector(0,1,0), Vector(0,-1,0)}

local function destroyStore(cache)
    if cache.Dead then return end
    cache.Dead = true
    for _, item in ipairs(cache.Meshes) do item.Mesh:Destroy() end
    cache.Meshes = {}
end

local function release(vehicle)
    local cache = vehicle._T64MeshCache
    if not cache then return end
    vehicle._T64MeshCache = nil
    cache.Refs = math.max(cache.Refs - 1, 0)
    if cache.Refs == 0 then destroyStore(cache) end
end

local function finite(value)
    return type(value) == "number" and value == value and math.abs(value) < 1000000
end

local function unpackVertices(flat)
    assert(type(flat) == "table" and #flat > 0 and #flat % 24 == 0,
        "invalid generated triangle data")
    assert(#flat <= 2048 * 3 * 8, "mesh chunk exceeds supported size")
    local vertices = {}
    for i = 1, #flat, 8 do
        for offset = 0, 7 do assert(finite(flat[i + offset]), "non-finite generated vertex") end
        vertices[#vertices + 1] = {
            pos = Vector(flat[i], flat[i+1], flat[i+2]),
            normal = Vector(flat[i+3], flat[i+4], flat[i+5]),
            u = flat[i+6], v = flat[i+7]
        }
    end
    -- Supply tangent userdata required by Source's normal-mapped model shaders.
    for i = 1, #vertices, 3 do
        local a,b,c = vertices[i], vertices[i+1], vertices[i+2]
        local e1,e2 = b.pos-a.pos, c.pos-a.pos
        local du1,dv1,du2,dv2 = b.u-a.u,b.v-a.v,c.u-a.u,c.v-a.v
        local determinant = du1*dv2-du2*dv1
        local tangent, bitangent
        if math.abs(determinant) > 0.0000001 then
            tangent = (e1*dv2-e2*dv1)/determinant
            bitangent = (e2*du1-e1*du2)/determinant
        end
        for j = i, i+2 do
            local vertex = vertices[j]
            local normal = vertex.normal:GetNormalized()
            local t = tangent and (tangent-normal*normal:Dot(tangent)):GetNormalized()
            if not t or t:LengthSqr() < 0.1 then
                t = normal:Cross(math.abs(normal.z) < 0.9 and Vector(0,0,1) or Vector(0,1,0)):GetNormalized()
            end
            local handedness = bitangent and normal:Cross(t):Dot(bitangent) < 0 and -1 or 1
            vertex.userdata = {t.x,t.y,t.z,handedness}
        end
    end
    return vertices
end

local function buildStore(cache)
    if cache.Built then return end
    local success, message = xpcall(function()
        for _, path in ipairs(definition.Chunks) do
            local chunk = include(path)
            assert(definition.Parts[chunk.Part], "unknown generated part")
            assert(type(chunk.Material) == "string" and chunk.Material:sub(1,10) == "t64a_1971/",
                "unexpected generated material")
            local material = Material(chunk.Material)
            local geometry = Mesh(material)
            cache.Meshes[#cache.Meshes + 1] = {Mesh = geometry, Part = chunk.Part,
                Material = material, MaterialPath = chunk.Material}
            geometry:BuildFromTriangles(unpackVertices(chunk.Vertices))
        end
        cache.Built = true
    end, debug.traceback)
    if not success then destroyStore(cache); error(message) end
end

local function trackMaterial(side)
    serial = serial + 1
    local original = Material("t64a_1971/tracks")
    local values = {["$model"] = "1"}
    for _, key in ipairs({"$basetexture", "$bumpmap", "$phong", "$phongexponent",
        "$phongboost", "$basemapalphaphongmask", "$phongfresnelranges"}) do
        local value = original:GetString(key)
        if value and value ~= "" then values[key] = value end
    end
    values["$basetexture"] = values["$basetexture"] or "t64a_1971/tracks_color"
    return CreateMaterial("t64a1971_track_"..side.."_"..serial, "VertexLitGeneric", values)
end

function ENT:T64EnsureMeshes()
    if self._T64MeshCache and not self._T64MeshCache.Dead then return self._T64MeshCache end
    if store.Dead then store = {Meshes = {}, Refs = 0, Built = false, Dead = false} end
    buildStore(store)
    store.Refs = store.Refs + 1
    self._T64MeshCache = store
    self._T64TrackMaterials = {Left = trackMaterial("left"), Right = trackMaterial("right")}
    self:CallOnRemove("T64GeneratedMeshRelease", release)
    self:DrawShadow(false)
    self:SetRenderBounds(self.T72Profile.RenderMins, self.T72Profile.RenderMaxs)
    return store
end

function ENT:T64AnimateMeshes()
    local frame = FrameNumber()
    if self._T64Frame == frame then return end
    self._T64Frame = frame
    local dt = math.Clamp(FrameTime(), 0.0001, 0.1)
    local yaw = self:GetAngles().y
    local rate = self._T64LastYaw and math.rad(math.AngleDifference(yaw,self._T64LastYaw))/dt or 0
    self._T64LastYaw = yaw
    local forward = self:GetVelocity():Dot(self:GetForward())
    local spacing = math.abs(self.T72Profile.Wheels.Left[1].y)
    local radius = self.T72Profile.Wheels.Radius
    local uvScale = self.T72Profile.TrackUVUnits or 10
    for _, side in ipairs({"Left", "Right"}) do
        local speed = forward + (side == "Left" and -1 or 1)*rate*spacing
        local phase = "_T64Wheel"..side
        local scroll = "_T64Track"..side
        self[phase] = ((self[phase] or 0)+math.deg(speed*dt/radius))%360
        self[scroll] = ((self[scroll] or 0)+speed*dt/uvScale)%1
        local matrix = Matrix()
        matrix:Translate(Vector(-self[scroll],0,0))
        self._T64TrackMaterials[side]:SetMatrix("$basetexturetransform",matrix)
        self._T64TrackMaterials[side]:SetMatrix("$bumptransform",matrix)
    end
end

local function point(value) return Vector(value[1],value[2],value[3]) end

function ENT:T64PartMatrix(part)
    local transform = Matrix()
    transform:SetTranslation(self:GetPos())
    transform:SetAngles(self:GetAngles())
    local pivot = point(part.Pivot)
    local rig = self.T72Profile.Rig
    if part.Kind == "turret" or part.Kind == "gun" then
        transform:Translate(rig.TurretPivot)
        transform:Rotate(Angle(0,self:GetTurretYaw(),0))
        if part.Kind == "gun" then
            transform:Translate(rig.GunPivot-rig.TurretPivot)
            transform:Rotate(Angle(self:GetTurretPitch(),0,0))
            transform:Translate(pivot-rig.GunPivot)
        else
            transform:Translate(pivot-rig.TurretPivot)
        end
    else
        transform:Translate(pivot)
        if part.Kind == "wheel" then
            transform:Rotate(Angle((self["_T64Wheel"..part.Side] or 0)*self.T72Profile.Wheels.Radius/(part.Radius or self.T72Profile.Wheels.Radius),0,0))
        end
    end
    return transform
end

function ENT:Draw()
    local ok, cache = pcall(self.T64EnsureMeshes,self)
    if not ok then
        if not self._T64Reported then ErrorNoHalt("[T-64A] "..tostring(cache).."\n");self._T64Reported=true end
        return
    end
    self:T64AnimateMeshes()
    local oldR,oldG,oldB = render.GetColorModulation()
    local oldBlend = render.GetBlend()
    local colour = self:GetColor()
    local origin = self:LocalToWorld(self:OBBCenter())
    local pushed = false
    local success, message = xpcall(function()
        render.SetLightingOrigin(origin)
        render.SuppressEngineLighting(true)
        render.ResetModelLighting(0,0,0)
        for id, normal in ipairs(directions) do
            local light = render.ComputeLighting(origin,normal)
            render.SetModelLighting(id-1,math.max(light.x,0.04),math.max(light.y,0.04),math.max(light.z,0.04))
        end
        render.SetColorModulation(colour.r/255,colour.g/255,colour.b/255)
        render.SetBlend(colour.a/255)
        local transforms = {}
        for _, item in ipairs(cache.Meshes) do
            local part = definition.Parts[item.Part]
            if not transforms[item.Part] then transforms[item.Part] = self:T64PartMatrix(part) end
            local material = part.Kind == "track" and self._T64TrackMaterials[part.Side] or item.Material
            render.SetMaterial(material)
            cam.PushModelMatrix(transforms[item.Part])
            pushed = true
            item.Mesh:Draw()
            cam.PopModelMatrix()
            pushed = false
        end
    end, debug.traceback)
    if pushed then cam.PopModelMatrix() end
    render.SuppressEngineLighting(false)
    render.SetColorModulation(oldR,oldG,oldB)
    render.SetBlend(oldBlend)
    if not success and not self._T64Reported then
        self._T64Reported = true
        ErrorNoHalt("[T-64A] generated mesh draw: "..tostring(message).."\n")
    end
end
function ENT:DrawTranslucent() end

if hook then
    hook.Add("ShutDown", "T64GeneratedMeshCleanup", function() destroyStore(store) end)
    hook.Add("OnReloaded", "T64GeneratedMeshReload", function() destroyStore(store) end)
end
