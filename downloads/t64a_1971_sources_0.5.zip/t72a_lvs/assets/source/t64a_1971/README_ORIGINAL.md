# Original T-64A circa1971 game model

This geometry was authored from scratch in `tools/build_t64a_model.py` and its
three `t64_*_detail.py` component modules. No tank
mesh or tank texture was imported from another game or Workshop addon. It is a
procedural game-art interpretation of early T-64A features, not a measured CAD
reconstruction. Version 0.5 was rebuilt from five user-supplied visual reference
screenshots. It has small steel road wheels, a broad low cast turret, a cheek
rangefinder housing, rear OPVT tube and a wooden self-recovery beam. Side armour
screens and their projecting hinges are deliberately omitted. No ERA or later
roof antiaircraft gun is fitted.

- Version 0.5: 150,992 triangles, 21 logical parts, 138 compressed Lua chunks.
  The runtime batches compatible chunks into 68 IMesh objects without removing
  geometry. See model_metadata.json for export metadata.
- Six road wheels per side plus visible idlers and drive sprockets. Each belt
  has 76 modeled shoes with grousers, pins and guide horns. Shoes share a static
  belt mesh; UV scrolling supplies motion, not articulated moving links.
- The rebuilt hull and turret use continuous surfaces, shaped fenders, hatches,
  optics, grilles, lifting eyes, fasteners, canvas and suspension.
- Only the tank is in the editable exports. The reference game's UI, scenery,
  weapon display stands and people are not part of this asset. Studio lighting
  and the neutral floor are added after the reusable model has been saved.
- Canonical Lua/runtime coordinates: +X forward, +Y left, +Z up, Source units.
- The separate GLB export uses the standard glTF Y-up conversion; the Blender
  source keeps its normal Z-up scene. Neither conversion changes runtime Lua.
- Lua vertex shards contain part-local xyz, normal xyz, UV coordinates. Each
  shard stays comfortably below Garry's Mod's compressed client Lua size limit.
- The Blender source and GLB embed the original newly generated texture maps.
- Stock GMod cube/wheel models used by the code are invisible physics handles;
  all visible tank geometry is the original generated component mesh.

Regenerate Lua/JSON data with:

```sh
python tools/build_t64a_model.py --addon /path/to/addon
```

Use `--sources` with Blender installed to regenerate the Blender/GLB sources and
render previews. The builder uses the supplied `material_sources/` PNGs. The
separate material builder can recreate these from `paint_generated.png`.
Previews are offline Blender renders, not Garry's Mod screenshots. The assembled
GMod vehicle, lighting, movement and networking still require an in-game check.
