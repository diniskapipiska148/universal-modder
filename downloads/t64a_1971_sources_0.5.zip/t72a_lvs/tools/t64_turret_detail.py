"""Original high-detail cast-turret and gun geometry for the T-64A study.

The public entry point is build(api), where api is build_t64a_model.  Only
the existing turret and gun logical parts are emitted; no mesh is imported.
This is authored game art, not a claim of measured factory geometry.
"""
from __future__ import annotations
import math

TAU = math.tau


def build(api):
    tri, quad, cyl = api.triangle, api.quad, api.cylinder
    add, sub, mul, unit, cross = api.add, api.sub, api.mul, api.unit, api.cross

    def axes(axis):
        n = unit(axis)
        u = unit(cross((0, 0, 1) if abs(n[2]) < .9 else (0, 1, 0), n))
        return n, u, cross(n, u)

    def point(c, u, v, x, y):
        return add(c, add(mul(u, x), mul(v, y)))

    def torus(part, mat, center, axis, radius, tube=.3, sectors=48, sides=8):
        n, u, v = axes(axis)
        def at(a, b):
            radial = add(mul(u, math.cos(a)), mul(v, math.sin(a)))
            normal = add(mul(radial, math.cos(b)), mul(n, math.sin(b)))
            return add(center, add(mul(radial, radius), mul(normal, tube))), normal
        for i in range(sectors):
            for j in range(sides):
                aa, ab = i / sectors * TAU, (i + 1) / sectors * TAU
                ba, bb = j / sides * TAU, (j + 1) / sides * TAU
                values = [at(aa, ba), at(ab, ba), at(ab, bb), at(aa, bb)]
                quad(part, mat, *[q[0] for q in values],
                     uv=[(i/sectors,j/sides),((i+1)/sectors,j/sides),
                         ((i+1)/sectors,(j+1)/sides),(i/sectors,(j+1)/sides)],
                     normals=[q[1] for q in values])

    def bevel_box(part, mat, center, size, bevel=.45, yaw=0):
        x, y, z = center
        hx, hy, hz = [q * .5 for q in size]
        bevel = min(bevel, hx * .45, hy * .45, hz * .45)
        co, si = math.cos(yaw), math.sin(yaw)
        def ring(inset, zz):
            a, b = hx - inset, hy - inset
            cut = max(bevel - inset, .05)
            xy = [(-a+cut,-b),(a-cut,-b),(a,-b+cut),(a,b-cut),
                  (a-cut,b),(-a+cut,b),(-a,b-cut),(-a,-b+cut)]
            return [(x+px*co-py*si,y+px*si+py*co,z+zz) for px,py in xy]
        layers = [ring(bevel,-hz),ring(0,-hz+bevel),
                  ring(0,hz-bevel),ring(bevel,hz)]
        for a, b in zip(layers,layers[1:]):
            for i in range(8):
                j=(i+1)%8
                quad(part,mat,a[i],a[j],b[j],b[i])
        for i in range(8):
            j=(i+1)%8
            tri(part,mat,(x,y,z-hz),layers[0][j],layers[0][i])
            tri(part,mat,(x,y,z+hz),layers[-1][i],layers[-1][j])

    def bolt(part, pos, radius=.8, height=.65, axis=(0,0,1), mat='darksteel'):
        n, _, _ = axes(axis)
        cyl(part,mat,pos,add(pos,mul(n,height)),radius,6)

    def handle(part, center, length=8, height=2, yaw=0, radius=.5):
        # A continuous bent rod, with welded feet, rather than three big blocks.
        x,y,z=center;co,si=math.cos(yaw),math.sin(yaw)
        path=[]
        for i in range(7):
            a=math.pi-i/6*math.pi*.5
            path.append((-length*.5+height+height*math.cos(a),height*math.sin(a)))
        path.append((length*.5-height,height))
        for i in range(1,7):
            a=math.pi*.5-i/6*math.pi*.5
            path.append((length*.5-height+height*math.cos(a),height*math.sin(a)))
        path=[(x+px*co,y+px*si,z+pz) for px,pz in path]
        for a,b in zip(path,path[1:]):cyl(part,'darksteel',a,b,radius,8)
        for sign in (-1,1):
            px=x+sign*length*.5*co;py=y+sign*length*.5*si
            bevel_box(part,'armor',(px,py,z-.15),(2.1,2.1,.6),.15)

    def line(part,mat,points,radius=.4,sectors=10):
        for a,b in zip(points,points[1:]):cyl(part,mat,a,b,radius,sectors)

    # The screenshots show a very broad cast turret, not an egg perched on a
    # narrow ring. These asymmetric plan control points define its cheeks,
    # broad shoulders and pinched aft bustle independently of roof elevation.
    contour=[(59,0),(55,24),(39,49),(13,66),(-17,70),(-47,63),
             (-70,43),(-79,14),(-78,-17),(-65,-45),(-41,-64),
             (-12,-69),(18,-63),(42,-44),(56,-20)]
    def plan(t):
        t=(t%1)*len(contour);i=int(t);f=t-i
        a,b,c,d=[contour[k%len(contour)] for k in (i-1,i,i+1,i+2)]
        return tuple(.5*((2*b[j])+(-a[j]+c[j])*f+
            (2*a[j]-5*b[j]+4*c[j]-d[j])*f*f+
            (-a[j]+3*b[j]-3*c[j]+d[j])*f*f*f) for j in (0,1))
    layers=[(64.8,.87,.87,0),(66,.93,.93,0),(69.5,1,1,0),
            (75.5,1,1,-.4),(82.5,.96,.975,-1.5),
            (89.5,.88,.925,-3.5),(94.2,.78,.845,-5.5),
            (97.0,.67,.76,-7),(98.0,.635,.725,-7.2)]
    def shell_point(k,t):
        z,sx,sy,dx=layers[k];x,y=plan(t)
        # Small slow casting irregularities are geometric, without fake rings.
        bulge=.18*math.sin(t*TAU*7+.4)*math.sin(k/(len(layers)-1)*math.pi)
        return (x*sx+dx+bulge,y*sy+bulge*.6,z)
    def shell_normal(k,t):
        around=sub(shell_point(k,t+.0002),shell_point(k,t-.0002))
        up=sub(shell_point(min(k+1,len(layers)-1),t),shell_point(max(k-1,0),t))
        return unit(cross(around,up))
    sectors=120
    for k in range(len(layers)-1):
        for i in range(sectors):
            a,b=i/sectors,(i+1)/sectors
            coords=[shell_point(k,a),shell_point(k,b),shell_point(k+1,b),shell_point(k+1,a)]
            normals=[shell_normal(k,a),shell_normal(k,b),shell_normal(k+1,b),shell_normal(k+1,a)]
            quad('turret','armor',*coords,uv=[(p[0]/55,p[1]/55) for p in coords],normals=normals)
    for k,up in ((0,False),(len(layers)-1,True)):
        for i in range(sectors):
            a,b=shell_point(k,i/sectors),shell_point(k,(i+1)/sectors)
            tri('turret','armor',(-15,0,layers[k][0]),*((a,b) if up else (b,a)))
    cyl('turret','darksteel',(-8,0,63.8),(-8,0,65.1),52.2,96)
    torus('turret','darksteel',(-8,0,65.0),(0,0,1),52.8,.33,96,6)
    # A shallow casting parting seam follows the broad lower shoulder.
    line('turret','armor',[shell_point(2,i/120) for i in range(121)],.18,6)

    # The asymmetric TPD sight/rangefinder enclosure is the identifying block
    # on the left cheek. Three recessed covers, rather than fictitious circular
    # side windows, follow its long angled face.
    bevel_box('turret','armor',(14,61.2,86.8),(58,21,21),2.5,yaw=.06)
    bevel_box('turret','armor',(13.6,72.0,86.4),(54,1.2,18.8),.6,yaw=.06)
    for x in (-5,13,31):
        cy=72.7+(x-13)*.06
        bevel_box('turret','armor',(x,cy,86.5),(15.9,2.1,18.1),1.1,yaw=.06)
        bevel_box('turret','darksteel',(x,cy+1.1,86.5),(14.6,.35,16.4),.65,yaw=.06)
        bevel_box('turret','armor',(x,cy+1.36,86.7),(14.1,.46,16.0),.65,yaw=.06)
        # Pressed cover perimeter and real hinge/latch, visible in close view.
        for xx in (x-5.4,x+5.4):
            bolt('turret',(xx,cy+1.8,80),.38,.3,(0,1,0))
        cyl('turret','darksteel',(x-4,cy+1.8,95.7),(x+4,cy+1.8,95.7),.55,10)
    bevel_box('turret','armor',(39,39,99.4),(23,14,2.4),.8,yaw=-.2)
    for x,y in ((35,34),(46,37),(28,43)):
        bolt('turret',(x,y,100.6),.6,.55)

    # Commander cupola on the right: raised fixed periscope band and a low
    # domed hatch. The second hatch sits lower on the left rear roof.
    x,y,z=-25,-28,98
    cyl('turret','darksteel',(x,y,z-.2),(x,y,z+.65),19.5,72)
    cyl('turret','armor',(x,y,z+.5),(x,y,z+5.0),18.5,72,r2=18)
    torus('turret','darksteel',(x,y,z+4.8),(0,0,1),17.8,.30,64,6)
    api.dome('turret','armor',(x,y,z+5),(17.5,17.5,3.6),64,8)
    for deg in (-50,-10,30,70,110,150):
        angle=math.radians(deg);co,si=math.cos(angle),math.sin(angle)
        px=x+16.8*co;py=y+16.8*si
        bevel_box('turret','armor',(px,py,z+4),(6.3,4.5,4.2),.5,yaw=angle)
        bevel_box('turret','glass',(px+2.6*co,py+2.6*si,z+4.7),(1.0,3.6,2.0),.15,yaw=angle)
    handle('turret',(x+2,y,z+8.6),8,1.4,yaw=.3,radius=.4)
    for yy in (y-6,y+6):
        bevel_box('turret','armor',(x-16,yy,z+6),(4.7,3.0,3.0),.5)
        cyl('turret','darksteel',(x-17,yy-2,z+6),(x-17,yy+2,z+6),.85,12)
    # Commander observation head, a small angled optical barrel and support.
    bevel_box('turret','armor',(x+11,y+3,z+10),(10,7,5),1.0,yaw=-.15)
    cyl('turret','armor',(x+15,y+3,z+10),(x+23,y+3,z+12),3.9,28,r2=3.4)
    cyl('turret','glass',(x+23.1,y+3,z+12),(x+23.3,y+3,z+12),2.7,28)
    lx,ly,lz=-35,24,98.0
    cyl('turret','darksteel',(lx,ly,lz),(lx,ly,lz+1),16.6,64)
    cyl('turret','armor',(lx,ly,lz+.9),(lx,ly,lz+2.7),15.8,64,r2=15.4)
    torus('turret','armor',(lx,ly,lz+2.8),(0,0,1),14.7,.35,64,6)
    handle('turret',(lx+1,ly,lz+3),8,1.4,yaw=-.35,radius=.42)
    for yy in (ly-5,ly+5):
        bevel_box('turret','armor',(lx-14,yy,lz+2.1),(4.5,3,3),.45)
        cyl('turret','darksteel',(lx-15,yy-2,lz+2.4),(lx-15,yy+2,lz+2.4),.75,10)
    # Periscope and sight assembly ahead of the left hatch.
    bevel_box('turret','armor',(7,24,100.5),(16,12,6.5),1.2,yaw=.08)
    bevel_box('turret','darksteel',(15.2,24,100.7),(1.1,9.8,4.8),.35)
    bevel_box('turret','glass',(15.85,24,100.8),(.25,8.0,3.3),.15)
    bevel_box('turret','armor',(17,-23,99.5),(12,8,3.6),.7,yaw=.1)
    # Bolted maintenance disc and roof seams following actual roof features.
    cyl('turret','darksteel',(-12,5,98),(-12,5,98.3),6.8,32)
    cyl('turret','armor',(-12,5,98.3),(-12,5,98.8),6.2,32)
    for deg in range(0,360,60):
        a=math.radians(deg);bolt('turret',(-12+5.2*math.cos(a),5+5.2*math.sin(a),98.8),.42,.4)
    line('turret','armor',[(4,-19,98.15),(17,-13,98.15),(23,-3,98.15)],.22,6)
    line('turret','armor',[(-44,5,98.15),(-49,4,98.15),(-53,-3,98.15)],.23,6)

    # Luna IR projector, set forward and to the left of the mantlet. The lip,
    # glass, tilted yoke and cable remain separate modeled features.
    bevel_box('turret','armor',(40,32,77.5),(15,17,5.5),1.0)
    for yy in (24,40):bevel_box('turret','darksteel',(44,yy,83.5),(3.2,2,14),.4)
    cyl('turret','armor',(40,32,87.0),(54,32,87.0),10.2,64,r2=9.7)
    cyl('turret','darksteel',(53.8,32,87),(55.2,32,87),10.1,64)
    cyl('turret','glass',(55.25,32,87),(55.4,32,87),8.85,64)
    torus('turret','armor',(55.55,32,87),(1,0,0),9.4,.38,64,6)
    # The two fine wires are a retaining guard, not the thick invented cage.
    for angle in (0,math.pi*.5):
        yy,zz=8.8*math.cos(angle),8.8*math.sin(angle)
        cyl('turret','darksteel',(55.8,32-yy,87-zz),(55.8,32+yy,87+zz),.16,6)
    for angle in range(0,360,60):
        aa=math.radians(angle)
        bolt('turret',(55.9,32+9.4*math.cos(aa),87+9.4*math.sin(aa)),.4,.35,(1,0,0))
    line('turret','darksteel',[(42,43,81),(32,46,82),(17,47,91),(10,42,96)],.5,10)

    # Thin stowage boxes follow the right rear cast shoulder. They do not form
    # the oversized rectangular bustle of v0.4.
    for x,y,sz,yaw in [(-35,-65,13,-.20),(-59,-53,13,-.55)]:
        bevel_box('turret','armor',(x,y,82),(22,8,sz),1.0,yaw=yaw)
        bevel_box('turret','armor',(x,y,89),(23,9,1.5),.45,yaw=yaw)
        bevel_box('turret','darksteel',(x,y-4.4,83),(4,1,4),.25,yaw=yaw)

    # OPVT snorkel tube across the turret rear is conspicuous in the reference.
    # Main cylindrical section, narrow curved neck, rolled lip and strap bands.
    cx,cz=-86,87.5
    cyl('turret','armor',(cx,-61,cz),(cx,51,cz),5.6,64)
    cyl('turret','armor',(cx,-64,cz),(cx,-61,cz),4.7,64,r2=5.6)
    torus('turret','darksteel',(cx,-63.7,cz),(0,1,0),4.7,.32,48,6)
    for yy in (-56,-24,10,43):
        torus('turret','darksteel',(cx,yy,cz),(0,1,0),5.77,.36,48,6)
        bevel_box('turret','armor',(-79,yy,83.5),(10,4,4),.5)
        cyl('turret','darksteel',(-81,yy,79.8),(-86,yy,82.1),.75,10)
    path=[(cx,51,cz),(cx,57,cz),(cx,62,cz+.5),(cx+1,66,cz+2.2),
          (cx+3.5,69,cz+4.4),(cx+7.5,70,cz+5.2),(cx+13,70,cz+5.4)]
    def swept_pipe(points,radius,sectors=40):
        frames=[]
        for k,p in enumerate(points):
            tangent=sub(points[min(k+1,len(points)-1)],points[max(k-1,0)])
            n,u,v=axes(tangent);frames.append((p,n,u,v))
        for k in range(len(frames)-1):
            for i in range(sectors):
                a,b=i/sectors*TAU,(i+1)/sectors*TAU
                values=[];normals=[]
                for j,angle in ((k,a),(k,b),(k+1,b),(k+1,a)):
                    p,n,u,v=frames[j];normal=add(mul(u,math.cos(angle)),mul(v,math.sin(angle)))
                    values.append(add(p,mul(normal,radius)));normals.append(normal)
                quad('turret','armor',*values,normals=normals)
        p,n,u,v=frames[-1]
        torus('turret','armor',p,n,radius,.38,48,6)
        cyl('turret','rubber',add(p,mul(n,-1.0)),add(p,mul(n,-.85)),radius-.45,48)
    swept_pipe(path,4.6)

    # Worn folded canvas behind the turret. A closed organic cross section with
    # sewn edges and narrow straps makes the roll part of the actual mesh.
    def canvas_roll(center,length,radius):
        xc,yc,zc=center;ns=56;nr=22
        def at(j,i):
            t=j/nr;angle=i/ns*TAU
            r=radius*(.91+.06*math.sin(t*TAU*3)+.045*math.sin(angle*5+t*8))
            return (xc+r*math.cos(angle),yc+(t-.5)*length,zc+r*.72*math.sin(angle))
        for j in range(nr):
            for i in range(ns):quad('turret','cloth',at(j,i),at(j+1,i),at(j+1,i+1),at(j,i+1))
        for j,sgn in ((0,-1),(nr,1)):
            for i in range(ns):
                a,b=at(j,i),at(j,i+1);tri('turret','cloth',(xc,yc+sgn*length*.5,zc),*((a,b) if sgn<0 else (b,a)))
        for yy in (yc-length*.30,yc+length*.30):
            torus('turret','darksteel',(xc,yy,zc),(0,1,0),radius*.98,.38,48,6)
    canvas_roll((-72,0,79),92,8.5)
    # Lift eyes, rail and antenna follow the visible asymmetric roof fittings.
    for xx,yy,zz in ((30,-48,87),(34,48,87),(-55,-39,89),(-60,36,88)):
        bevel_box('turret','armor',(xx,yy,zz),(5.7,4,2),.55)
        torus('turret','armor',(xx,yy,zz+2.6),(0,1,0),2.0,.6,28,6)
    cyl('turret','armor',(-46,-2,98),(-46,-2,105),2.6,32,r2=1.8)
    torus('turret','darksteel',(-46,-2,104.5),(0,0,1),2.1,.28,32,6)
    cyl('turret','darksteel',(-46,-2,105),(-46.5,-1.8,161),.34,12,r2=.12)

    # Cloth mantlet cover: broad trapezoidal drape with irregular longitudinal
    # folds, rather than the uniformly corrugated vacuum-hose shape of v0.4.
    boot=[];nr=24;ns=72
    for j in range(nr+1):
        t=j/nr;boot.append((45+31*t,19*(1-t)+6.0*t,13.7*(1-t)+5.8*t))
    def cloth_point(k,a):
        x,ry,rz=boot[k];t=k/nr
        fold=(.9*math.sin(a*5+t*2.4)+.55*math.cos(a*8-t*5))*(math.sin(math.pi*t)**.7)
        sag=-1.1*math.sin(math.pi*t)*(1+math.sin(a))*.5
        return (x,(ry+fold)*math.cos(a),82+(rz+fold*.6)*math.sin(a)+sag)
    for j in range(nr):
        for i in range(ns):
            aa,bb=i/ns*TAU,(i+1)/ns*TAU
            vals=[cloth_point(j,aa),cloth_point(j,bb),cloth_point(j+1,bb),cloth_point(j+1,aa)]
            # Smoothed cloth normals derived from the actual drape surface.
            normals=[]
            for k,a in ((j,aa),(j,bb),(j+1,bb),(j+1,aa)):
                around=sub(cloth_point(k,a+.001),cloth_point(k,a-.001))
                along=sub(cloth_point(min(k+1,nr),a),cloth_point(max(k-1,0),a))
                normals.append(unit(cross(around,along)))
            quad('gun','cloth',*vals,normals=normals)
    for k in (0,nr):
        line('gun','darksteel',[cloth_point(k,i/ns*TAU) for i in range(ns+1)],.22,6)

    # The screenshot's extractor sits in the forward half of the exposed tube.
    # A slender lathed 2A26 with the same canonical bore/muzzle position.
    sections=[(73,5.95),(77,5.7),(79,4.7),(85,4.55),(185,4.15),
              (189,5.8),(192,6.1),(231,6.1),(235,5.7),(238,4.05),
              (302,3.55),(311.5,3.5),(313,3.5)]
    n=72
    for k in range(len(sections)-1):
        x0,r0=sections[k];x1,r1=sections[k+1]
        slope=(r0-r1)/(x1-x0)
        for i in range(n):
            aa,bb=i/n*TAU,(i+1)/n*TAU
            values=[(x0,r0*math.cos(aa),82+r0*math.sin(aa)),
                    (x0,r0*math.cos(bb),82+r0*math.sin(bb)),
                    (x1,r1*math.cos(bb),82+r1*math.sin(bb)),
                    (x1,r1*math.cos(aa),82+r1*math.sin(aa))]
            normals=[unit((slope,math.cos(a),math.sin(a))) for a in (aa,bb,bb,aa)]
            quad('gun','armor',*values,
                 uv=[(x0/40,i/n),(x0/40,(i+1)/n),(x1/40,(i+1)/n),(x1/40,i/n)],normals=normals)
    for xx,rr in ((79,4.75),(190,5.95),(234,5.85),(310.5,3.58)):
        torus('gun','armor',(xx,0,82),(1,0,0),rr,.16,64,6)
    # Extractor seam and small retaining screws are modeled, not painted.
    for xx in (192,231):
        for deg in (45,135,225,315):
            a=math.radians(deg)
            p=(xx,6.12*math.cos(a),82+6.12*math.sin(a))
            bolt('gun',p,.34,.3,(0,math.cos(a),math.sin(a)),mat='armor')
    for i in range(n):
        aa,bb=i/n*TAU,(i+1)/n*TAU
        outer=[(313,3.5*math.cos(a),82+3.5*math.sin(a)) for a in (aa,bb)]
        inner=[(313,2.85*math.cos(a),82+2.85*math.sin(a)) for a in (aa,bb)]
        quad('gun','darksteel',outer[0],outer[1],inner[1],inner[0])
        a,b=inner
        quad('gun','darksteel',b,(299,b[1],b[2]),(299,a[1],a[2]),a)
        tri('gun','rubber',(298.9,0,82),(298.9,a[1],a[2]),(298.9,b[1],b[2]))
    bevel_box('gun','darksteel',(53,-9,79),(10,4,5),.7)
    cyl('gun','darksteel',(54,-9,79),(59,-9,79),1.55,24,caps=False)
    torus('gun','darksteel',(59,-9,79),(1,0,0),1.55,.24,24,6)
