# T-64A 1971: visual reference rebuild 0.5

Five user-supplied views define the visual target: top, rear, left, front and
right. They are used for observation, not as a source of extracted meshes or
projected game textures. The asset is newly authored with AI-assisted tools.

The explicit exception to the reference is removal of the hinged side armour
screens and their projecting mounts. Fender shelves and upper fuel/tool bins
remain. Only the tank belongs in Blender/GLB exports; all studio objects are
added after export.

Key landmarks used in the rebuild:

- Broad cast turret occupying around three quarters of the full vehicle width,
  with a low nearly flat crown, defined cheeks and asymmetric optical fittings.
- A large rectangular cheek rangefinder casing, two different roof hatches,
  gun mantlet canvas and a transverse rear OPVT tube instead of a broad rear box.
- Shallow pressed fender bins, V-shaped glacis rails, central driver position,
  tow equipment, separate fine engine grilles and a wooden rear recovery beam.
- Six small steel road wheels per side, thin resilient rims, dished wheel faces
  and characteristic circular pressings. Raised rear sprockets/front idlers
  lead into long sloping track sections, with a nearly straight bottom run.

The runtime keeps the existing turret/gun pivots and analytically aligned
muzzle socket. This retains the accepted aiming, shell selection and loader
behaviour. Source units use +X forward, +Y left and +Z up. Apparent proportions
from screenshots are an art reference, not engineering measurements.

Offline checks cover normals, geometry export, Lua payload sizes, materials,
component pivots and the existing runtime contracts. In-game lighting,
performance, collisions and the assembled vehicle still need a GMod test.

The complete gun/turret motion sweep reaches X=-329.023..313.023,
Y=-321.023..321.023, Z=2.96..161.002. Render bounds include these positions with
a margin, and the geometry tests check all analytical extrema rather than only
the neutral pose. Compatible network shards share GPU meshes; steel track
hardware retains its own static material while the belt surface scrolls.
