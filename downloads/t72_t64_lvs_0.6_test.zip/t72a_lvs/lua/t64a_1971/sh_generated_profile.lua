-- Original generated T-64A1971 game-art geometry; not an engineering survey.
local left,right={},{}
left[1]=Vector(100.8,77,20.5);right[1]=Vector(100.8,-77,20.5)
left[2]=Vector(63,77,20.5);right[2]=Vector(63,-77,20.5)
left[3]=Vector(25.2,77,20.5);right[3]=Vector(25.2,-77,20.5)
left[4]=Vector(-12.6,77,20.5);right[4]=Vector(-12.6,-77,20.5)
left[5]=Vector(-50.4,77,20.5);right[5]=Vector(-50.4,-77,20.5)
left[6]=Vector(-88.2,77,20.5);right[6]=Vector(-88.2,-77,20.5)
return {
 Ready=true,Model="models/hunter/blocks/cube025x025x025.mdl",VisualYaw=0,
 HullMins=Vector(-149,-70,29),HullMaxs=Vector(154,70,109),
 -- Include the complete yaw/pitch sweep of the long barrel, not just neutral pose.
 RenderMins=Vector(-336,-328,-4),RenderMaxs=Vector(320,328,168),
 DriverSeat={Pos=Vector(63,-15,48.8571),Ang=Angle(0,-90,0)},
 Engine={Pos=Vector(-85.5,0,52.6286),Ang=Angle(0,0,0)},
 Wheels={Left=left,Right=right,DriveIndex=3,Model="models/props_vehicles/tire001c_car.mdl",Radius=16,Width=14},
 Suspension={Height=7,MaxTravel=7,ControlArmLength=150,SpringConstant=42000,SpringDamping=1800,SpringRelativeDamping=2000},
 Turret={AimRate=16,PitchMin=-14,PitchMax=6},TrackUVUnits=9.2,
 Rig={TurretPivot=Vector(-7.2,0,74),GunPivot=Vector(41.56,0,89.64),CannonMuzzle=Vector(288.12,0,89.64),MGMuzzle=Vector(54.44,-8.28,86.88),Sight=Vector(55.36,-16.56,108.96)}
}
