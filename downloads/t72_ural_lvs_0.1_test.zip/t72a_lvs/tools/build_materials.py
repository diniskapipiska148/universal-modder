#!/usr/bin/env python3
"""Build original Source materials from the project's generated olive tile.

This writes documented VTF 7.2 RGBA8888 images, with mip levels in smallest-
to-largest order. No model texture, normal map or War Thunder graphic is used.
Usage: python tools/build_materials.py /path/to/olive_generated.png [addon_root]
Requires Pillow. Generated mipmaps intentionally use ordinary box filtering.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import struct

from PIL import Image


def encode_vtf(image: Image.Image) -> bytes:
    """Encode an opaque or alpha RGBA image without DXT compression.

    Source's RGBA8888 byte channels are R,G,B,A. Pixels retain ordinary raster
    top-to-bottom row order. No UV flip is baked into the file.
    """
    image = image.convert("RGBA")
    width, height = image.size
    if width < 1 or height < 1 or width & (width - 1) or height & (height - 1):
        raise ValueError("VTF dimensions must be positive powers of two")
    levels = [image]
    while levels[-1].size != (1, 1):
        w, h = levels[-1].size
        levels.append(levels[-1].resize((max(w // 2, 1), max(h // 2, 1)), Image.Resampling.BOX))
    header = bytearray(80)
    header[0:4] = b"VTF\0"
    struct.pack_into("<IIIHHIHH", header, 4, 7, 2, 80, width, height, 0x12, 1, 0)
    # Reflectivity is informational; opaque base color average, in [0,1].
    average = image.convert("RGB").resize((1, 1), Image.Resampling.BOX).getpixel((0, 0))
    struct.pack_into("<3f", header, 32, *(value / 255 for value in average))
    struct.pack_into("<fI", header, 48, 1.0, 0)  # bump scale, IMAGE_FORMAT_RGBA8888
    header[56] = len(levels)
    struct.pack_into("<I", header, 57, 0xFFFFFFFF)  # no low-res thumbnail
    header[61:63] = b"\0\0"
    struct.pack_into("<H", header, 63, 1)  # depth
    return bytes(header) + b"".join(level.tobytes() for level in reversed(levels))


def vmt(texture: str, extra: str = "") -> str:
    return ('"VertexLitGeneric"\n{\n'
            f'    "$basetexture" "t72a_ural/{texture}"\n'
            '    "$model" "1"\n'
            + extra + '}\n')


def build(source: Path, addon: Path) -> list[Path]:
    destination = addon / "materials" / "t72a_ural"
    destination.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as image:
        olive = image.convert("RGB").resize((1024, 1024), Image.Resampling.LANCZOS)
        # A neutral surface derivative for rubber/steel; this is a material
        # variant of the original tile, not a claimed measured PBR map.
        neutral = image.convert("L").resize((256, 256), Image.Resampling.LANCZOS)
        neutral = neutral.point(lambda value: 32 + value * 0.25).convert("RGB")
    images = {
        "olive": olive,
        "neutral": neutral,
        "glass": Image.new("RGBA", (8, 8), (45, 63, 66, 255)),
        "lamp": Image.new("RGBA", (8, 8), (146, 141, 110, 255)),
    }
    result = []
    for name, image in images.items():
        path = destination / (name + ".vtf")
        path.write_bytes(encode_vtf(image))
        result.append(path)
    specifications = {
        "olive": vmt("olive", '    "$phong" "1"\n    "$phongexponent" "12"\n    "$phongboost" "0.15"\n'),
        "darksteel": vmt("neutral", '    "$color2" "[0.6 0.62 0.64]"\n    "$phong" "1"\n    "$phongexponent" "24"\n    "$phongboost" "0.25"\n'),
        "tracks": vmt("neutral", '    "$color2" "[0.52 0.53 0.54]"\n    "$phong" "1"\n    "$phongexponent" "20"\n    "$phongboost" "0.18"\n'),
        "rubber": vmt("neutral", '    "$color2" "[0.28 0.28 0.28]"\n'),
        "glass": vmt("glass", '    "$envmap" "env_cubemap"\n    "$envmaptint" "[0.16 0.16 0.16]"\n'),
        "lamp": vmt("lamp", '    "$phong" "1"\n    "$phongexponent" "40"\n    "$phongboost" "0.4"\n'),
        "lamp_on": vmt("lamp", '    "$selfillum" "1"\n'),
        "interior": vmt("neutral", '    "$color2" "[0.36 0.36 0.34]"\n'),
    }
    for name, content in specifications.items():
        path = destination / (name + ".vmt")
        path.write_text(content, encoding="utf-8")
        result.append(path)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("addon", type=Path, nargs="?", default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    for path in build(args.source, args.addon):
        print(path)
