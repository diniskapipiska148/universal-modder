# Original material set

The olive base-color tile was generated with OpenAI image generation for this
project, then converted to Source's VTF image format. No texture from the model
addon, War Thunder, or another game is included. The original generated PNG is included at
`assets/source/olive_generated.png` for reproducibility.

`tools/build_materials.py SOURCE.png` reproduces all VTF/VMT outputs. It requires
Pillow, resizes the original paint tile to 1024x1024, creates a neutral grayscale
surface derivative, and writes a full uncompressed RGBA8888 mip chain. This is a
simple original material set, not a claimed scan, detailed UV-painted atlas,
normal-map set, or historically exact camouflage.

The 43 model slots (including alternative skins) are resolved by basename in
`lua/t72a/sh_materials.lua`. Armor is olive, wheels/black parts dark rubber,
tracks and mesh dark steel, interior dark gray, lenses opaque blue-gray, and
lamps pale glass. The `props` slot is shared by equipment and the rear log; both
use olive paint in this first set because the source atlas was not supplied.
No normal map is synthesized or asserted. Glass is intentionally opaque to avoid
transparency sorting failures with the vehicle's custom visual draw path.

These replacement materials are applied only to this vehicle's client-side
visual entity with `SetSubMaterial`; original Workshop files are not overwritten.
The cloud validates binary VTF structure and channel/mipmap layout. Actual Source
rendering, lighting and texture filtering still require an in-game check.
