-- Original gameplay code. All firing, ammo and damage are server authoritative.
ENT.T72ReloadDuration = 7.1
ENT.T72ShellVelocity = 48000 -- Source units/s; intentionally an arcade balance.

function ENT:GetT72Muzzle(machineGun)
    local name = machineGun and self.T72Profile.MGAttachment or self.T72Profile.CannonAttachment
    if not name then return end
    local id = self:LookupAttachment(name)
    if not id or id <= 0 then return end
    return self:GetAttachment(id)
end

function ENT:InitWeapons()
    local cannon = {}
    cannon.Ammo = 39
    cannon.Delay = self.T72ReloadDuration
    cannon.HeatRateUp = 0
    cannon.HeatRateDown = 1
    cannon.UseableByAI = false
    cannon.Icon = Material("lvs/weapons/bullet.png")
    cannon.Attack = function(vehicle)
        if vehicle:GetHP() <= 0 or vehicle:GetAmmo() <= 0 or not vehicle:GetTurretEnabled()
            or CurTime() < vehicle:GetT72ReloadEnd() then return true end
        local muzzle = vehicle:GetT72Muzzle(false)
        if not muzzle then return true end
        vehicle:LVSFireBullet({
            Src = muzzle.Pos, Dir = muzzle.Ang:Forward(), Spread = Vector(0, 0, 0),
            EnableBallistics = true, Velocity = vehicle.T72ShellVelocity,
            Force = 500, HullSize = 2, Damage = 650,
            SplashDamage = 600, SplashDamageRadius = 240,
            SplashDamageEffect = "lvs_bullet_impact_explosive",
            SplashDamageType = DMG_BLAST, TracerName = "lvs_tracer_cannon",
            Attacker = vehicle:GetDriver()
        })
        vehicle:TakeAmmo(1)
        vehicle:SetT72ReloadEnd(CurTime() + vehicle.T72ReloadDuration)
        vehicle:EmitSound("weapons/explode3.wav", 100, 85, 1)
        local effect = EffectData()
        effect:SetOrigin(muzzle.Pos)
        effect:SetAngles(muzzle.Ang)
        effect:SetScale(4)
        util.Effect("MuzzleFlash", effect, true, true)
        local physics = vehicle:GetPhysicsObject()
        if IsValid(physics) then
            physics:ApplyForceOffset(-muzzle.Ang:Forward() * 180000, muzzle.Pos)
        end
    end
    cannon.OnSelect = function(vehicle)
        vehicle:TurretUpdateBallistics(vehicle.T72ShellVelocity, vehicle.T72Profile.CannonAttachment)
    end
    self:AddWeapon(cannon)

    local mg = {}
    mg.Ammo = 2000
    mg.Delay = 0.1
    mg.HeatRateUp = 0
    mg.HeatRateDown = 1
    mg.UseableByAI = false
    mg.Icon = Material("lvs/weapons/bullet.png")
    mg.Attack = function(vehicle)
        if vehicle:GetHP() <= 0 or vehicle:GetAmmo() <= 0 or not vehicle:GetTurretEnabled() then return true end
        local muzzle = vehicle:GetT72Muzzle(true)
        if not muzzle then return true end
        local driver = vehicle:GetDriver()
        vehicle:LVSFireBullet({
            Attacker = IsValid(driver) and driver or vehicle,
            Src = muzzle.Pos, Dir = muzzle.Ang:Forward(),
            Spread = Vector(0.003, 0.003, 0), Num = 1,
            TracerName = "lvs_tracer_yellow_small", Force = 8, Damage = 18,
            EnableBallistics = true, Velocity = 40000, HullSize = 0
        })
        vehicle:TakeAmmo(1)
        vehicle:EmitSound("weapons/ar2/fire1.wav", 85, 120, 0.75)
    end
    mg.OnSelect = function(vehicle)
        vehicle:TurretUpdateBallistics(40000, vehicle.T72Profile.MGAttachment)
    end
    self:AddWeapon(mg)
end
