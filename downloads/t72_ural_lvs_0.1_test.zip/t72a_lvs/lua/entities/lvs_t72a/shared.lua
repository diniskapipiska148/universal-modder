ENT.Base = "lvs_tank_wheeldrive"
ENT.Type = "anim"
ENT.PrintName = "Т-72 Урал"
ENT.Author = "Local T-72A project"
ENT.Information = "LVS tank with a single hull-health pool"
ENT.Category = "[LVS] - Т-72 Урал"
ENT.VehicleCategory = "Tanks"
ENT.VehicleSubCategory = "Main battle tank"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.lvsShowInSpawner = true
ENT.T72A = true
ENT.T72WeaponNames = { [1] = "125 мм", [2] = "ПКТ 7,62 мм" }

ENT.T72Profile = include("t72a/sh_profile.lua") or {}
local profile = ENT.T72Profile
local turret = profile.Turret or {}

-- Model paths and rig names must come from the selected Workshop addon.
-- A deliberately absent MDL is caught by Initialize/SpawnFunction below.
ENT.MDL = profile.Model or ""
ENT.MaxHealth = 2500
ENT.MaxHealthEngine = 2500
ENT.MaxShield = 0
ENT.SpawnNormalOffset = 30
ENT.PhysicsMass = 4000
ENT.PhysicsWeightScale = 1
ENT.PhysicsInertia = Vector(12000, 12000, 3500)
ENT.PhysicsDampingSpeed = 1300
ENT.MaxVelocity = 650
ENT.MaxVelocityReverse = 50
ENT.EngineTorque = 400
ENT.EngineCurve = 0.25
ENT.TransGears = 7
ENT.TransGearsReverse = 1
ENT.TransMinGearHoldTime = 0.4
ENT.TransShiftSpeed = 0.2
ENT.SteerSpeed = 1.5
ENT.SteerReturnSpeed = 3
ENT.MouseSteerAngle = 45
ENT.AllowSuperCharger = false
ENT.AllowTurbo = false
ENT.PivotSteerEnable = true
ENT.PivotSteerByBrake = true
ENT.PivotSteerWheelRPM = 40

-- Combat damage always subtracts hull HP; no penetration/module simulation.
ENT.DSArmorIgnoreDamageType = 0
ENT.DSArmorIgnoreForce = 0
ENT.DSArmorDamageReduction = 1

ENT.EngineSounds = {{sound = "vehicles/apc/apc_idle1.wav", Volume = 0.8,
    Pitch = 75, PitchMul = 35, SoundLevel = 85, SoundType = LVS and LVS.SOUNDTYPE_NONE or 0}}
ENT.ExhaustPositions = profile.ExhaustPositions or {}

if file.Exists("entities/lvs_tank_wheeldrive/modules/sh_turret.lua", "LUA") then
    include("entities/lvs_tank_wheeldrive/modules/sh_turret.lua")
    include("entities/lvs_tank_wheeldrive/modules/sh_turret_ballistics.lua")
end

ENT.TurretAimRate = turret.AimRate or 16
ENT.TurretPitchPoseParameterName = turret.PitchPose or ""
ENT.TurretYawPoseParameterName = turret.YawPose or ""
ENT.TurretPitchMul = turret.PitchMul or 1
ENT.TurretYawMul = turret.YawMul or 1
ENT.TurretPitchMin = turret.PitchMin or -14
ENT.TurretPitchMax = turret.PitchMax or 6
ENT.TurretBallisticsMuzzleAttachment = profile.CannonAttachment or ""
ENT.TurretBallisticsViewAttachment = profile.ViewAttachment or profile.CannonAttachment or ""
ENT.TurretBallisticsProjectileVelocity = 48000

function ENT:OnSetupDataTables()
    self:AddDT("Float", "T72ReloadEnd")
    self:AddDT("Float", "T72Range")
    if SERVER then
        self:SetT72ReloadEnd(0)
        self:SetT72Range(-1)
    end
end

include("sh_weapons.lua")
include("t72a/sh_bone_turret.lua")
