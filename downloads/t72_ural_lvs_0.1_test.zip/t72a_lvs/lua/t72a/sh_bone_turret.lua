-- Canonical +X-forward rig; no reliance on cached server-side model bones.
local function pitchRotate(v, degrees)
    local a = math.rad(degrees)
    local c, s = math.cos(a), math.sin(a)
    return Vector(v.x*c + v.z*s, v.y, -v.x*s + v.z*c)
end
local function yawRotate(v, degrees)
    local a = math.rad(degrees)
    local c, s = math.cos(a), math.sin(a)
    return Vector(v.x*c - v.y*s, v.x*s + v.y*c, v.z)
end
function ENT:T72RigPoint(point, pitch, yaw, gunLinked)
    local rig = self.T72Profile.Rig
    local result = point
    if gunLinked then result = rig.GunPivot + pitchRotate(result - rig.GunPivot, pitch) end
    result = rig.TurretPivot + yawRotate(result - rig.TurretPivot, yaw)
    return self:LocalToWorld(result)
end
function ENT:GetT72Muzzle(machineGun)
    local rig = self.T72Profile and self.T72Profile.Rig
    if not rig then return end
    local point = machineGun and rig.MGMuzzle or rig.CannonMuzzle
    if not point then return end
    local pitch, yaw = self:GetTurretPitch(), self:GetTurretYaw()
    local direction = yawRotate(pitchRotate(Vector(1,0,0), pitch), yaw)
    return {Pos = self:T72RigPoint(point, pitch, yaw, true),
        Ang = self:LocalToWorldAngles(direction:Angle())}
end
function ENT:GetTurretViewOrigin()
    local rig = self.T72Profile and self.T72Profile.Rig
    if not rig or not rig.Sight then return self:GetPos(), false end
    return self:T72RigPoint(rig.Sight, 0, self:GetTurretYaw(), false), true
end
function ENT:TurretUpdateBallistics(velocity)
    if velocity then self.TurretBallisticsProjectileVelocity = velocity end
end
function ENT:CalcOpticsCrosshairDot() end
function ENT:T72ApplyVisualTurret(visual)
    if not CLIENT or not IsValid(visual) then return end
    local rig = self.T72Profile.Rig
    if self._T72RigVisual ~= visual then
        self._T72RigVisual = visual
        self._T72TurretBone = visual:LookupBone(rig.TurretBone)
        self._T72GunBone = visual:LookupBone(rig.GunBone)
    end
    -- Bind matrices map local +Y to canonical +Z on turret, -Y on gun.
    if self._T72TurretBone then
        visual:ManipulateBoneAngles(self._T72TurretBone, Angle(self:GetTurretYaw(),0,0))
    end
    if self._T72GunBone then
        visual:ManipulateBoneAngles(self._T72GunBone, Angle(-self:GetTurretPitch(),0,0))
    end
end
function ENT:AimTurret()
    if CLIENT then self:T72ApplyVisualTurret(self.T72Visual) return end
    if not self:IsTurretEnabled() then
        self:StopTurretSound()
        self:StopTurretSoundDMG()
        return
    end
    local weapon = self:GetWeaponHandler(self.TurretPodIndex or 1)
    if not IsValid(weapon) then return end
    local target = self:WorldToLocalAngles(weapon:GetAimVector():Angle())
    local rate = self.TurretAimRate * FrameTime()
    if self:GetTurretDamaged() then rate = rate * self.TurretRateDestroyedMul end
    if self:GetTurretForceCenter() then target = Angle(0,0,0) end
    local pitch = math.Clamp(math.ApproachAngle(self:GetTurretPitch(), target.p, rate),
        self.TurretPitchMin, self.TurretPitchMax)
    local yaw = math.ApproachAngle(self:GetTurretYaw(), target.y, rate)
    self:CalcTurretSound(pitch, yaw, math.max(rate,0.0001))
    self:SetTurretPitch(pitch)
    self:SetTurretYaw(yaw)
end
function ENT:UpdatePoseParameters()
    if CLIENT then self:T72ApplyVisualTurret(self.T72Visual) end
end
