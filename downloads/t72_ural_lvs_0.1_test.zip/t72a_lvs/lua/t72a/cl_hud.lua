-- Original vector HUD. No textures, fonts or UI files from War Thunder are used.
-- Called only by the T-72A entity's LVSHudPaint(X, Y, ply).
T72AHUD = T72AHUD or {}

local ink = Color(235, 240, 229, 245)
local muted = Color(170, 187, 174, 230)
local green = Color(166, 213, 126, 255)
local amber = Color(244, 193, 104, 255)
local red = Color(239, 111, 95, 255)
local panel = Color(15, 23, 20, 205)
local dark = Color(0, 0, 0, 220)
local lastScale

local function fonts(scale)
    if lastScale == scale then return end
    lastScale = scale
    surface.CreateFont("T72A_HUD_Small", {font = "Roboto", size = math.floor(16 * scale), weight = 500, extended = true})
    surface.CreateFont("T72A_HUD_Normal", {font = "Roboto", size = math.floor(21 * scale), weight = 600, extended = true})
    surface.CreateFont("T72A_HUD_Large", {font = "Roboto", size = math.floor(34 * scale), weight = 600, extended = true})
end

local function text(value, font, x, y, colour, align)
    draw.SimpleTextOutlined(tostring(value), "T72A_HUD_" .. font, x, y, colour or ink,
        align or TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, dark)
end

local function line(x1, y1, x2, y2, colour)
    surface.SetDrawColor(colour or ink)
    surface.DrawLine(x1, y1, x2, y2)
end

local function ring(x, y, radius, fraction, colour)
    surface.SetDrawColor(colour)
    local count = math.floor(math.Clamp(fraction, 0, 1) * 64)
    for i = 1, count do
        local a = (i - 1) / 64 * math.pi * 2 - math.pi * 0.5
        local b = i / 64 * math.pi * 2 - math.pi * 0.5
        surface.DrawLine(x + math.cos(a) * radius, y + math.sin(a) * radius,
            x + math.cos(b) * radius, y + math.sin(b) * radius)
    end
end

local function box(x, y, w, h, scale)
    draw.RoundedBox(3 * scale, x, y, w, h, panel)
    surface.SetDrawColor(96, 117, 100, 125)
    surface.DrawOutlinedRect(x, y, w, h, 1)
end

local function reticle(vehicle, width, height, scale, zoomed)
    local x, y = width * 0.5, height * 0.5
    local gap, length = 12 * scale, (zoomed and 135 or 75) * scale
    line(x - length, y, x - gap, y)
    line(x + gap, y, x + length, y)
    line(x, y - length * 0.65, x, y - gap)
    line(x, y + gap, x, y + length * 0.65)
    surface.SetDrawColor(ink)
    surface.DrawCircle(x, y, 4 * scale, ink.r, ink.g, ink.b, ink.a)
    for i = 1, 4 do
        local distance = (20 + i * 20) * scale
        local tick = (i % 2 == 0 and 7 or 4) * scale
        line(x - distance, y - tick, x - distance, y + tick, muted)
        line(x + distance, y - tick, x + distance, y + tick, muted)
    end

    -- This marker shows the bore's straight line, not a predicted ballistic impact.
    if vehicle.GetT72Muzzle then
        local position, angles = vehicle:GetT72Muzzle(vehicle:GetSelectedWeapon() == 2)
        if position and position.Pos then position, angles = position.Pos, position.Ang end
        if position and angles then
            local trace = util.TraceLine({start = position, endpos = position + angles:Forward() * 32768,
                filter = vehicle:GetCrosshairFilterEnts(), mask = MASK_SHOT})
            local screen = trace.HitPos:ToScreen()
            if screen.visible and screen.x > 5 and screen.x < width - 5 and screen.y > 5 and screen.y < height - 5 then
                surface.SetDrawColor(green)
                surface.DrawCircle(screen.x, screen.y, 7 * scale, green.r, green.g, green.b, green.a)
            end
        end
    end
end

local function compass(vehicle, width, scale)
    local heading = (360 - vehicle:GetAngles().y) % 360
    local centre = width * 0.5
    local y = 36 * scale
    local step = 5 * scale
    for offset = -45, 45, 5 do
        local bearing = (math.floor(heading / 5) * 5 + offset) % 360
        local xpos = centre + ((bearing - heading + 540) % 360 - 180) * step
        local major = bearing % 15 == 0
        line(xpos, y + 23 * scale, xpos, y + (major and 35 or 29) * scale, muted)
        if major then text(string.format("%03d", bearing), "Small", xpos, y, muted, TEXT_ALIGN_CENTER) end
    end
    line(centre, y + 39 * scale, centre - 5 * scale, y + 46 * scale, green)
    line(centre, y + 39 * scale, centre + 5 * scale, y + 46 * scale, green)
    text("КУРС КОРПУСА", "Small", centre, y + 52 * scale, muted, TEXT_ALIGN_CENTER)
end

local function vehicleInfo(vehicle, width, height, scale)
    local margin, w, h = 28 * scale, 290 * scale, 166 * scale
    local x, y = margin, height - margin - h
    box(x, y, w, h, scale)
    text("Т-72 УРАЛ", "Normal", x + 15 * scale, y + 12 * scale, ink)
    local health = math.max(vehicle:GetHP(), 0)
    local maxHealth = math.max(vehicle:GetMaxHP(), 1)
    local fraction = math.Clamp(health / maxHealth, 0, 1)
    local colour = fraction > 0.5 and green or (fraction > 0.25 and amber or red)
    text(string.format("ПРОЧНОСТЬ  %d / %d", math.ceil(health), maxHealth), "Small", x + 15 * scale, y + 43 * scale, colour)
    draw.RoundedBox(0, x + 15 * scale, y + 68 * scale, w - 30 * scale, 5 * scale, muted)
    draw.RoundedBox(0, x + 15 * scale, y + 68 * scale, (w - 30 * scale) * fraction, 5 * scale, colour)

    -- Same velocity conversion as LVS' wheel-drive HUD: Source units/s to km/h.
    local speed = vehicle:GetVelocity():Length() * 0.09144
    text(string.format("%02d", math.floor(speed + 0.5)), "Large", x + 15 * scale, y + 84 * scale)
    text("км/ч", "Small", x + 77 * scale, y + 101 * scale, muted)
    local currentGear = vehicle:GetGear()
    local gear = vehicle:GetReverse() and "R" or (currentGear == -1 and "АВТО" or tostring(currentGear))
    text("ПЕРЕДАЧА", "Small", x + 155 * scale, y + 86 * scale, muted)
    text(gear, "Normal", x + 252 * scale, y + 84 * scale, ink, TEXT_ALIGN_RIGHT)
    local running = vehicle:GetEngineActive()
    text(running and "ДВИГАТЕЛЬ: РАБОТАЕТ" or "ДВИГАТЕЛЬ: ВЫКЛ.", "Small", x + 15 * scale,
        y + 137 * scale, running and green or amber)
end

local function weaponInfo(vehicle, width, height, scale)
    local margin, w, h = 28 * scale, 315 * scale, 166 * scale
    local x, y = width - margin - w, height - margin - h
    box(x, y, w, h, scale)
    local selected = vehicle:GetSelectedWeapon()
    local names = vehicle.T72WeaponNames or {}
    local name = names[selected] or ("ОРУЖИЕ " .. tostring(selected))
    text(name, "Normal", x + 15 * scale, y + 12 * scale)
    local ammo, maximum = vehicle:GetNWAmmo(), vehicle:GetMaxAmmo()
    local stock = maximum <= 0 and "∞" or string.format("%d / %d", ammo, maximum)
    text(stock, "Large", x + 15 * scale, y + 40 * scale, ammo == 0 and red or ink)
    text("БОЕЗАПАС", "Small", x + 15 * scale, y + 80 * scale, muted)

    local duration = vehicle.GetT72ReloadDuration and vehicle:GetT72ReloadDuration() or vehicle.T72ReloadDuration or 0
    local remaining = selected == 1 and vehicle.GetT72ReloadEnd and math.max(vehicle:GetT72ReloadEnd() - CurTime(), 0) or 0
    local progress = duration > 0 and 1 - math.Clamp(remaining / duration, 0, 1) or 1
    local available = vehicle:GetHP() > 0 and ammo ~= 0
    local status = vehicle:GetHP() <= 0 and "УНИЧТ." or (ammo == 0 and "ПУСТО" or
        (remaining > 0 and string.format("%.1f", remaining) or "ГОТОВ"))
    local statusColour = not available and red or (remaining > 0 and amber or green)
    local rx, ry = x + w - 50 * scale, y + 71 * scale
    ring(rx, ry, 27 * scale, 1, muted)
    ring(rx, ry, 27 * scale, available and progress or 0, statusColour)
    text(status, "Small", rx, ry - 8 * scale, statusColour, TEXT_ALIGN_CENTER)
    text(selected == 2 and "ПКТ" or "125 мм", "Small", rx, ry + 35 * scale, muted, TEXT_ALIGN_CENTER)
    local range = vehicle.GetT72Range and vehicle:GetT72Range() or 0
    text(range > 0 and string.format("ДАЛЬНОМЕР: %d м", math.floor(range + 0.5)) or "ДАЛЬНОМЕР: —",
        "Small", x + 15 * scale, y + 137 * scale, muted)
end

function T72AHUD.Paint(vehicle, width, height, ply)
    if not IsValid(vehicle) or not IsValid(ply) then return end
    if not vehicle.T72A then return end
    local scale = math.Clamp(height / 1080, 0.6, 1.6)
    fonts(scale)
    local zoomed = ply:lvsKeyDown("ZOOM")
    if zoomed then
        local border = math.max((width - height * 1.35) * 0.5, 0)
        surface.SetDrawColor(0, 0, 0, 215)
        surface.DrawRect(0, 0, border, height)
        surface.DrawRect(width - border, 0, border, height)
    end
    compass(vehicle, width, scale)
    reticle(vehicle, width, height, scale, zoomed)
    vehicleInfo(vehicle, width, height, scale)
    weaponInfo(vehicle, width, height, scale)
end

-- Per-entity overrides: other LVS vehicles keep their standard HUD.
function T72AHUD.SuppressBasePanels(entityDefinition)
    entityDefinition.LVSHudPaintVehicleHealth = function() end
    entityDefinition.LVSHudPaintInfoText = function() end
    entityDefinition.LVSHudPaintCarMenu = function() end
end
