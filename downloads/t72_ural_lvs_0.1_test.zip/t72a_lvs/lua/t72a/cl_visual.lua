-- Original visual adapter. Native Damik model is -Y forward, LVS is +X.
-- Materials and bone edits affect only this private clientside instance.
local materials = include("t72a/sh_materials.lua")
local materialSerial = 0

local function removeVisual(vehicle)
    if IsValid(vehicle.T72Visual) then vehicle.T72Visual:Remove() end
    vehicle.T72Visual = nil
end

function ENT:T72EnsureVisual()
    if IsValid(self.T72Visual) then return self.T72Visual end
    local profile = self.T72Profile
    if not profile or not profile.Model or not util.IsValidModel(profile.Model) then return end
    local visual = ClientsideModel(profile.Model, RENDERGROUP_OPAQUE)
    if not IsValid(visual) then return end
    visual:SetNoDraw(true)
    visual:SetSkin(0)
    -- Model's default bodygroups have closed hatches and complete tracks.
    for _, group in ipairs(visual:GetBodyGroups()) do visual:SetBodygroup(group.id, 0) end
    for id, name in ipairs(visual:GetMaterials()) do
        -- GMod's override interface exposes slots 0..31. The default skin's
        -- 19 used slots fit; the MDL's later entries are unused skin variants.
        if id <= 32 then
            local replacement = materials.Resolve(name)
            visual:SetSubMaterial(id - 1, replacement)
            if replacement == materials.TrackMaterial then self._T72TrackSlot = id - 1 end
        end
    end
    if self._T72TrackSlot then
        materialSerial = materialSerial + 1
        self._T72TrackMaterial = CreateMaterial("t72a_ural_tracks_" .. materialSerial, "VertexLitGeneric", {
            ["$basetexture"] = "t72a_ural/neutral", ["$model"] = "1",
            ["$color2"] = "[0.52 0.53 0.54]", ["$phong"] = "1",
            ["$phongexponent"] = "20", ["$phongboost"] = "0.18"
        })
        visual:SetSubMaterial(self._T72TrackSlot, "!" .. self._T72TrackMaterial:GetName())
    end
    self.T72Visual = visual
    self:DrawShadow(false)
    self:SetRenderBounds(profile.RenderMins, profile.RenderMaxs)
    self:CallOnRemove("T72UralVisualCleanup", removeVisual)
    self._T72VisualWheelBones = {Left = {}, Right = {}}
    for _, side in ipairs({"Left", "Right"}) do
        for _, name in ipairs((profile.WheelBones or {})[side] or {}) do
            local id = visual:LookupBone(name)
            if id then table.insert(self._T72VisualWheelBones[side], id) end
        end
    end
    return visual
end

function ENT:T72AnimateRunningGear(visual)
    local frame = FrameNumber()
    if self._T72RunningGearFrame == frame then return end
    self._T72RunningGearFrame = frame
    local dt = math.Clamp(FrameTime(), 0.0001, 0.1)
    local yaw = self:GetAngles().y
    local yawRate = self._T72LastYaw and math.rad(math.AngleDifference(yaw, self._T72LastYaw)) / dt or 0
    self._T72LastYaw = yaw
    local forward = self:GetVelocity():Dot(self:GetForward())
    local spacing = math.abs(self.T72Profile.Wheels.Left[1].y)
    local radius = math.max(self.T72Profile.Wheels.Radius or 15.684, 1)
    local left = forward - yawRate * spacing
    local right = forward + yawRate * spacing
    self._T72WheelPhaseLeft = ((self._T72WheelPhaseLeft or 0) + math.deg(left * dt / radius)) % 360
    self._T72WheelPhaseRight = ((self._T72WheelPhaseRight or 0) + math.deg(right * dt / radius)) % 360
    for _, bone in ipairs(self._T72VisualWheelBones.Left) do
        visual:ManipulateBoneAngles(bone, Angle(-self._T72WheelPhaseLeft, 0, 0))
    end
    for _, bone in ipairs(self._T72VisualWheelBones.Right) do
        visual:ManipulateBoneAngles(bone, Angle(-self._T72WheelPhaseRight, 0, 0))
    end
    -- Both belts share one original material slot. Use a common UV scroll;
    -- independent wheel rotations above still represent pivot turns.
    if self._T72TrackMaterial then
        self._T72TrackScroll = ((self._T72TrackScroll or 0) + forward * dt / 100) % 1
        local matrix = Matrix()
        matrix:Translate(Vector(0, self._T72TrackScroll, 0))
        self._T72TrackMaterial:SetMatrix("$basetexturetransform", matrix)
    end
end

function ENT:Draw(flags)
    local visual = self:T72EnsureVisual()
    if not IsValid(visual) then return end
    visual:SetPos(self:GetPos())
    visual:SetAngles(self:LocalToWorldAngles(Angle(0, self.T72Profile.VisualYaw or 90, 0)))
    visual:SetColor(self:GetColor())
    self:T72ApplyVisualTurret(visual)
    self:T72AnimateRunningGear(visual)
    visual:SetupBones()
    visual:DrawModel(flags)
end

-- All our replacement shaders are opaque, including the tinted glass.
-- Avoid a second draw of either the original root or its visual adapter.
function ENT:DrawTranslucent() end
