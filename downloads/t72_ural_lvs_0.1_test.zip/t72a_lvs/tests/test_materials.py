"""Tests of the byte-level format, independent of an installed Garry's Mod."""
import importlib.util
from pathlib import Path
import struct
import unittest

from PIL import Image

path = Path(__file__).resolve().parents[1] / "tools" / "build_materials.py"
spec = importlib.util.spec_from_file_location("build_materials", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class VTFTests(unittest.TestCase):
    def test_header_layout_mip_order_channels_and_rows(self):
        source = Image.new("RGBA", (2, 2))
        source.putdata([(255, 0, 0, 255), (0, 255, 0, 255),
                        (0, 0, 255, 255), (255, 255, 255, 255)])
        data = module.encode_vtf(source)
        self.assertEqual(data[:4], b"VTF\0")
        self.assertEqual(struct.unpack_from("<IIIHH", data, 4), (7, 2, 80, 2, 2))
        self.assertEqual(struct.unpack_from("<HH", data, 24), (1, 0))
        self.assertEqual(struct.unpack_from("<I", data, 52)[0], 0)
        self.assertEqual(data[56], 2)
        self.assertEqual(struct.unpack_from("<I", data, 57)[0], 0xFFFFFFFF)
        self.assertEqual(struct.unpack_from("<H", data, 63)[0], 1)
        self.assertEqual(len(data), 80 + 4 + 16)
        # The 1x1 mip is first; the original colored quadrants are last with
        # unchanged channel and row orientation (no texture-writer UV flip).
        self.assertEqual(data[80:84], bytes((128, 128, 128, 255)))
        self.assertEqual(data[84:], source.tobytes())

    def test_rectangular_mip_chain_and_reject_invalid_dimensions(self):
        data = module.encode_vtf(Image.new("RGB", (8, 2), (2, 3, 4)))
        self.assertEqual(data[56], 4)
        self.assertEqual(len(data), 80 + (1 + 2 + 4 + 16) * 4)
        self.assertEqual(data[80:84], bytes((2, 3, 4, 255)))
        with self.assertRaises(ValueError):
            module.encode_vtf(Image.new("RGB", (3, 4)))


if __name__ == "__main__":
    unittest.main()
