-- Contract smoke test, not a Source rendering/physics test.
local root = arg[1] or "."
ENT = {OnRemoved = function() return "preserved" end}
local draws, creations, removals, callbacks = 0, 0, 0, {}
local frame = 1
local visual
function IsValid(e) return type(e) == "table" and e.valid ~= false end
function include(path) return dofile(root .. "/lua/" .. path) end
function Angle(p,y,r) return {p=p,y=y,r=r} end
function Vector(x,y,z) return {x=x,y=y,z=z,Dot=function() return 100 end} end
function FrameNumber() return frame end
function FrameTime() return 0.016 end
math.Clamp = function(n,a,b) return math.max(a,math.min(n,b)) end
math.AngleDifference = function(a,b) return (a-b+180)%360-180 end
RENDERGROUP_OPAQUE = 0
util = {IsValidModel=function() return true end}
function Matrix() return {Translate=function() end} end
function CreateMaterial(name)
    return {GetName=function() return name end,SetMatrix=function() end}
end
function ClientsideModel()
    creations = creations + 1
    visual = {valid=true,bones={},sub={}}
    function visual:SetNoDraw(v) self.noDraw=v end
    function visual:SetSkin(v) self.skin=v end
    function visual:GetBodyGroups() return {{id=0}} end
    function visual:SetBodygroup() end
    function visual:GetMaterials() return {"models/test/body", "models/test/tracks"} end
    function visual:SetSubMaterial(id,value) self.sub[id]=value end
    function visual:LookupBone(name) return name == "left" and 1 or 2 end
    function visual:ManipulateBoneAngles(id,value) self.bones[id]=value end
    function visual:SetPos(pos) self.pos=pos end
    function visual:SetAngles(ang) self.ang=ang end
    function visual:SetColor() end
    function visual:SetupBones() end
    function visual:DrawModel() draws=draws+1 end
    function visual:Remove() self.valid=false; removals=removals+1 end
    return visual
end
dofile(root .. "/lua/t72a/cl_visual.lua")
local v = setmetatable({T72Profile={Model="model",VisualYaw=90,
    RenderMins={},RenderMaxs={},Wheels={Left={Vector(0,57.322,0)},Radius=15.684},
    WheelBones={Left={"left"},Right={"right"}}}}, {__index=ENT})
function v:DrawShadow() end
function v:SetRenderBounds() end
function v:CallOnRemove(name,func) callbacks[name]=func end
function v:GetPos() return {} end
function v:GetAngles() return {y=0} end
function v:LocalToWorldAngles(ang) return ang end
function v:GetColor() return {} end
function v:GetVelocity() return Vector(100,0,0) end
function v:GetForward() return Vector(1,0,0) end
function v:T72ApplyVisualTurret() end
v:Draw()
assert(creations==1 and draws==1 and visual.noDraw and visual.skin==0)
assert(visual.ang.y==90 and visual.sub[0]=="t72a_ural/olive")
assert(visual.sub[1]:sub(1,1)=="!", "track material must be per-instance")
local phase=v._T72WheelPhaseLeft
v:Draw()
assert(creations==1 and v._T72WheelPhaseLeft==phase, "same frame must not animate twice")
frame=2
v:Draw()
assert(v._T72WheelPhaseLeft~=phase)
v:DrawTranslucent()
assert(draws==3, "no duplicate translucent model")
assert(v:OnRemoved()=="preserved", "base removal hook must stay intact")
callbacks.T72UralVisualCleanup(v)
assert(removals==1 and v.T72Visual==nil)
print("PASS: visual lifecycle, private materials, orientation and one update/frame (mock API)")
