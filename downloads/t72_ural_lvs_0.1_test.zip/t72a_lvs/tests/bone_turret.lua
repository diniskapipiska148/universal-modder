-- Deterministic rig contract tests using a small mocked GMod API.
-- This does not validate GMod bone multiplication or real vehicle physics.
-- Run from addon root: texlua tests/bone_turret.lua .
local root = arg[1] or "."
local vector = {}
vector.__index = vector
function Vector(x,y,z) return setmetatable({x=x,y=y,z=z},vector) end
function vector.__add(a,b) return Vector(a.x+b.x,a.y+b.y,a.z+b.z) end
function vector.__sub(a,b) return Vector(a.x-b.x,a.y-b.y,a.z-b.z) end
function vector:Length() return math.sqrt(self.x*self.x+self.y*self.y+self.z*self.z) end
local angle = {}
angle.__index = angle
function Angle(p,y,r) return setmetatable({p=p,y=y,r=r},angle) end
function angle:Forward()
    local p,y=math.rad(self.p),math.rad(self.y)
    return Vector(math.cos(p)*math.cos(y),math.cos(p)*math.sin(y),-math.sin(p))
end
function vector:Angle()
    return Angle(math.deg(math.atan(-self.z,math.sqrt(self.x*self.x+self.y*self.y))),
        math.deg(math.atan(self.y,self.x)),0)
end
function IsValid(v) return v~=nil and v.valid~=false end
math.Clamp = function(v,a,b) return math.max(a,math.min(v,b)) end
math.ApproachAngle = function(current,target,rate)
    local delta=(target-current+180)%360-180
    return current+math.Clamp(delta,-rate,rate)
end
local dt=0.1
function FrameTime() return dt end
CLIENT=false
SERVER=true
ENT={}
local profile=dofile(root.."/lua/t72a/sh_profile.lua")
dofile(root.."/lua/t72a/sh_bone_turret.lua")
local count=0
local function check(v,message) count=count+1; assert(v,message) end
local function near(a,b,message,epsilon)
    check(math.abs(a-b)<(epsilon or 1e-6),message..": "..tostring(a).." vs "..tostring(b))
end
local function nearVector(a,b,message)
    near(a.x,b.x,message.." x");near(a.y,b.y,message.." y");near(a.z,b.z,message.." z")
end
local vehicle=setmetatable({T72Profile=profile,pitch=0,yaw=0,rootYaw=0,origin=Vector(0,0,0),
    enabled=true,damaged=false,forceCentre=false,TurretAimRate=16,
    TurretPitchMin=-14,TurretPitchMax=6,TurretRateDestroyedMul=0.25}, {__index=ENT})
function vehicle:GetTurretPitch() return self.pitch end
function vehicle:GetTurretYaw() return self.yaw end
function vehicle:SetTurretPitch(v) self.pitch=v end
function vehicle:SetTurretYaw(v) self.yaw=v end
function vehicle:GetPos() return self.origin end
function vehicle:LocalToWorld(v)
    local a=math.rad(self.rootYaw)
    return self.origin+Vector(v.x*math.cos(a)-v.y*math.sin(a),v.x*math.sin(a)+v.y*math.cos(a),v.z)
end
function vehicle:LocalToWorldAngles(a) return Angle(a.p,a.y+self.rootYaw,a.r) end
function vehicle:WorldToLocalAngles(a) return Angle(a.p,a.y-self.rootYaw,a.r) end
function vehicle:IsTurretEnabled() return self.enabled end
function vehicle:GetTurretDamaged() return self.damaged end
function vehicle:GetTurretForceCenter() return self.forceCentre end
local soundStops=0
function vehicle:StopTurretSound() soundStops=soundStops+1 end
function vehicle:StopTurretSoundDMG() soundStops=soundStops+1 end
function vehicle:CalcTurretSound(p,y,rate) self.lastSoundRate=rate end
local aim=Angle(0,0,0)
function vehicle:GetWeaponHandler() return {GetAimVector=function() return aim:Forward() end} end

-- Confirm the tested geometry comes from the supplied model, not placeholders.
check(profile.Ready and profile.VisualYaw==90,"profile is prepared for canonical +X")
check(#profile.Wheels.Left==6 and #profile.Wheels.Right==6,"six measured road wheels per side")
near(profile.Wheels.Radius,15.684,"measured wheel radius")
for i=1,6 do
    local l,r=profile.Wheels.Left[i],profile.Wheels.Right[i]
    near(l.x,r.x,"paired wheel longitudinal alignment")
    near(l.y,-r.y,"paired wheel track symmetry")
end
local rig=profile.Rig
nearVector(vehicle:GetT72Muzzle(false).Pos,Vector(240.478439,0.0451313,69.9407692),"rest muzzle matches end ring")
nearVector(vehicle:GetT72Muzzle(false).Ang:Forward(),Vector(1,0,0),"rest bore points +X")
vehicle.yaw=90
nearVector(vehicle:GetT72Muzzle(false).Pos,
    Vector(rig.TurretPivot.x-rig.CannonMuzzle.y,
        rig.CannonMuzzle.x-rig.TurretPivot.x,rig.CannonMuzzle.z),"yaw rotates muzzle about turret pivot")
nearVector(vehicle:GetT72Muzzle(false).Ang:Forward(),Vector(0,1,0),"yaw rotates bore direction")
vehicle.yaw=0;vehicle.pitch=10
local a=math.rad(10)
local expected=Vector(rig.GunPivot.x+(rig.CannonMuzzle.x-rig.GunPivot.x)*math.cos(a)
    +(rig.CannonMuzzle.z-rig.GunPivot.z)*math.sin(a),rig.CannonMuzzle.y,
    rig.GunPivot.z-(rig.CannonMuzzle.x-rig.GunPivot.x)*math.sin(a)
    +(rig.CannonMuzzle.z-rig.GunPivot.z)*math.cos(a))
nearVector(vehicle:GetT72Muzzle(false).Pos,expected,"pitch rotates muzzle about gun pivot")
near(vehicle:GetT72Muzzle(false).Ang.p,10,"positive Source pitch points down")
near((vehicle:GetT72Muzzle(false).Pos-rig.GunPivot):Length(),
    (rig.CannonMuzzle-rig.GunPivot):Length(),"pitch preserves barrel distance")
vehicle.yaw=-90
local moved=vehicle:GetT72Muzzle(false).Pos
nearVector(moved,Vector(rig.TurretPivot.x+expected.y,-(expected.x-rig.TurretPivot.x),expected.z),
    "pitch then yaw are composed in correct order")
local mg=vehicle:GetT72Muzzle(true)
check((mg.Pos-moved):Length()>100,"MG uses separate gameplay socket")
nearVector(mg.Ang:Forward(),vehicle:GetT72Muzzle(false).Ang:Forward(),"coax shares bore orientation")
local sight,found=vehicle:GetTurretViewOrigin()
check(found,"sight is available")
vehicle.pitch=-10
nearVector(vehicle:GetTurretViewOrigin(),sight,"sight follows turret but not gun pitch")
vehicle.yaw=0;vehicle.pitch=0;vehicle.rootYaw=90;vehicle.origin=Vector(100,200,300)
nearVector(vehicle:GetT72Muzzle(false).Pos,Vector(100-rig.CannonMuzzle.y,200+rig.CannonMuzzle.x,300+rig.CannonMuzzle.z),
    "world muzzle follows rigid vehicle transform")
nearVector(vehicle:GetT72Muzzle(false).Ang:Forward(),Vector(0,1,0),"world bore follows vehicle rotation")

vehicle.rootYaw=0;vehicle.origin=Vector(0,0,0);vehicle.pitch=0;vehicle.yaw=179
aim=Angle(60,-179,0)
vehicle:AimTurret()
near(vehicle.pitch,1.6,"pitch rate limit")
near(vehicle.yaw,180.6,"yaw uses shortest arc across wrap boundary")
vehicle.pitch=5.9;vehicle.yaw=0
vehicle:AimTurret();near(vehicle.pitch,6,"downwards pitch clamp")
aim=Angle(-60,0,0);vehicle.pitch=-13.9
vehicle:AimTurret();near(vehicle.pitch,-14,"upwards pitch clamp")
vehicle.pitch=0;vehicle.yaw=0;vehicle.damaged=true;aim=Angle(30,30,0)
vehicle:AimTurret();near(vehicle.pitch,0.4,"damaged turret reduced rate")
vehicle.damaged=false;vehicle.forceCentre=true;vehicle.pitch=5;vehicle.yaw=5
vehicle:AimTurret();near(vehicle.pitch,3.4,"force-centre pitch moves towards zero")
near(vehicle.yaw,3.4,"force-centre yaw moves towards zero")
vehicle.enabled=false
local frozenP,frozenY=vehicle.pitch,vehicle.yaw
vehicle:AimTurret()
near(vehicle.pitch,frozenP,"disabled turret pitch stays fixed")
near(vehicle.yaw,frozenY,"disabled turret yaw stays fixed")
check(soundStops==2,"disabled turret stops both sound loops")

-- Native bone-local axes differ from canonical server axes.
CLIENT=true;SERVER=false;vehicle.yaw=23;vehicle.pitch=-4
local lookups,angles=0,{}
local visual={LookupBone=function(_,name)
    lookups=lookups+1;return name==rig.TurretBone and 29 or 30
end,ManipulateBoneAngles=function(_,bone,value) angles[bone]=value end}
vehicle:T72ApplyVisualTurret(visual)
near(angles[29].p,23,"turret native local +Y rotation")
near(angles[30].p,4,"gun native local -Y rotation")
vehicle:T72ApplyVisualTurret(visual)
check(lookups==2,"bone IDs cached per visual instance")
vehicle:T72ApplyVisualTurret(nil)
check(lookups==2,"missing visual ignored")
print("PASS: "..count.." bone-rig math/aim contracts (mock API; GMod verification pending)")
