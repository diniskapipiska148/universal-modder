function Color(r,g,b,a) return {r=r,g=g,b=b,a=a} end
TEXT_ALIGN_LEFT=0; TEXT_ALIGN_RIGHT=1; TEXT_ALIGN_CENTER=2; TEXT_ALIGN_TOP=3
MASK_SHOT=1
function IsValid(e) return e~=nil and e.valid ~= false end
function CurTime() return 100 end
math.Clamp=function(n,a,b) return math.max(a, math.min(n,b)) end
local drawcalls=0
surface=setmetatable({}, {__index=function() return function(...) drawcalls=drawcalls+1 end end})
local labels = {}
draw=setmetatable({SimpleTextOutlined=function(value) labels[tostring(value)] = true; drawcalls=drawcalls+1 end}, {__index=function() return function(...) drawcalls=drawcalls+1 end end})
util={TraceLine=function() return {HitPos={ToScreen=function() return {visible=true,x=300,y=300} end}} end}
local addonRoot = arg[1] or '.'
dofile(addonRoot .. '/lua/t72a/cl_hud.lua')
local vehicle={T72A=true,T72WeaponNames={[1]='125 мм',[2]='ПКТ'}}
local values={HP=3500,MaxHP=6000,Reverse=false,Gear=4,EngineActive=true,SelectedWeapon=1,NWAmmo=30,MaxAmmo=39,T72ReloadDuration=7.1,T72ReloadEnd=104,T72Range=538}
for k,_ in pairs(values) do vehicle['Get'..k]=function() return values[k] end end
function vehicle:GetAngles() return {y=354} end
local direction = setmetatable({}, {__mul=function() return {} end})
local position = setmetatable({}, {__add=function() return {} end})
function vehicle:GetT72Muzzle(machineGun)
 assert(machineGun == (values.SelectedWeapon == 2), 'reticle picked wrong weapon muzzle')
 return {Pos=position, Ang={Forward=function() return direction end}}
end
function vehicle:GetCrosshairFilterEnts() return {self} end
function vehicle:GetVelocity() return {Length=function() return 600 end} end
local ply={lvsKeyDown=function() return false end}
for _,s in ipairs({{800,600},{1280,720},{1920,1080},{3840,2160}}) do
 T72AHUD.Paint(vehicle,s[1],s[2],ply)
end
values.Gear=-1; labels={}
T72AHUD.Paint(vehicle,1920,1080,ply)
assert(labels['АВТО'], 'automatic gearbox label absent')
values.SelectedWeapon=2; values.NWAmmo=0; values.T72ReloadEnd=99; values.HP=0; values.EngineActive=false; values.Reverse=true
ply.lvsKeyDown=function() return true end
labels={}
T72AHUD.Paint(vehicle,1920,1080,ply)
assert(labels['УНИЧТ.'] and not labels['ГОТОВ'], 'destroyed vehicle reports ready')
values.HP=100; labels={}
T72AHUD.Paint(vehicle,1920,1080,ply)
assert(labels['ПУСТО'] and not labels['ГОТОВ'], 'empty weapon reports ready')
vehicle.GetT72ReloadDuration=nil; vehicle.GetT72ReloadEnd=nil; vehicle.GetT72Range=nil
T72AHUD.Paint(vehicle,1920,1080,ply)
vehicle.T72A=false
local previous=drawcalls
T72AHUD.Paint(vehicle,1920,1080,ply)
assert(drawcalls==previous,'HUD leaked to unrelated vehicle')
print('HUD mock render smoke passed: 4 resolutions; zoom; 0 HP/ammo; reverse; absent optional telemetry; non-T72 skip. Draw calls: '..drawcalls)
