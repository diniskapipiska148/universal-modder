-- Standalone contract test; not a Garry's Mod runtime test.
-- Run: texlua tests/weapons.lua /path/to/t72a_lvs
local root = arg[1] or "."
local now = 100
function CurTime() return now end
function Material(value) return value end
function IsValid(value) return type(value) == "table" and value.valid == true end
function Vector(x, y, z)
    return setmetatable({x = x, y = y, z = z}, {
        __unm = function(a) return Vector(-a.x, -a.y, -a.z) end,
        __mul = function(a, b) return Vector(a.x * b, a.y * b, a.z * b) end
    })
end
function EffectData()
    return {SetOrigin = function() end, SetAngles = function() end, SetScale = function() end}
end
util = {Effect = function() end}
DMG_BLAST = 64
ENT = {}
dofile(root .. "/lua/entities/lvs_t72a/sh_weapons.lua")

local shots, count = {}, 0
local function check(value, message)
    count = count + 1
    assert(value, message)
end
local vehicle = setmetatable({
    hp = 4000, enabled = true, reload = 0, selected = 1,
    ammo = {39, 2000}, registered = {}, missing = false,
    T72Profile = {CannonAttachment = "confirmed_gun", MGAttachment = "confirmed_mg"}
}, {__index = ENT})
function vehicle:GetHP() return self.hp end
function vehicle:GetAmmo() return self.ammo[self.selected] end
function vehicle:GetTurretEnabled() return self.enabled end
function vehicle:GetT72ReloadEnd() return self.reload end
function vehicle:SetT72ReloadEnd(value) self.reload = value end
function vehicle:AddWeapon(value) self.registered[#self.registered + 1] = value end
function vehicle:LookupAttachment(name)
    if self.missing then return 0 end
    return name == "confirmed_gun" and 1 or (name == "confirmed_mg" and 2 or 0)
end
function vehicle:GetAttachment(id)
    if id <= 0 then return end
    return {Pos = Vector(id, 0, 0), Ang = {Forward = function() return Vector(1, 0, 0) end}}
end
function vehicle:GetDriver() return {valid = true} end
function vehicle:LVSFireBullet(bullet) shots[#shots + 1] = bullet end
function vehicle:TakeAmmo(value) self.ammo[self.selected] = self.ammo[self.selected] - value end
function vehicle:EmitSound() end
function vehicle:GetPhysicsObject() return {valid = false} end
function vehicle:TurretUpdateBallistics(speed, attachment) self.ballistics = {speed, attachment} end

vehicle:InitWeapons()
check(#vehicle.registered == 2, "register cannon and MG")
local cannon, mg = vehicle.registered[1], vehicle.registered[2]
check(cannon.Ammo == 39 and mg.Ammo == 2000, "finite separate ammunition")
cannon.OnSelect(vehicle)
check(vehicle.ballistics[2] == "confirmed_gun", "cannon uses its own attachment")
cannon.Attack(vehicle)
check(#shots == 1 and vehicle.ammo[1] == 38, "shot costs exactly one shell")
check(shots[1].EnableBallistics and shots[1].SplashDamage > 0, "cannon fires ballistic HE")
check(vehicle.reload == 107.1, "autoloader timestamp")
check(cannon.Attack(vehicle) == true and #shots == 1, "cannot refire during reload")
vehicle.selected = 2
mg.OnSelect(vehicle)
check(vehicle.ballistics[2] == "confirmed_mg", "MG uses distinct attachment")
mg.Attack(vehicle)
check(#shots == 2 and vehicle.ammo[2] == 1999, "MG fires while cannon reloads")
vehicle.selected = 1
check(cannon.Attack(vehicle) == true and #shots == 2, "switching weapons cannot skip reload")
now = 108
vehicle.missing = true
check(cannon.Attack(vehicle) == true and vehicle.ammo[1] == 38, "missing rig costs no ammo")
vehicle.missing = false
cannon.Attack(vehicle)
check(#shots == 3 and vehicle.ammo[1] == 37, "cannon fires after reload")
vehicle.hp = 0
check(mg.Attack(vehicle) == true and #shots == 3, "destroyed vehicle cannot fire")
vehicle.hp = 4000
vehicle.enabled = false
check(mg.Attack(vehicle) == true and #shots == 3, "disabled turret cannot fire")
vehicle.enabled = true
vehicle.selected = 2
vehicle.ammo[2] = 0
check(mg.Attack(vehicle) == true and #shots == 3, "empty MG cannot fire")
vehicle.selected = 1
vehicle.ammo[1] = 0
now = 120
check(cannon.Attack(vehicle) == true and #shots == 3, "empty cannon cannot fire")
print("PASS: " .. count .. " weapon contract checks (mock API; in-game testing pending)")
