-- Validate the actual original exported mesh, not just a renderer fixture.
local root = arg[1] or "."
function Vector(x,y,z) return {x=x,y=y,z=z} end
function Angle(p,y,r) return {p=p,y=y,r=r} end
local profile=dofile(root.."/lua/t64a_1971/sh_generated_profile.lua")
local index=dofile(root.."/lua/t64a_1971/geometry/index.lua")
assert(profile.Ready and #profile.Wheels.Left==6 and #profile.Wheels.Right==6)
assert(profile.Model:find("models/hunter/",1,true)==1,"no borrowed tank model dependency")
local paths,triangles,wheels={},0,0
local maxGun=-math.huge
for name,part in pairs(index.Parts) do
 assert(type(part.Pivot)=="table" and #part.Pivot==3,name)
 if part.Kind=="wheel" then
  wheels=wheels+1
  assert(part.Side=="Left" or part.Side=="Right")
 end
end
assert(wheels==12,"twelve independently rendered road wheels")
for _,path in ipairs(index.Chunks) do
 assert(not paths[path],"duplicate chunk")
 assert(path:match("^t64a_1971/geometry/chunk_%d+%.lua$"),"unexpected generated path")
 paths[path]=true
 local chunk=dofile(root.."/lua/"..path)
 local vertices=chunk.Vertices
 assert(index.Parts[chunk.Part],"part metadata missing")
 assert(chunk.Material:sub(1,10)=="t64a_1971/","foreign material")
 local material=assert(io.open(root.."/materials/"..chunk.Material..".vmt","rb"),"generated material missing")
 material:close()
 assert(#vertices>0 and #vertices%24==0 and #vertices<=512*3*8,"triangle shard size")
 triangles=triangles+#vertices/24
 for i=1,#vertices,8 do
  for k=0,7 do assert(type(vertices[i+k])=="number" and vertices[i+k]==vertices[i+k] and math.abs(vertices[i+k])<1000000) end
  local norm=vertices[i+3]^2+vertices[i+4]^2+vertices[i+5]^2
  assert(norm>.99 and norm<1.01,"unit normals required")
  if index.Parts[chunk.Part].Kind=="gun" then
   maxGun=math.max(maxGun,vertices[i]+index.Parts[chunk.Part].Pivot[1])
  end
 end
end
assert(triangles>5000 and triangles<40000,"actual complete geometry, not an empty or oversized placeholder")
assert(math.abs(maxGun-profile.Rig.CannonMuzzle.x)<.1,"physical shot origin must coincide with generated gun end")
assert(index.Parts.turret.Pivot[1]==profile.Rig.TurretPivot.x)
assert(index.Parts.gun.Pivot[1]==profile.Rig.GunPivot.x)
print("PASS: original T64 profile,12 wheel parts,"..#index.Chunks.." network shards,"..triangles.." triangles and muzzle alignment")
