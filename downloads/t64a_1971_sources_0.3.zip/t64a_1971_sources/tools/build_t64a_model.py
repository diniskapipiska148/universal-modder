#!/usr/bin/env python3
"""Original procedural T-64A (circa 1971) game-art approximation.

No tank mesh is imported. Exports Source-unit, +X-forward component meshes to
small Lua shards, and optionally Blender/GLB sources and honest offline renders.
Run Python normally for geometry; --sources invokes installed Blender as well.
The early gill skirts, small road wheels and low cast turret distinguish this
model from later T-64B/BV and T-72 variants. It is not an engineering survey.
"""
from __future__ import annotations
import argparse, json, math, pathlib, subprocess, sys, zlib
from collections import defaultdict

V=lambda x,y,z:(float(x),float(y),float(z))
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def mul(a,s): return tuple(x*s for x in a)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def unit(a):
 n=math.sqrt(dot(a,a));return mul(a,1/n) if n>1e-12 else (0.,0.,1.)
PARTS={}; TRI=defaultdict(list)
PIVOTS={'hull':(0,0,0),'turret':(-8,0,65),'gun':(45,0,82),'track_left':(0,0,0),'track_right':(0,0,0)}
def part(name,kind,pivot=(0,0,0),side=None):
 PARTS[name]={'Kind':kind,'Pivot':list(pivot)}
 if side: PARTS[name]['Side']=side
 PIVOTS[name]=pivot

def triangle(partname,mat,a,b,c,uv=None,normals=None):
 n=unit(cross(sub(b,a),sub(c,a)))
 if math.sqrt(dot(cross(sub(b,a),sub(c,a)),cross(sub(b,a),sub(c,a))))<1e-8:return
 if uv is None:
  # Stable planar coordinates, not arbitrary per-triangle 0..1 texture stretching.
  major=max(range(3),key=lambda i:abs(n[i])); axes=([1,2],[0,2],[0,1])[major]
  uv=[(p[axes[0]]/45,p[axes[1]]/45) for p in (a,b,c)]
 TRI[(partname,mat)].append([(sub(p,PIVOTS[partname]), normals[i] if normals else n, uv[i]) for i,p in enumerate((a,b,c))])

def quad(p,m,a,b,c,d,uv=None,normals=None):
 triangle(p,m,a,b,c,[uv[i] for i in (0,1,2)] if uv else None,[normals[i] for i in (0,1,2)] if normals else None)
 triangle(p,m,a,c,d,[uv[i] for i in (0,2,3)] if uv else None,[normals[i] for i in (0,2,3)] if normals else None)

def box(p,m,center,size,rot=0):
 x,y,z=center; sx,sy,sz=[v/2 for v in size]; ca,sa=math.cos(rot),math.sin(rot)
 vs=[(x+dx*ca-dy*sa,y+dx*sa+dy*ca,z+dz) for dx,dy,dz in [(-sx,-sy,-sz),(sx,-sy,-sz),(sx,sy,-sz),(-sx,sy,-sz),(-sx,-sy,sz),(sx,-sy,sz),(sx,sy,sz),(-sx,sy,sz)]]
 for ids in ((0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)):
  quad(p,m,*[vs[i] for i in ids])

def cylinder(p,m,a,b,r,n=24,r2=None,caps=True):
 axis=unit(sub(b,a)); seed=(0,0,1) if abs(axis[2])<.9 else (0,1,0)
 u=unit(cross(seed,axis));v=cross(axis,u); r2=r if r2 is None else r2
 length=math.sqrt(dot(sub(b,a),sub(b,a)))
 for i in range(n):
  aa,bb=i*math.tau/n,(i+1)*math.tau/n
  na=add(mul(u,math.cos(aa)),mul(v,math.sin(aa)));nb=add(mul(u,math.cos(bb)),mul(v,math.sin(bb)))
  va,vb=add(a,mul(na,r)),add(a,mul(nb,r));vc,vd=add(b,mul(nb,r2)),add(b,mul(na,r2))
  quad(p,m,va,vb,vc,vd,[(0,i/n),(0,(i+1)/n),(length/35,(i+1)/n),(length/35,i/n)],[na,nb,nb,na])
  if caps:
   triangle(p,m,a,vb,va);triangle(p,m,b,vd,vc)

def dome(p,m,center,radii,n=48,rings=12,theta_max=math.pi*.5):
 # Upper, gently irregular cast shell, explicitly closed underneath.
 cx,cy,cz=center;rx,ry,rz=radii
 def vertex(theta,phi):
  st,ct=math.sin(theta),math.cos(theta)
  cast=1+.012*math.sin(phi*7)*st*st
  v=(cx+rx*st*math.cos(phi)*cast,cy+ry*st*math.sin(phi)*cast,cz+rz*ct)
  normal=unit(((v[0]-cx)/(rx*rx),(v[1]-cy)/(ry*ry),(v[2]-cz)/(rz*rz)))
  return v,normal
 for j in range(rings):
  t0,t1=j/rings*theta_max,(j+1)/rings*theta_max
  for i in range(n):
   a0,a1=i/n*math.tau,(i+1)/n*math.tau
   vals=[vertex(t0,a0),vertex(t1,a0),vertex(t1,a1),vertex(t0,a1)]
   quad(p,m,*[x[0] for x in vals],uv=[(i/n,j/rings), (i/n,(j+1)/rings),((i+1)/n,(j+1)/rings),((i+1)/n,j/rings)],normals=[x[1] for x in vals])
 bottom=cz+rz*math.cos(theta_max)
 for i in range(n):
  a,b=vertex(theta_max,i/n*math.tau)[0],vertex(theta_max,(i+1)/n*math.tau)[0]
  triangle(p,m,(cx,cy,bottom),b,a)

def build():
 PARTS.clear();TRI.clear();PIVOTS.clear()
 part('hull','hull');part('turret','turret',(-8,0,65));part('gun','gun',(45,0,82))
 for side,label,y in [('Left','L',77),('Right','R',-77)]:
  part('track_'+side.lower(),'track',(0,0,0),side)
  for i,x in enumerate([112,70,28,-14,-56,-98],1):part(f'wheel_{label}{i}','wheel',(x,y,19),side)
 # Six-sided lower/upper hull with a sloping glacis, instead of a featureless cube.
 profile=[(-164,29),(158,29),(176,46),(122,65),(-130,65),(-164,54)]
 for i in range(len(profile)):
  a,b=profile[i],profile[(i+1)%len(profile)]
  quad('hull','armor',(a[0],-67,a[1]),(a[0],67,a[1]),(b[0],67,b[1]),(b[0],-67,b[1]))
 for s in (-1,1):
  for i in range(1,len(profile)-1):
   a,b,c=[(profile[k][0],s*67,profile[k][1]) for k in (0,i,i+1)]
   triangle('hull','armor',*( (a,b,c) if s<0 else (a,c,b)))
  box('hull','armor',(-1,s*79,49),(324,31,4))
  box('hull','darksteel',(0,s*94,47),(320,2,5))
  # Characteristic early hinged gill armour, not later full rubber skirts.
  for i,x in enumerate([92,35,-22,-79]):
   box('hull','armor',(x,s*(91.5+i*.3),35),(36,3,29),rot=s*math.radians(13))
   cylinder('hull','darksteel',(x-15,s*92,50),(x+15,s*92,50),1.8,10)
  # Tow cable, rear hooks and lifting eyes.
  cylinder('hull','darksteel',(-155,s*57,55),(-62,s*57,60),1.0,10)
  cylinder('hull','darksteel',(140,s*48,48),(158,s*48,48),2.2,12)
  cylinder('hull','darksteel',(-169,s*48,38),(-157,s*48,38),2.5,12)
  # Rear cylindrical auxiliary tanks with hoops and brackets.
  cylinder('hull','armor',(-164,s*44-18,67),(-164,s*44+18,67),15,28)
  for yy in (s*44-14,s*44+14):cylinder('hull','darksteel',(-164,yy-.7,67),(-164,yy+.7,67),15.7,28)
  box('hull','darksteel',(-156,s*44,52),(18,41,4))
  # Front lamps on fenders; glass at the outward/front lens.
  cylinder('hull','armor',(143,s*72,59),(153,s*72,59),5,20)
  cylinder('hull','lamp',(153.1,s*72,59),(153.3,s*72,59),4.1,20)
 # Engine deck grill and layered access covers.
 box('hull','darksteel',(-86,0,66),(95,94,2))
 for i in range(19):box('hull','armor',(-129+i*4.7,0,68),(2,90,2))
 for y in (-50,50):box('hull','armor',(-87,y,67),(92,3,3))
 box('hull','armor',(55,-18,67),(44,30,3))
 cylinder('hull','armor',(55,-18,68),(55,-18,70),14,28)
 for y in (-10,-20,-30):box('hull','glass',(74,y,70),(7,7,4))
 for x in (-125,-90,-55,50,100):
  for y in (-58,58):cylinder('hull','darksteel',(x,y,65),(x,y,67),1.4,8)
 box('hull','armor',(119,0,64),(5,126,2))
 # Cast turret with shallow front cheeks and mantlet.
 dome('turret','armor',(-8,0,67),(65,54,34),48,14)
 cylinder('turret','darksteel',(-8,0,64),(-8,0,67),48,48)
 for y in (-29,29):dome('turret','armor',(32,y,72),(25,24,22),28,8)
 # Commander/gunner hatches, periscopes and low cupola.
 cylinder('turret','armor',(-25,-24,94),(-25,-24,104),15,28)
 cylinder('turret','armor',(-25,-24,104),(-25,-24,107),14.7,28)
 cylinder('turret','armor',(-15,24,95),(-15,24,99),15.5,28)
 for a in range(0,360,60):
  x,y=-25+13*math.cos(math.radians(a)),-24+13*math.sin(math.radians(a))
  box('turret','glass',(x,y,102),(5,3,3),math.radians(a))
 for x,y in [(-25,-24),(-15,24)]:
  box('turret','darksteel',(x,y,108 if y<0 else 100),(9,2,1))
  cylinder('turret','darksteel',(x-4,y,108 if y<0 else 100),(x-4,y,110 if y<0 else 102),.8,8)
 # Period optical rangefinder bulges and IR searchlight; no modern thermal/ERA.
 for y in (-49,49):
  cylinder('turret','armor',(2,y-4,86),(2,y+4,86),7,24)
  cylinder('turret','glass',(2,y+(4.2 if y>0 else -4.2),86),(2,y+(4.5 if y>0 else -4.5),86),5.3,24)
 cylinder('turret','armor',(39,30,86),(53,30,86),10.5,28)
 cylinder('turret','glass',(53.2,30,86),(53.5,30,86),8.8,28)
 box('turret','armor',(-57,0,81),(20,83,18))
 for y in (-42,42):box('turret','darksteel',(-58,y,82),(22,2,14))
 cylinder('turret','darksteel',(-36,32,97),(-36,32,165),.6,8)
 cylinder('turret','armor',(-36,32,94),(-36,32,101),2.5,12)
 # Cannon moves as a complete group, with proper hollow muzzle and bore.
 dome('gun','armor',(45,0,73),(21,22,23),32,10)
 cylinder('gun','darksteel',(48,0,82),(82,0,82),6.7,32)
 cylinder('gun','armor',(81,0,82),(312,0,82),4.2,32,r2=3.8,caps=False)
 cylinder('gun','armor',(154,0,82),(195,0,82),6.4,32)
 for x in (84,149,198,256):cylinder('gun','darksteel',(x,0,82),(x+1.6,0,82),4.65,32)
 # Muzzle rim and dark inner tube: open center survives close views.
 n=32
 for i in range(n):
  a,b=i/n*math.tau,(i+1)/n*math.tau
  o1,o2=(313,3.8*math.cos(a),82+3.8*math.sin(a)),(313,3.8*math.cos(b),82+3.8*math.sin(b))
  i1,i2=(313,2.8*math.cos(a),82+2.8*math.sin(a)),(313,2.8*math.cos(b),82+2.8*math.sin(b))
  quad('gun','darksteel',o1,o2,i2,i1)
 cylinder('gun','darksteel',(300,0,82),(313,0,82),2.8,32,caps=False)
 cylinder('gun','rubber',(299.9,0,82),(300,0,82),2.8,32)
 cylinder('gun','darksteel',(44,-9,79),(59,-9,79),1.5,16)
 # Six small stamped-metal road wheels, with shallow rubber rims and bolt rings.
 for s,label,y in [(1,'L',77),(-1,'R',-77)]:
  for i,x in enumerate([112,70,28,-14,-56,-98],1):
   p=f'wheel_{label}{i}'
   cylinder(p,'rubber',(x,y-6,19),(x,y+6,19),14.5,24)
   cylinder(p,'darksteel',(x,y-6.5,19),(x,y+6.5,19),12.6,24)
   cylinder(p,'armor',(x,y-7,19),(x,y+7,19),5.3,20)
   for a in range(0,360,60):
    xx,zz=x+8.4*math.cos(math.radians(a)),19+8.4*math.sin(math.radians(a))
    cylinder(p,'darksteel',(xx,y+s*6.6,zz),(xx,y+s*7.7,zz),1.15,8)
   cylinder('hull','darksteel',(x,s*64,27),(x-11,s*76,19),2,12)
  for x in (-132,141):
   cylinder('hull','darksteel',(x,y-8,24),(x,y+8,24),17.5,28)
   cylinder('hull','armor',(x,y-8.5,24),(x,y+8.5,24),11.5,24)
   for a in range(0,360,30):
    xx,zz=x+17.5*math.cos(math.radians(a)),24+17.5*math.sin(math.radians(a))
    box('hull','darksteel',(xx,y,zz),(4,15,4),0)
 # Continuous stadium-shaped belt, U follows travel; local geometry is independent of wheels.
 for side,y in [('left',77),('right',-77)]:
  p='track_'+side;path=[]
  # Clockwise path: top travels +X; bottom travels -X for positive U.
  for i in range(25):path.append((-132+(141+132)*i/24,43.5))
  for i in range(1,17):
   a=math.pi*.5-i/16*math.pi;path.append((141+19.5*math.cos(a),24+19.5*math.sin(a)))
  for i in range(1,25):path.append((141-(141+132)*i/24,4.5))
  for i in range(1,17):
   a=-math.pi*.5-i/16*math.pi;path.append((-132+19.5*math.cos(a),24+19.5*math.sin(a)))
  distance=0
  for i,(x,z) in enumerate(path):
   xn,zn=path[(i+1)%len(path)];length=math.hypot(xn-x,zn-z)
   a,b=(x,y-14.5,z),(xn,y-14.5,zn);c,d=(xn,y+14.5,zn),(x,y+14.5,z)
   quad(p,'tracks',a,b,c,d,[(distance/10,0),((distance+length)/10,0),((distance+length)/10,1),(distance/10,1)])
   # Link edge thickness forms a continuous visible belt, instead of loose wheel rings.
   for yy in (-14.5,14.5):
    vs=[(x,y+yy,z),(xn,y+yy,zn),(xn,y+yy,zn+1.7),(x,y+yy,z+1.7)]
    quad(p,'darksteel',*(vs if yy<0 else vs[::-1]))
   distance+=length
 # Tie-downs and handles add readable silhouette detail without borrowed art.
 for y in (-62,62):
  for x in (-110,-45,20,85):
   cylinder('hull','darksteel',(x,y,67),(x,y,70),.7,8)
   cylinder('hull','darksteel',(x+8,y,67),(x+8,y,70),.7,8)
   cylinder('hull','darksteel',(x,y,70),(x+8,y,70),.7,8)
 return PARTS,TRI

def lua_num(v):return f'{v:.6g}' if abs(v)>1e-8 else '0'
def lua_table(v):
 if isinstance(v,str):return json.dumps(v)
 if isinstance(v,(int,float)):return lua_num(v)
 if isinstance(v,list) or isinstance(v,tuple):return '{'+','.join(lua_table(x) for x in v)+'}'
 if isinstance(v,dict):return '{'+','.join('['+json.dumps(k)+']='+lua_table(x) for k,x in v.items())+'}'
 raise TypeError(type(v))

def export(addon):
 parts,tris=build();dest=addon/'lua/t64a_1971/geometry';dest.mkdir(parents=True,exist_ok=True)
 for old in dest.glob('chunk_*.lua'):old.unlink()
 chunks=[];largest=0
 for (pn,mat),triangles in tris.items():
  for start in range(0,len(triangles),512):
   flat=[float(x) for tri in triangles[start:start+512] for pos,normal,uv in tri for x in (*pos,*normal,*uv)]
   body='-- Original T-64A component mesh, generated by tools/build_t64a_model.py\nreturn '+lua_table({'Part':pn,'Material':'t64a_1971/'+mat,'Vertices':flat})+'\n'
   name=f'chunk_{len(chunks)+1:03}.lua';(dest/name).write_text(body)
   largest=max(largest,len(zlib.compress(body.encode())))
   chunks.append('t64a_1971/geometry/'+name)
 index={'Chunks':chunks,'Parts':parts,'TrackUVUnits':10,'TriangleCount':sum(len(t) for t in tris.values()),'Authoring':'Original procedural approximation of T-64A circa1971'}
 (dest/'index.lua').write_text('-- Original model index\nreturn '+lua_table(index)+'\n')
 source=addon/'assets/source/t64a_1971';source.mkdir(parents=True,exist_ok=True)
 payload={'parts':parts,'meshes':[{'part':pn,'material':m,'triangles':t} for (pn,m),t in tris.items()]}
 (source/'model_geometry.json').write_text(json.dumps(payload,separators=(',',':')))
 (source/'model_metadata.json').write_text(json.dumps({'index':index,'largest_zlib_chunk':largest,'units':'Source units, +Xforward +Yleft +Zup','new_original_geometry':True},indent=2))
 assert largest<60000,('network shard too large',largest)
 profile='''-- Original generated T-64A1971 game-art geometry; not an engineering survey.
local left,right={},{}
for i,x in ipairs({112,70,28,-14,-56,-98}) do left[i]=Vector(x,77,19);right[i]=Vector(x,-77,19) end
return {
 Ready=true,Model="models/hunter/blocks/cube025x025x025.mdl",VisualYaw=0,
 HullMins=Vector(-164,-70,29),HullMaxs=Vector(168,70,101),
 RenderMins=Vector(-183,-98,0),RenderMaxs=Vector(314,98,167),
 DriverSeat={Pos=Vector(70,-15,45),Ang=Angle(0,-90,0)},
 Engine={Pos=Vector(-95,0,48),Ang=Angle(0,0,0)},
 Wheels={Left=left,Right=right,DriveIndex=3,Model="models/props_vehicles/tire001c_car.mdl",Radius=14.5,Width=14},
 Suspension={Height=7,MaxTravel=7,ControlArmLength=150,SpringConstant=42000,SpringDamping=1800,SpringRelativeDamping=2000},
 Turret={AimRate=16,PitchMin=-14,PitchMax=6},TrackUVUnits=10,
 Rig={TurretPivot=Vector(-8,0,65),GunPivot=Vector(45,0,82),CannonMuzzle=Vector(313,0,82),MGMuzzle=Vector(59,-9,79),Sight=Vector(60,-18,103)}
}
'''
 (addon/'lua/t64a_1971/sh_generated_profile.lua').write_text(profile)
 print('T64 original geometry:',index['TriangleCount'],'triangles,',len(chunks),'shards, max compressed',largest)
 return source/'model_geometry.json'

def blender_sources(addon,preview):
 import bpy
 from mathutils import Vector
 import numpy as np
 source=addon/'assets/source/t64a_1971';payload=json.loads((source/'model_geometry.json').read_text())
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 root=bpy.data.objects.new('T64A1971 ORIGINAL MODEL',None);bpy.context.collection.objects.link(root)
 empties={}
 for name,info in payload['parts'].items():
  empty=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(empty);empties[name]=empty
  empty.parent=root;empty.location=info['Pivot']
 empties['gun'].parent=empties['turret'];empties['gun'].location=(53,0,17)
 mats={}
 material_colors={'armor':(.17,.22,.12,1),'darksteel':(.07,.075,.06,1),'rubber':(.025,.027,.023,1),'tracks':(.06,.055,.04,1),'glass':(.018,.026,.023,1),'lamp':(.22,.21,.15,1)}
 mapdir=pathlib.Path('/workspace/scratch/material_sources')
 texnames={'armor':'olive','darksteel':'neutral','rubber':'rubber_color','tracks':'tracks_color','glass':'glass','lamp':'lamp'}
 normals={'armor':'olive_normal','darksteel':'steel_normal','rubber':'rubber_normal','tracks':'tracks_normal'}
 for key,col in material_colors.items():
  mat=bpy.data.materials.new('t64a_1971/'+key);mat.use_nodes=True
  bsdf=mat.node_tree.nodes.get('Principled BSDF');bsdf.inputs['Base Color'].default_value=col;bsdf.inputs['Roughness'].default_value=.93
  bsdf.inputs['Metallic'].default_value=.08 if key in ('armor','darksteel','tracks') else 0
  path=mapdir/(texnames[key]+'.png')
  if path.exists():
   tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(path),check_existing=True);tex.image.alpha_mode='NONE';tex.extension='REPEAT';mat.node_tree.links.new(tex.outputs['Color'],bsdf.inputs['Base Color'])
  normal=mapdir/(normals.get(key,'')+'.png')
  if key in normals and normal.exists():
   tx=mat.node_tree.nodes.new('ShaderNodeTexImage');tx.image=bpy.data.images.load(str(normal),check_existing=True);tx.image.colorspace_settings.name='Non-Color';tx.extension='REPEAT'
   sep=mat.node_tree.nodes.new('ShaderNodeSeparateColor');combine=mat.node_tree.nodes.new('ShaderNodeCombineColor');inv=mat.node_tree.nodes.new('ShaderNodeMath');inv.operation='SUBTRACT';inv.inputs[0].default_value=1
   mat.node_tree.links.new(tx.outputs['Color'],sep.inputs[0]);mat.node_tree.links.new(sep.outputs[0],combine.inputs[0]);mat.node_tree.links.new(sep.outputs[1],inv.inputs[1]);mat.node_tree.links.new(inv.outputs[0],combine.inputs[1]);mat.node_tree.links.new(sep.outputs[2],combine.inputs[2])
   nm=mat.node_tree.nodes.new('ShaderNodeNormalMap');nm.inputs['Strength'].default_value=.65;mat.node_tree.links.new(combine.outputs[0],nm.inputs['Color']);mat.node_tree.links.new(nm.outputs['Normal'],bsdf.inputs['Normal'])
  mats[key]=mat
 for count,m in enumerate(payload['meshes']):
  verts=[];norms=[];uvs=[]
  for tri in m['triangles']:
   for pos,norm,uv in tri:verts.append(pos);norms.append(norm);uvs.append(uv)
  mesh=bpy.data.meshes.new(m['part']+'_'+m['material']);mesh.from_pydata(verts,[],[tuple(range(i,i+3)) for i in range(0,len(verts),3)]);mesh.update()
  for poly in mesh.polygons:poly.use_smooth=True
  if hasattr(mesh,'normals_split_custom_set'):mesh.normals_split_custom_set(norms)
  layer=mesh.uv_layers.new(name='UVMap');layer.data.foreach_set('uv',np.array(uvs,dtype=np.float32).ravel())
  ob=bpy.data.objects.new(mesh.name,mesh);bpy.context.collection.objects.link(ob);ob.parent=empties[m['part']];ob.data.materials.append(mats[m['material']])
 bpy.ops.object.select_all(action='SELECT');root.select_set(True)
 for ob in bpy.context.scene.objects:
  if ob.type=='MESH' or ob.type=='EMPTY':ob.select_set(True)
 bpy.ops.file.pack_all()
 bpy.ops.wm.save_as_mainfile(filepath=str(source/'t64a_1971.blend'))
 bpy.ops.export_scene.gltf(filepath=str(source/'t64a_1971.glb'),export_format='GLB',use_selection=True,export_yup=True)
 # Studio setup belongs only to the preview, not the original reusable model.
 bpy.ops.mesh.primitive_plane_add(size=1600,location=(0,0,2.8));ground=bpy.context.object
 mat=bpy.data.materials.new('Neutral studio floor');mat.diffuse_color=(.16,.17,.15,1);ground.data.materials.append(mat)
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False;scene.world.color=(.35,.35,.35)
 for loc,energy,size in [((150,-250,600),3900000,400),((-220,320,400),2500000,300)]:
  light=bpy.data.lights.new('Soft area','AREA');light.energy=energy;light.shape='DISK';light.size=size;ob=bpy.data.objects.new('Soft area',light);bpy.context.collection.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector((0,0,60))-ob.location).to_track_quat('-Z','Y').to_euler()
 cam=bpy.data.objects.new('Preview camera',bpy.data.cameras.new('Preview camera'));bpy.context.collection.objects.link(cam);scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=560
 scene.render.resolution_x=1600;scene.render.resolution_y=1000;scene.render.resolution_percentage=100;scene.view_settings.view_transform='Standard'
 preview.mkdir(parents=True,exist_ok=True)
 for name,loc,target in [('front',(500,-570,330),(20,0,70)),('rear',(-490,530,310),(0,0,65))]:
  cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(preview/f't64a_1971_{name}.png');bpy.ops.render.render(write_still=True)
 print('ORIGINAL BLEND/GLB and previews saved')

def main():
 args0=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:]
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--addon',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1]);ap.add_argument('--sources',action='store_true');ap.add_argument('--blender',action='store_true');ap.add_argument('--preview',type=pathlib.Path,default=pathlib.Path('/workspace/artifacts/t64a_1971_preview'))
 args=ap.parse_args(args0)
 if args.blender:blender_sources(args.addon,args.preview);return
 export(args.addon)
 if args.sources:subprocess.run(['blender','-b','-t','4','--python',str(pathlib.Path(__file__).resolve()),'--','--blender','--addon',str(args.addon),'--preview',str(args.preview)],check=True)
if __name__=='__main__':main()
